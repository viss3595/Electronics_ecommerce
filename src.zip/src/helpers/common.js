export  const capitalize = (s) => {
    if (typeof s !== 'string') return ''
    return s.charAt(0).toUpperCase() + s.slice(1)
}

export const dateFormat = (givenDate, time) =>{
    if(givenDate.includes('Z') == true ){
        givenDate = givenDate.replace('Z','');
    }
    var mydate = new Date(givenDate);
    var month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"][mydate.getMonth()];
    // return mydate.getDate() + ' ' + month + ' ' + mydate.getFullYear();
    if(time == true || time == 1){
        return mydate.getDate() + ' ' + month + ' ' + mydate.getFullYear() +' '+ mydate.getHours() + ":"  + mydate.getMinutes()
    }else{
        
        return mydate.getDate() + ' ' + month + ' ' + mydate.getFullYear();
    }
}

export const caseInsensitiveSubStrMatch = (str, substr) => {
    var re = new RegExp(substr, 'i');
    let match = str.match(re)
    if(match == null){
      return false
    }
    return true;
  }

/** CONVERT SECONDS INTO MINTUES */
export const secondToMinutes = (seconds) => {
    return !isNaN(Number(seconds/60))? (Number(seconds/60)).toFixed(0): 0
}