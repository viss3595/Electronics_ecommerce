import React from 'react';
import { Redirect } from 'react-router-dom';
import { Route } from 'react-router-dom';
import * as FeatherIcon from 'react-feather';

import { isUserAuthenticated, getLoggedInUser } from '../helpers/authUtils';
import { toast } from 'react-toastify';
//Affiliate
const Agent = React.lazy(() => import('../pages/settings/Agent'));
const User = React.lazy(() => import('../pages/settings/User'));
const UserRole = React.lazy(() => import('../pages/settings/UserRole'));
const Customer = React.lazy(() => import('../pages/settings/Customer'));
const Sales = React.lazy(() => import('../pages/settings/Sales'));
const Affiliate = React.lazy(() => import('../pages/settings/Affiliate'));
const ProductType = React.lazy(() => import('../pages/settings/ProductType'));
const PaymentStatus = React.lazy(() => import('../pages/settings/PaymentStatus'));
const CommissionFee = React.lazy(() => import('../pages/settings/CommissionFee'));
const SettlementAgent =  React.lazy(() => import('../pages/settings/SettlementAgent'));
const SummarySettlementCommission = React.lazy(() => import('../pages/settings/SummarySettlementCommission'));
const ViewSettlementCommissionDetails = React.lazy(() => import('../pages/settings/ViewSettlementCommissionDetails'));
const Notification = React.lazy(() => import('../pages/settings/Notification'));
const SendNotification = React.lazy(() => import('../pages/settings/SendNotification'));
const AddNotification = React.lazy(() => import('../pages/settings/AddNotification'));

// auth
const Login = React.lazy(() => import('../pages/auth/Login'));
const Reset = React.lazy(() => import('../pages/auth/ResetPassword'));
const Logout = React.lazy(() => import('../pages/auth/Logout'));
const Register = React.lazy(() => import('../pages/auth/Register'));
const ForgetPassword = React.lazy(() => import('../pages/auth/ForgetPassword'));
const AuthenticateOAuth = React.lazy(() => import('../pages/auth/AuthenticateOAuth'));
const RouteNotFoundRedirect = React.lazy(() => import('../pages/auth/RouteNotFoundRedirect'));
const Confirm = React.lazy(() => import('../pages/auth/Confirm'));

/** VERIFICATION MAIL ROUTE */
const Verification = React.lazy(() => import('../pages/auth/AccountVerification'));

// dashboard
const Dashboard = React.lazy(() => import('../pages/dashboard'));
const Call = React.lazy(() => import('../pages/dashboard/Call'));
const CallUpload = React.lazy(() => import('../pages/dashboard/CallUpload'));
// apps
const CalendarApp = React.lazy(() => import('../pages/apps/Calendar'));
const EmailInbox = React.lazy(() => import('../pages/apps/Email/Inbox'));
const EmailDetail = React.lazy(() => import('../pages/apps/Email/Detail'));
const EmailCompose = React.lazy(() => import('../pages/apps/Email/Compose'));
const ProjectList = React.lazy(() => import('../pages/apps/Project/List'));
const ProjectDetail = React.lazy(() => import('../pages/apps/Project/Detail/'));
const TaskList = React.lazy(() => import('../pages/apps/Tasks/List'));
const TaskBoard = React.lazy(() => import('../pages/apps/Tasks/Board'));

// pages
const Starter = React.lazy(() => import('../pages/other/Starter'));
const Profile = React.lazy(() => import('../pages/other/Profile/'));
const Activity = React.lazy(() => import('../pages/other/Activity'));
const Invoice = React.lazy(() => import('../pages/other/Invoice'));
const Pricing = React.lazy(() => import('../pages/other/Pricing'));
const Error404 = React.lazy(() => import('../pages/other/Error404'));
const Error500 = React.lazy(() => import('../pages/other/Error500'));

// ui
const BSComponents = React.lazy(() => import('../pages/uikit/BSComponents/'));
const FeatherIcons = React.lazy(() => import('../pages/uikit/Icons/Feather'));
const UniconsIcons = React.lazy(() => import('../pages/uikit/Icons/Unicons'));
const Widgets = React.lazy(() => import('../pages/uikit/Widgets/'));

// charts
const Charts = React.lazy(() => import('../pages/charts/'));

// forms
const BasicForms = React.lazy(() => import('../pages/forms/Basic'));
const FormAdvanced = React.lazy(() => import('../pages/forms/Advanced'));
const FormValidation = React.lazy(() => import('../pages/forms/Validation'));
const FormWizard = React.lazy(() => import('../pages/forms/Wizard'));
const FileUpload = React.lazy(() => import('../pages/forms/FileUpload'));
const Editor = React.lazy(() => import('../pages/forms/Editor'));

// tables
const BasicTables = React.lazy(() => import('../pages/tables/Basic'));
const AdvancedTables = React.lazy(() => import('../pages/tables/Advanced'));

// SETTINGS MENU
const AgentList = React.lazy(() => import('../pages/settings/AgentList'));
const TeamList = React.lazy(() => import('../pages/settings/TeamList'));

// SUPER ADMIN ROUTES
const SuperAdmin = React.lazy(() => import('../pages/admin/AdminForm'));
const CallSummary = React.lazy(() => import('../pages/settings/CallSummary'));
const CallDetail = React.lazy(() => import('../pages/settings/CallDetail'));
const CallDetailFilter = React.lazy(() => import('../pages/settings/CallDetailFilter'));

//NotAuthorizePage

const NotAuthorizePage = React.lazy(() => import('../pages/auth/NotAuthorizePage'));


// handle auth and authorization
let previusComponent = {};
const PrivateRoute = ({ component: Component, roles, ...rest }) => (
    <Route
        {...rest}
        render={(props) => {

       
            if (!isUserAuthenticated()) {
 
                // not logged in so redirect to login page with the return url
                return <Redirect to={{ pathname: '/login', state: { from: props.location } }} />;
            }
            // console.log('rest => ', {...rest});
            const loggedInUser = getLoggedInUser();
            // check if route is restricted by role
            const loggedInUserRoles = loggedInUser.roles;
            // console.log("loggedInUserRoles => ", loggedInUserRoles);
            // console.log("loggedInUser => ", loggedInUser);
             console.log("roles => ", loggedInUser.roles);
            // console.log(loggedInUserRoles.indexOf(roles));
            if (roles && loggedInUserRoles.indexOf(roles) === -1) {
                // role not authorised so redirect to home page
                console.log("props",props);
                console.log("roles",roles);
                
                toast('You do not have access to this option',{bodyClassName:'error-toast'});
                return <Redirect to={{ pathname: '/notauthorize',state: { }}} />;
               // this.props.history.push("/NotAuthorize");
              // return <Redirect to="/NotAuthorize" />
            //    return <div>
            //                 <h3>You have not Authorize this page!</h3>
            //             </div>;
               // return <Redirect to={{ pathname: '/login', state: { from: props.location } }} />;
                //return previusComponent.component;

            }
            // if (loggedInUserRoles.indexOf(roles) === -1) {
            //     return <Redirect to={{ pathname: '/' }} />;
            // }
            // authorised so return component
            //previusComponent.component = <Component {...props}/>;
            return <Component {...props} />;
        }}
    />
);

// root routes
const rootRoute = {
    path: '/',
    exact: true,
    component: () => <Redirect to="/dashboard" />,

    route: PrivateRoute,
};

// dashboards
const dashboardRoutes = {
    path: '/dashboard',
    name: 'Dashboard',
    icon: FeatherIcon.Grid,
    header: '',
    component: Dashboard,
    roles: 'dashboard',
    route: PrivateRoute,
};





const crmRoute = {
    path: '/crm',
    name: 'CRM',
    icon: FeatherIcon.Users,
    children: [
        {
            name: 'List Agent',
            path: '/crm/agents',
            component: Agent,
            roles: 'listAgent',
            route: PrivateRoute,
        },
        {
            name: 'List Customer',
            path: '/crm/customer',
            component: Customer,
            roles: 'listCustomer',
            route: PrivateRoute,
        }],
    };
    
const salesAndMarketing = {
    path: '/sales',
    name: 'Sales and Marketing',
    icon: FeatherIcon.FileText,
    children: [
        {
            name: 'List Sale',
            path: '/sales/manage',
            component: Sales,
            roles: 'listSaleOperation',
            route: PrivateRoute,
        },
    ]
};

const finance = {
    path: '/finance',
    name: 'Finance',
    icon: FeatherIcon.DollarSign,
    children: [
        {
            name: 'Settlement Commission',
            path: '/finance/settlementCommission',
            component: SummarySettlementCommission,
            roles: 'listSaleOperation',
            route: PrivateRoute,
        },
        {
            path: '/finance/viewSettlementCommissionDetails',
            component: ViewSettlementCommissionDetails,
            roles: 'listSaleOperation',
            route: PrivateRoute,
        }
    ]
}

const manufacturingRoute = {
    path: '/manufacturing',
    name: 'Manufacturing',
    icon: FeatherIcon.Settings,
    children: [
        {
            name: 'Affiliate',
            path: '/manufacturing/affiliate',
            component: Affiliate,
            roles: 'affiliate',
            route: PrivateRoute,
        },
        {
            name: 'Product Type',
            path: '/manufacturing/productType',
            component: ProductType,
            roles: 'productType',
            route: PrivateRoute,
        },
        {
            name: 'Payment Status',
            path: '/manufacturing/paymentStatus',
            component: PaymentStatus,
            roles: 'paymentStatus',
            route: PrivateRoute,
        }
    ],
};    
    
const userRoute = {
    path: '/hr',
    name: 'HR',
    icon: FeatherIcon.UserPlus,
    children: [
        {
            name: 'User Role',
            path: '/hr/role',
            component: UserRole,
            roles: 'userRole',
            route: PrivateRoute,
        },
        {
            name: 'User',
            path: '/hr/manage',
            component: User,
            roles: 'user',
            route: PrivateRoute,
        }
    ],
};    

const reportsRoute = {
    path: '/report',
    name: 'Report',
    icon: FeatherIcon.Clipboard,
    children: [
        {
            name: 'Commission Fee',
            path: '/report/commissionFee',
            component: CommissionFee,
            roles: 'commissionFee',
            route: PrivateRoute,
        },
        {
            name: 'Settlement Agent',
            path: '/report/settlementAgent',
            component: SettlementAgent,
            roles: 'settlementAgent',
            route: PrivateRoute,
        }
    ],
};    

const notificationRoute = {
    path: '/notification',
    name: 'Notification',
    icon : FeatherIcon.Rss,
    children: [
        {
            name: 'List Notification',
            path: '/notification/list',
            component: Notification,
            roles: 'listNotification',
            route: PrivateRoute,
        }
        ,
        {
            path: '/notification/send',
            component: SendNotification,
            route: PrivateRoute,
        }
        //,
        // {
        //     path: '/notification/add',
        //     component: AddNotification,
        //     route: PrivateRoute,
        // }
    ]
}
    
    // const agentRoute = {
    //     path: '/agent',
    //     name: 'Agents',
    //     // header: 'Apps',
    //     icon: FeatherIcon.BarChart2,
    //     component: AgentList,
    //     route: PrivateRoute
    // };

    // apps
    
    // const callAppRoute = {
//     path: '/analyse/calls/:callId',
//     // name: 'Call',
//     // header: 'Apps',
//     // icon: FeatherIcon.PhoneCall,
//     component: Call,
//     route: PrivateRoute,
//     roles: ['Admin'],
// };


// Library Route
// const CallUploadRoute = {
//     path: '/upload-calls',
//     component: CallUpload,
//     name: 'Upload',
//     icon: FeatherIcon.Upload,
//     roles: ['Admin'],
//     route: Route,
// };

// const callsListRoute = {
//     // path: '/analyse/call(/:momentId)(/:groupId)(/:callerName)',
//     path: '/analyse/call/',
//     name: 'Call Analysis',
//     // header: 'Apps',
//     icon: FeatherIcon.BarChart2,
//     component: CallDetailFilter,
//     route: PrivateRoute,
//     roles: ['Admin'],
// };

const noPageFound = {
    path: '/*',
    name: '404',
    component: RouteNotFoundRedirect,
    route: Route,
};





// const calendarAppRoutes = {
//     path: '/apps/calendar',
//     name: 'Calendar',
//     header: 'Apps',
//     icon: FeatherIcon.Calendar,
//     component: CalendarApp,
//     route: PrivateRoute,
//     roles: ['Admin'],
// };

// const emailAppRoutes = {
//     path: '/apps/email',
//     name: 'Email',
//     icon: FeatherIcon.Inbox,
//     children: [
//         {
//             path: '/apps/email/inbox',
//             name: 'Inbox',
//             component: EmailInbox,
//             route: PrivateRoute,
//             roles: ['Admin'],
//         },
//         {
//             path: '/apps/email/details',
//             name: 'Details',
//             component: EmailDetail,
//             route: PrivateRoute,
//             roles: ['Admin'],
//         },
//         {
//             path: '/apps/email/compose',
//             name: 'Compose',
//             component: EmailCompose,
//             route: PrivateRoute,
//             roles: ['Admin'],
//         },
//     ]
// };

// const projectAppRoutes = {
//     path: '/apps/projects',
//     name: 'Projects',
//     icon: FeatherIcon.Briefcase,
//     children: [
//         {
//             path: '/apps/projects/list',
//             name: 'List',
//             component: ProjectList,
//             route: PrivateRoute,
//             roles: ['Admin'],
//         },
//         {
//             path: '/apps/projects/detail',
//             name: 'Detail',
//             component: ProjectDetail,
//             route: PrivateRoute,
//             roles: ['Admin'],
//         },
//     ]
// };

// const taskAppRoutes = {
//     path: '/apps/tasks',
//     name: 'Tasks',
//     icon: FeatherIcon.Bookmark,
//     children: [
//         {
//             path: '/apps/tasks/list',
//             name: 'List',
//             component: TaskList,
//             route: PrivateRoute,
//             roles: ['Admin'],
//         },
//         {
//             path: '/apps/tasks/board',
//             name: 'Board',
//             component: TaskBoard,
//             route: PrivateRoute,
//             roles: ['Admin'],
//         },
//     ],
// };

const appRoutes = [
    // dashboardRoutes,
    // crmRoute,
    // salesAndMarketing,
    // userRoute,
];

// // pages
// const pagesRoutes = {
//     path: '/pages',
//     name: 'Pages',
//     header: 'Custom',
//     icon: FeatherIcon.FileText,
//     children: [
//         {
//             path: '/pages/starter',
//             name: 'Starter',
//             component: Starter,
//             route: PrivateRoute,
//             roles: ['Admin'],
//         },
//         {
//             path: '/pages/profile',
//             name: 'Profile',
//             component: Profile,
//             route: PrivateRoute,
//             roles: ['Admin'],
//         },
//         {
//             path: '/pages/activity',
//             name: 'Activity',
//             component: Activity,
//             route: PrivateRoute,
//             roles: ['Admin'],
//         },
//         {
//             path: '/pages/invoice',
//             name: 'Invoice',
//             component: Invoice,
//             route: PrivateRoute,
//             roles: ['Admin'],
//         },
//         {
//             path: '/pages/pricing',
//             name: 'Pricing',
//             component: Pricing,
//             route: PrivateRoute,
//             roles: ['Admin'],
//         },
//         {
//             path: '/pages/error-404',
//             name: 'Error 404',
//             component: Error404,
//             route: Route
//         },
//         {
//             path: '/pages/error-500',
//             name: 'Error 500',
//             component: Error500,
//             route: Route
//         },
//     ]
// };

// components
// const componentsRoutes = {
//     path: '/ui',
//     name: 'UI Elements',
//     header: 'Components',
//     icon: FeatherIcon.Package,
//     children: [
//         {
//             path: '/ui/bscomponents',
//             name: 'Bootstrap UI',
//            , groupId: this.props.match.params.groupId component: BSComponents,
//             route: PrivateRoute,
//             roles: ['Admin'],
//         },
//         {
//             path: '/ui/icons',
//             name: 'Icons',
//             children: [
//                 {
//                     path: '/ui/icons/feather',
//                     name: 'Feather Icons',
//                     component: FeatherIcons,
//                     route: PrivateRoute,
//                     roles: ['Admin'],
//                 },
//                 {
//                     path: '/ui/icons/unicons',
//                     name: 'Unicons Icons',
//                     component: UniconsIcons,
//                     route: PrivateRoute,
//                     roles: ['Admin'],
//                 },
//             ]
//         },
//         {
//             path: '/ui/widgets',
//             name: 'Widgets',
//             component: Widgets,
//             route: PrivateRoute,
//             roles: ['Admin'],
//         },

//     ]
// };

// charts
// const chartRoutes = {
//     path: '/charts',
//     name: 'Charts',
//     component: Charts,
//     icon: FeatherIcon.PieChart,
//     roles: ['Admin'],
//     route: PrivateRoute
// }

// forms
// const formsRoutes = {
//     path: '/forms',
//     name: 'Forms',
//     icon: FeatherIcon.FileText,
//     children: [
//         {
//             path: '/forms/basic',
//             name: 'Basic Elements',
//             component: BasicForms,
//             route: PrivateRoute,
//         },
//         {
//             path: '/forms/advanced',
//             name: 'Advanced',
//             component: FormAdvanced,
//             route: PrivateRoute,
//         },
//         {
//             path: '/forms/validation',
//             name: 'Validation',
//             component: FormValidation,
//             route: PrivateRoute,
//         },
//         {
//             path: '/forms/wizard',
//             name: 'Wizard',
//             component: FormWizard,
//             route: PrivateRoute,
//         },
//         {
//             path: '/forms/editor',
//             name: 'Editor',
//             component: Editor,
//             route: PrivateRoute,
//         },
//         {
//             path: '/forms/upload',
//             name: 'File Upload',
//             component: FileUpload,
//             route: PrivateRoute,
//         }
//     ]
// };

// const tableRoutes = {
//     path: '/tables',
//     name: 'Tables',
//     icon: FeatherIcon.Grid,
//     children: [
//         {
//             path: '/tables/basic',
//             name: 'Basic',
//             component: BasicTables,
//             route: PrivateRoute,
//         },
//         {
//             path: '/tables/advanced',
//             name: 'Advanced',
//             component: AdvancedTables,
//             route: PrivateRoute,
//         }]
// };



/*** SETTING ROUTE */

/** SUPER ADMIN ROUTE */
const superAdminRoute = {
    path: '/admin_settings',
    name: 'Admin Settings',
    icon: FeatherIcon.Settings,
    component: SuperAdmin,
    roles: ['Admin'],
    route: PrivateRoute,
};

// auth
const authRoutes = {
    path: '/',
    name: 'Auth',
    children: [
        {
            path: '/login',
            name: 'Login',
            component: Login,
            route: Route,
        },
        {
            path: '/reset-password/:token',
            name: 'ResetPassword',
            component: Reset,
            route: Route,
        },
        {
            path: '/logout',
            name: 'Logout',
            component: Logout,
            route: Route,
        },
        {
            path: '/register',
            name: 'Register',
            component: Register,
            route: Route,
        },
        {
            path: '/confirm',
            name: 'Confirm',
            component: Confirm,
            route: Route,
        },
        {
            path: '/forget-password',
            name: 'Forget Password',
            component: ForgetPassword,
            route: Route,
        },
        {
            path: '/verify/:email',
            name: 'Verification',
            component: Verification,
            route: Route,
        },
        {
            path: '/authenticate/custom',
            name: 'Authenticate OAuth',
            component: AuthenticateOAuth,
            route: Route,
        },
        {
            path: '/notauthorize',
            name: 'notauthorize ',
            component: NotAuthorizePage,
            roles: 'notauthorize',
            route: Route,
        }
    ],
};

// FOR PREVIEW FEEDBACK COMMENT
// const previewFeedbackRoute = {

// };

// flatten the list of all nested routes
const flattenRoutes = (routes) => {
    let flatRoutes = [];

    routes = routes || [];
    routes.forEach((item) => {
        flatRoutes.push(item);

        if (typeof item.children !== 'undefined') {
            flatRoutes = [...flatRoutes, ...flattenRoutes(item.children)];
        }
    });
    return flatRoutes;
};

// All routes
const allRoutes = [
    // callAppRoute,
    rootRoute,
    dashboardRoutes,
    ...appRoutes,
    // pagesRoutes,
    // componentsRoutes,
    // chartRoutes,
    // formsRoutes,
    // tableRoutes,
    // CallUploadRoute,
    authRoutes,
    salesAndMarketing,
    manufacturingRoute,
    crmRoute,
    userRoute,
    reportsRoute,
    finance,
    notificationRoute,
    superAdminRoute,
    noPageFound,
];

const authProtectedRoutes = [
    dashboardRoutes,
    crmRoute,
    salesAndMarketing,
    finance,
    manufacturingRoute,
    userRoute,
    notificationRoute,
    reportsRoute,
    

    // CallUploadRoute,
    // callAppRoute,

    // ,
    // pagesRoutes,
    // componentsRoutes,
    // chartRoutes,
    // formsRoutes,
    // tableRoutes,
];

// const addValidRoutes = () => {
//     let user = getLoggedInUser();
//     console.log(user);
//     if (user) {
//         let loggedInUserRoles = user.roles;
//         // console.log("loggedInUserRoles => ", loggedInUserRoles);
//         appRoutes.map((route) => {
//             // console.log("route => ", route);
//             if (route.children !== undefined) {
//                 let childRoutes = [];
//                 route.children.map((child, index) => {
//                     // console.log("child => ", child);
//                     // console.log(loggedInUserRoles.indexOf(child.roles));
//                     if (loggedInUserRoles.indexOf(child.roles) > -1) {
//                         // console.log("inside slice");
//                         childRoutes.push(child);
//                     }        
//                 })
//                 route.children = childRoutes;
//                 // console.log("after slice => ", route.children);
//                 if (childRoutes.length > 0) {
//                     authProtectedRoutes.push(route);
//                 }
//             } else {
//                 if (loggedInUserRoles.indexOf(route.roles) > -1) {
//                     authProtectedRoutes.push(route);
//                 }
//             }
//         })
//         console.log("authProtectedRoutes => ", authProtectedRoutes);
//     }
// }

// addValidRoutes();
const allFlattenRoutes = flattenRoutes(allRoutes);
export { allRoutes, 
    authProtectedRoutes, 
    allFlattenRoutes, superAdminRoute };
