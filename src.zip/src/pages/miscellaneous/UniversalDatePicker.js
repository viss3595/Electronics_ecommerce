import React from 'react';
import { connect } from 'react-redux';
import { setDateRange, setPastDateRange } from '../../redux/actions';
import Flatpickr from 'react-flatpickr';
import { DATE_RANGE, PAST_DATE_RANGE } from './../../constants/options';

import moment from 'moment';

// Calculating the to & From date initially
const dateTo = moment(new Date()).format('YYYY-MM-DD');
const dateFrom = moment(new Date()).subtract(7, 'days').startOf('day').format('YYYY-MM-DD');

class UniversalDatePicker extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            dateRange: DATE_RANGE,
            pastDaterange: PAST_DATE_RANGE,
        };
        console.log('>>>>>', this.props);
    }

    render() {
        return (
            <React.Fragment>
                <div
                    style={{
                        width: !this.props.isWidthTimmed ? '100%' : '19%',
                        float: this.props.isFloatDisabled ? 'none' : 'right',
                    }}
                    className={`form-group ${this.props.className ? this.props.className : ''}`}>
                    <Flatpickr
                        value={[this.props.dateRange.from, this.props.dateRange.to]}
                        options={{ mode: 'range' }}
                        /** TODO: please check if this console is required or not */
                        onChange={(date) => {
                            console.log(date);
                            if (date.length > 1) {
                                console.log(date);
                                this.props.setDateRange(
                                    moment(date[0]).startOf('day').utc().format(),
                                    moment(date[1]).endOf('day').utc().format()
                                );
                                this.props.setPastDateRange(
                                    moment(date[0])
                                        .subtract(moment(date[1]).diff(moment(date[0]), 'days'), 'days')
                                        .startOf('day')
                                        .utc()
                                        .format(),
                                    moment(date[0]).subtract(1, 'days').endOf('day').utc().format()
                                );
                                this.props.handleDateChange();
                            }
                        }}
                        className="form-control"
                    />
                </div>
            </React.Fragment>
        );
    }
}

// export default UniversalDatePicker;
const mapStateToProps = (state) => {
    return state.Options;
};
export default connect(mapStateToProps, { setDateRange, setPastDateRange })(UniversalDatePicker);
