import React, { useState } from 'react';
import { connect } from 'react-redux';
import moment from 'moment';
import { setDateRange, setPastDateRange } from '../../redux/actions';
import { DateRange } from 'react-date-range';

import 'react-date-range/dist/styles.css'; // main style file
import 'react-date-range/dist/theme/default.css'; // theme css file

const BetterDatePicker = ({ setDateRange, setPastDateRange, dateRange, handleDateChange }) => {
    const [dropdown, setdropdown] = useState('hidden');
    const dateToCalFormat = (date, par) => {
        if (par === 'from') {
            const val = date.split('-');
            const secondVal = val[2].split('T')[0];
            return new Date(parseInt(val[0]), parseInt(val[1] - 1), parseInt(secondVal) + 1);
        }
        if (par === 'to') {
            const val = date.split('-');
            const secondVal = val[2].split('T')[0];
            return new Date(parseInt(val[0]), parseInt(val[1] - 1), parseInt(secondVal));
        }
    };
    console.log(dateRange.from);

    const [state, setState] = useState([
        {
            startDate: dateToCalFormat(dateRange.from, 'from'),
            endDate: dateToCalFormat(dateRange.to, 'to'),
            key: 'selection',
        },
    ]);

    console.log(state);

    return (
        <div className="date-form">
            <div class="btn-group dropdown mt-2 mr-1 show">
                <button
                    onClick={() => {
                        dropdown === 'show' ? setdropdown('hidden') : setdropdown('show');
                    }}
                    class="btn btn-secondary dropdown-toggle"
                    type="button"
                    data-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="true">
                    <div>
                        {moment(dateRange.from).format('DD-MM-YY')} to {moment(dateRange.to).format('DD-MM-YY')}
                    </div>
                </button>
                <form class={'dropdown-menu dropdown-lg p-3 ' + dropdown} x-placement="bottom-start">
                    <DateRange
                        editableDateInputs={true}
                        onChange={(item) => {
                            const { startDate, endDate } = item.selection;
                            const date = [startDate, endDate];
                            setState([item.selection]);
                            console.log(state);

                            setDateRange(
                                moment(date[0]).startOf('day').utc().format(),
                                moment(date[1]).endOf('day').utc().format()
                            );
                            setPastDateRange(
                                moment(date[0])
                                    .subtract(moment(date[1]).diff(moment(date[0]), 'days'), 'days')
                                    .startOf('day')
                                    .utc()
                                    .format(),
                                moment(date[0]).subtract(1, 'days').endOf('day').utc().format()
                            );
                        }}
                        moveRangeOnFirstSelection={false}
                        ranges={state}
                    />

                    <button
                        onClick={(e) => {
                            e.preventDefault();
                            setdropdown('hidden');
                            handleDateChange();
                        }}
                        class="btn btn-primary">
                        Apply
                    </button>
                </form>
            </div>
            <div className="lorem"></div>
        </div>
    );
};

const mapStateToProps = (state) => {
    return state.Options;
};

export default connect(mapStateToProps, { setDateRange, setPastDateRange })(BetterDatePicker);
