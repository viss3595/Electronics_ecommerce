import React, { Component } from 'react';
import { Row, Col, Form, FormGroup, Label, Input, FormText, Button, Card, CardBody } from 'reactstrap';
import { AvForm, AvGroup, AvInput, AvFeedback, AvField } from 'availity-reactstrap-validation';
import { servicePost } from "./../../../helpers/api";
import ReactMultiSelectCheckboxes from 'react-multiselect-checkboxes';
import { connect } from 'react-redux';
import { toast } from 'react-toastify';
import Select from 'react-select';
class AddTeam extends Component {
    constructor(props){
        super(props);
        console.log('props===>',props);
        let assignedAgent=[];
        if(this.props.data.assignedAgent){
            let values = this.props.data.teamData;
            for (let i = 0; i < values.length; i++) {
                const element = values[i];
                assignedAgent.push({ value: element._id , label: element.name })
            }
        }

        this.state = {
            isSuccess: false,
            message: '',
            agentListOpt: '',
            selectedAgentList: assignedAgent,
            teamError: 0,
            errorMesg: '',
            isProcessing: false
            // tableRecords: this.props.tableRow
        }
        this.handleSubmit = this.handleSubmit.bind(this);
        // HEADERS
        this.headers= {
            "Content-Type": 'application/json',
            "Authorization": 'JWT '+this.props.user.token,
    }

        
    }


    /** GET AGENTS LIST */
    agentList = async () => {
        try{
        let agentListOpt = []
        await servicePost('agent/getAgentForTeam',{},this.headers)
            .then((res) => {
                if(res.status == 1){
                    
                    for( var l=0; l<res.data.length; l++ ){
                        agentListOpt.push({label: res.data[l].name, value: res.data[l]._id});
                    }
                }
                this.setState({
                    agentListOpt: agentListOpt,

                })
            })
            .catch((err)=> {
                console.log(err);
            })
        }catch(err){
            console.log(err);
        }
    }

    

    /**
     * Handles the submit
     */
    handleSubmit = (event, values) => {
        event.preventDefault();
        try{
            this.setState({ 
                isProcessing:true 
            })

            let successMessage = '';
            if( values.teamId != '' ){
                successMessage = 'Updating Team'
            }else{
                successMessage = 'Creating Team'
            }

            let data = {
                teamName: values.teamName,
                teamLead: values.teamLead,
                selectAgent: this.state.selectedAgentList,
                teamId: values.teamId
            }
        
            this.setState({
                teamError: 0
            })
        
            servicePost('team/addTeam',data,this.headers)
            .then((res) => {
                
                if(res.status == 1){
                    toast( successMessage ,{bodyClassName:'success-toast'});
                    this.props.toggle()
                    this.props.view()
                    
                } else if(res.status == 2){
                    this.setState({
                        teamError: 2,
                        errorMesg: res.error
                    })
                    // toast(res.error,{bodyClassName:'error-toast'}); 
                } else if(res.status == 0){
                    this.setState({
                        teamError: 1
                    })
                    // toast(res.error,{bodyClassName:'error-toast'}); 
                } else {
                    toast('Something went wrong',{bodyClassName:'error-toast',hideProgressBar: true,}); 
                }
                this.setState({
                    isProcessing: false
                })

            })
            .catch((err)=> {
                console.log(err);
                toast('Something went wrong',{bodyClassName:'error-toast',hideProgressBar: true,}); 
            })
        }catch(err){
            console.log(err);
            toast('Something went wrong',{bodyClassName:'error-toast',hideProgressBar: true,}); 
        }
    }

    componentDidMount = async () => {
        this.agentList()
        }

    onChangeAgentList = async (selectedAgent) => {

        // console.log('selectedList',selectedAgent);
        this.setState({
            selectedAgentList: selectedAgent 
        })
    }

    render(){
        let teamData = {teamName: '', teamLead: '', agents: '', teamId: ''}
        if(this.props.data){
            teamData = {
                teamName: this.props.data.teamName,
                teamLead: this.props.data.teamLead,
                agents: this.props.data.assignedAgent,
                teamId: this.props.data._id,
            }
        }
        return(
            <React.Fragment>
                <Card>
                    <CardBody>
                        <AvForm onValidSubmit={this.handleSubmit}>
                            <AvGroup row>
                                <Col sm={12}>
                                    <Label for="example">Team Name</Label>
                                    <AvInput type="text" name="teamName" id="teamName" value={ teamData.teamName } autoComplete="false" placeholder="Enter Team Name" required/>
                                    {this.state.teamError == 1 && <React.Fragment>
                                        <span  style={{ color: 'red', fontWeight: 'normal' }} > Team already exits </span>
                                    </React.Fragment>}
                                    
                                    
                                </Col>
                            </AvGroup>

                            <AvGroup row>
                                <Col sm={12}>
                                    <Label for="example">Team Lead</Label>
                                    <AvInput type="text" name="teamLead" id="teamLead" value={ teamData.teamLead } autoComplete="false" placeholder="Enter Team Lead" required/>
                                </Col>
                            </AvGroup>
                            
                            <Row>
                                <Col sm={12}>
                                <label for="example">Assign Agents</label>
                                <Select
                                    onChange={this.onChangeAgentList}
                                    value={this.state.selectedAgentList}
                                    isMulti={true}
                                    options={this.state.agentListOpt}
                                    className="react-select"
                                    classNamePrefix="react-select"
                                    placeholder={'Assign Agents'}
                                />                                    
                                {this.state.teamError == 2 && <React.Fragment>
                                        <span  style={{ color: 'red', fontWeight: 'normal' }} > {this.state.errorMesg} </span>
                                    </React.Fragment>}
                                </Col>
                            </Row>
                            <br/>
                            <Row>
                                <Col sm={6} >
                                    <AvInput type="hidden" name="teamId" id="teamId" autoComplete="false" value={ teamData.teamId } />
                                    <Button onClick={this.props.toggle} style={{float: 'right'}} className="btn btn-primary cancel-btn" type="button">
                                        Cancel
                                    </Button>
                                </Col>
                                <Col sm={6}>
                                    <Button color="primary" type="submit" disabled={this.state.isProcessing}>
                                        {`${(this.props.bName)? this.props.bName : 'Create Team'}`}
                                    </Button>
                                </Col>
                            </Row>
                            {this.state.isSuccess && <React.Fragment>
                                <AvGroup row>
                                    {this.state.message}
                                </AvGroup>
                            </React.Fragment>}
                        </AvForm>
                    </CardBody>
                </Card>
            </React.Fragment>
        )
    }
}

const mapStateToProps = (state) => {
    // const { user, loading, error } = state.Auth;
    return state.Auth;
};
export default connect(mapStateToProps)(AddTeam);