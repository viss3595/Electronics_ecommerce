import React, { Component } from 'react';
import { Row, Col, Form, FormGroup, Label, Input, FormText, Button, Card, CardBody } from 'reactstrap';
import { servicePost } from "./../../../helpers/api";
import { AvForm, AvGroup, AvInput, AvFeedback } from 'availity-reactstrap-validation';
import { connect } from 'react-redux';
import { toast } from 'react-toastify';

class AddMoment extends Component {
    constructor(props){
        super(props);

        this.state = {
            isSuccess: false,
            message: '',
            isShow: false,
            options:false,
            required:true,
            isProcessing : false
            // tableRecords: this.props.tableRow
        }
        this.handleSubmit = this.handleSubmit.bind(this);
    }
        /**
     * Handles the submit
     */
    handleSubmit = (event, values) => {
        event.preventDefault();

        this.setState({
            isProcessing : true
        })

        let data = {
            momentName: values.momentName,
            momentDesc: values.momentDesc,
            momentGroupId:values.momentGroupId,
            momentGroup:values.momentGroup,
            themeId: values.themeID,
            momentKeywords: values.momentKeywords,
            momentID: values.momentID,
            userId:this.props.user.id,
        }

        console.log(data);
        // return false;
      
        let headers= {
            "Content-Type": 'application/json',
            "Authorization": 'JWT '+this.props.user.token,
        }
   
        try{
            if(values.submitType == '1'){
                servicePost('moments/edit',data,headers)
                .then((res) => {
                    if(res.status == 1){
                        this.setState({
                            isSuccess: true,
                            message: 'Moment Updated.',
                            isProcessing : false
                        })
                        // this.props.tableRow= res.data
                        this.props.toggle()
                        this.props.view()
                        toast('Updating the Moment...',{bodyClassName:'success-toast'});                                    
                    }
                })
                .catch((err)=> {
                    this.setState({
                        isProcessing : false
                    })
                    console.log(err);
                    toast('Something went wrong',{bodyClassName:'error-toast',hideProgressBar: true,}); 
                })
            }
            if(values.submitType == '0'){
            servicePost('moments/add',data,headers)
            .then((res) => {
                if(res.status == 1){
                    this.setState({
                        isSuccess: true,
                        message: 'Moment created.',
                        isProcessing : false
                    })
                    // this.props.tableRow= res.data
                    toast('Moment added successfully',{bodyClassName:'success-toast'});
                    this.props.toggle()
                    this.props.view()                                   
                }
            })
            .catch((err)=> {
                this.setState({
                    isProcessing : false,
                    isSuccess: false,
                    message: 'Moment name already exist.',
                }) 
                console.log(err);
                toast('Something went wrong',{bodyClassName:'error-toast',hideProgressBar: true,}); 
            })
        }
        }catch(err){
            console.log(err);
        }
    }

    appendInput() {
        this.setState({
            isShow: true
        });
    }

    removeInput() {
        this.setState({
            isShow: false
        });
    }

    onKeyUpValue(event) {
        const groupValue = event.target.value;
        if (typeof groupValue !== 'undefined' && groupValue !== null) {
            this.setState({
                required: false,
            })
        }
    }

    getMomentGroupByUser=()=>{
        try{
            let headers= {
                "Content-Type": 'application/json',
                "Authorization": 'JWT '+this.props.user.token,
            };
            servicePost('moments/group/user',{ id: this.props.user.id, themeId: this.props.themeId },headers)
            .then((res) => {
                if(res.data.length > 0)
                {
                    this.setState({
                        options: res.data,
                    })
                }

            })
            .catch((err)=> {
                console.log(err);
            })
        }catch(err){
            console.log(err);
        }
    }

    componentDidMount() {
        this._isMounted = true;
        try{
            this.getMomentGroupByUser()
        }catch(err){
            console.log(err);
        }
    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    render(){
        let momentData ={momentName:'', momentDesc:'',momentKeywords:'',submitType:'0',momentID:''}

        if(this.props.data){
            momentData = {
                momentName: this.props.data.momentName,
                momentDesc: this.props.data.momentDesc,
                momentKeywords: this.props.data.momentKeywords,
                submitType: '1',
                momentID: this.props.data._id,
                momentGroupId: this.props.data.momentGroupId,
            }

        }
        return(
            <React.Fragment>
                <Card>
                    <CardBody> 
                    <AvForm onValidSubmit={this.handleSubmit}>

                            <AvGroup row>
                                <Col sm={11}>
                                    <Label for="example">Moment Name</Label>
                                    <AvInput type="text" name="momentName" id="momentName" value={momentData.momentName} autoComplete="false" placeholder="Moment Name" required />
                                    <AvInput type="hidden" name="submitType" value={momentData.submitType} />
                                    <AvInput type="hidden" name="momentID" value={momentData.momentID} />
                                    <AvInput type="hidden" name="themeID" value={this.props.themeId} />
                                </Col>
                                {!this.state.isSuccess && <React.Fragment>
       
                                <Col sm={'11 pl-3 error' }>{this.state.message}</Col>
        
                            </React.Fragment>}
                                {/* <AvFeedback>This field is invalid</AvFeedback> */}
                            </AvGroup>

                            <AvGroup row>
                                <Col sm={11}>
                                    <Label for="example">Moment Desc</Label>
                                    <AvInput type="text" name="momentDesc" value={momentData.momentDesc} id="momentDesc" autoComplete="false" placeholder="Moment Desc" />
                                </Col>
                            </AvGroup>

                            {this.state.options && <React.Fragment>
                             
                             <AvGroup row>
                                 <Col sm={11}>
                                 {/* With select and AvField */}
                                     <Label for="example">Assign to Moment Group</Label>
                                    {this.state.required && <React.Fragment>
                                        <AvInput type="select" name="momentGroupId" class="mb-0" value={momentData.momentGroupId} required>
                                            <option value="0">Assign to Moment Group</option>
                                            {this.state.options.map((data, index) => {
                                            return <option value={data._id}>{data.groupName}</option>
                                            })}
                                        </AvInput>
                                    </React.Fragment>}
                                    {!this.state.required && <React.Fragment>
                                        <AvInput type="select" name="momentGroupId" class="mb-0" value={momentData.momentGroupId}>
                                            <option value="0">Assign to Moment Group</option>
                                            {this.state.options.map((data, index) => {
                                            return <option value={data._id}>{data.groupName}</option>
                                            })}
                                        </AvInput>
                                    </React.Fragment>}
                                     
                                 </Col>
                                 {!this.state.isShow && <React.Fragment>
                                 <Col sm={'1 pt-4 mt-2'}><i class="uil uil-plus-circle font-size-22" onClick={ () => this.appendInput() }></i></Col>
                                 </React.Fragment>}
 
                                 {this.state.isShow && <React.Fragment>
                                 <Col sm={'1 pt-4 mt-2'}><i class="uil uil-minus-circle font-size-22" onClick={ () => this.removeInput() }></i></Col>
                                 </React.Fragment>}
 
                             </AvGroup>
                              </React.Fragment>}
             
                             
                             {this.state.isShow && <React.Fragment>
                                 <AvGroup row>
                                 <Col sm={'11' }><AvInput type="text" name="momentGroup" onKeyUp={this.onKeyUpValue.bind(this)} value='' autoComplete="false" placeholder="Add Moment Group" required/></Col>
                                 </AvGroup>
                             </React.Fragment>}
 
                             {!this.state.options && <React.Fragment>
                                 <AvGroup row>
                                 <Col sm={'11' }><AvInput type="text" name="momentGroup" onKeyUp={this.onKeyUpValue.bind(this)} value='' autoComplete="false" placeholder="Add Moment Group" required/></Col>
                                 </AvGroup>
                             </React.Fragment>}

                            <AvGroup row>
                                <Col sm={11}>
                                <Label for="example">Keywords</Label>
                                <AvInput type="textarea" name="momentKeywords" value={momentData.momentKeywords} id="momentKeywords" autoComplete="false" placeholder="Add one keywords/phrase/sentence per line" required/>
                                </Col>
                            </AvGroup>
                            <AvGroup row>
                                <Col sm={5} >
                                    <Button onClick={this.props.toggle} style={{float: 'right'}} className="btn btn-primary cancel-btn" type="button">
                                        Cancel
                                    </Button>
                                </Col>
                                <Col sm={6}>
                                    <Button disabled={this.state.isProcessing} color="primary" type="submit">
                                    { this.props.bName == 'Update Moment' && <React.Fragment>
                                            Update Moment
                                        </React.Fragment>}
                                        { this.props.bName != 'Update Moment' && <React.Fragment>
                                            Create Moment
                                        </React.Fragment>}
                                    </Button>
                                </Col>
                            </AvGroup>
                            {this.state.isSuccess && <React.Fragment>
                                <AvGroup row>
                                    {this.state.message}
                                </AvGroup>
                            </React.Fragment>}
                            
                            
                        </AvForm>
                    </CardBody>
                </Card>
            </React.Fragment>
        )
    }
};
const mapStateToProps = (state) => {
    // const { user, loading, error } = state.Auth;
    return state.Auth;
};
export default connect(mapStateToProps)(AddMoment);