import React, { Component } from 'react';
import { Row, Col, Alert, Button, Card, CardBody,Label } from 'reactstrap';
import { AvForm, AvGroup, AvInput, AvFeedback } from 'availity-reactstrap-validation';
import { servicePost } from "./../../../helpers/api";
import { connect } from 'react-redux';
import { toast } from 'react-toastify';
import Select from 'react-select';

class AddAgent extends Component {
    constructor(props){
        super(props);

        this.state = {
            isSuccess: false,
            message: '',
            error: false,
            errorMessage: '',
            errorColor: '',
            listTeam: '',
            selectedTeam: '',
            assignTeam: (this.props.data.team.length != 0)? { label:  this.props.data.team[0].teamName,  value:  this.props.data.team[0]._id} : '',            
            // tableRecords: this.props.tableRow
            isProcessing: false
        }
        this.handleSubmit = this.handleSubmit.bind(this);

        // HEADERS
        this.headers= {
            "Content-Type": 'application/json',
            "Authorization": 'JWT '+this.props.user.token,
        }

    }

    removePopUp = (seconds) => {
        setTimeout(() => {
            this.props.toggle()
            this.props.view()
        },seconds)
    }

    componentDidMount = () => {
        this.getAllTeam();
    }
    
    
    /**GET TEAM LIST */
    getAllTeam = async () => {
        try{
            let listTeamOpt=[];
            servicePost('team/getTeams',{},this.headers)
                .then((res) => {
                    if(res.status == 1){
                        for( var l=0; l<res.data.length; l++ ){
                            listTeamOpt.push({label: res.data[l].teamName, value: res.data[l]._id});
                        }
                    }
                    this.setState({
                        listTeam: listTeamOpt,
    
                    })
                })
                .catch((err)=> {
                    console.log(err);
                })
            }catch(err){
                console.log(err);
            }
    }


    /**
     * Handles the submit
     */
    handleSubmit = (event, values) => {
        event.preventDefault();
        let data = {
            agentEmail: values.agentEmail,
            agentName: values.agentName,
            agentRole: 'sales',
            selectTeam: this.state.selectedTeam,
            agentPassword: '1234567890',
            agentID: values.agentID,
            updateType: values.updateType,
        }
        try{
            this.setState(
                {
                    isProcessing:true
                }
            )
            if(values.submitType == '1'){
                servicePost('agent/editAgent',data,this.headers)
                .then((res) => {
                    if(res.status == 1){
                        this.setState(
                            {
                                isProcessing:false
                            }
                        )
                        // this.setState({
                        //     isSuccess: true,
                        //     errorMessage: 'Agent Updated.',
                        //     error: true,
                        //     errorColor: 'success'
                        // })
                        // this.props.tableRow= res.data
                        toast( 'Updating Agent' ,{bodyClassName:'success-toast'});
                        // this.removePopUp(2000);   
                        this.props.toggle()
                        this.props.view()
                    }
                })
                .catch((err)=> {
                    console.log(err);
                    // this.setState({
                    //     isSuccess: true,
                    //     errorMessage: 'Internal server error. Please try again later',
                    //     error: true,
                    //     errorColor: 'danger'
                    // })
                    toast('Internal server error. Please try again later',{bodyClassName:'error-toast', hideProgressBar: true,}); 
                    this.removePopUp(2000);
                })
            }
            if(values.submitType == '0'){
                servicePost('agent/addAgent',data,this.headers)
                .then((res) => {
                    if(res.status == 1){
                        this.setState(
                            {
                                isProcessing:false
                            }
                        )
                        // this.setState({
                        //     isSuccess: true,
                        //     errorMessage: 'Agent created.',
                        //     error: true,
                        //     errorColor: 'success'
                        // })
                        // this.props.tableRow= res.data
                        toast( 'Creating Agent' ,{bodyClassName:'success-toast'});
                        // this.removePopUp(2000);
                        this.props.toggle()
                        this.props.view()
                                                            
                    }
                    if(res.status == 2){
                        // this.setState({
                        //     isSuccess: true,
                        //     errorMessage: res.error,
                        //     error: true,
                        //     errorColor: 'danger'
                        // })
                        this.setState(
                            {
                                isProcessing:false
                            }
                        )
                        toast("Your plan allows addition of maximum "+res.data.countAgents+" agents. Please contact your account manager at abc@peter.com to upgrade the limit.",{bodyClassName:'error-toast', hideProgressBar: true,}); 
                        //this.removePopUp(3000);
                    }
                })
                .catch((err)=> {
                    console.log(err);
                    this.setState({
                        isSuccess: true,
                        errorMessage: 'Internal server error. Please try again later',
                        error: true,
                        errorColor: 'danger',
                        isProcessing:false
                    })
                    toast('Internal server error. Please try again later',{bodyClassName:'error-toast', hideProgressBar: true,});
                })
            }
        }catch(err){
            console.log(err);
        }
    }

    onChangeTeamList = async (selectedValue) => {
        this.setState({
            selectedTeam: selectedValue.value,
            assignTeam: selectedValue
        })
    }

    render(){
        let agentData ={email:'', name:'',team:'',submitType:'0',agentID:''}
        if(this.props.data){
            agentData = {
                email: this.props.data.email,
                name: this.props.data.name,
                // team: { label:  this.props.data.team[0].teamName,  value:  this.props.data.team[0]._id,},
                submitType: (this.props.data._id) ? '1':'0',
                agentID: this.props.data._id
            }
            
            // this.setState({
            //     assignTeam: ,
            // })
        }
        

        return(
            <React.Fragment>
                <Card>
                    <CardBody>
                        <AvForm onValidSubmit={this.handleSubmit}>
                            {this.props.typeForm == 'edit' && <React.Fragment>
                                <AvGroup row>
                                    <Col sm={12}>
                                        <Label for="example">Full Name</Label>
                                        <AvInput type="text" name="agentName" value={agentData.name} id="agentName" autoComplete="false" placeholder="Enter Full Name" required />
                                        
                                    </Col>
                                    <AvFeedback>This field is invalid</AvFeedback>
                                </AvGroup>

                                <AvGroup row>
                                    <Col sm={12}>
                                    <Label for="example">Email</Label>
                                        <AvInput type="email" required value={agentData.email}  name="agentEmail" id="agentEmail" autoComplete="false" placeholder="Enter Email ID" />
                                    </Col>
                                </AvGroup>

                                <Row>
                                    <Col sm={12}>
                                    <Label for="example">Assign to Team</Label>
                                    <Select
                                        onChange={this.onChangeTeamList}
                                        value={this.state.assignTeam}
                                        // isMulti={true}
                                        options={this.state.listTeam}
                                        className="react-select"
                                        classNamePrefix="react-select"
                                        placeholder={'Select a Team'}
                                    />
                                    </Col>
                                </Row>
                                <AvGroup row>
                                    <Col sm={12}>
                                    <Label for="example">Role</Label>
                                        <AvInput type="text" name="agentRole" id="agentRole" autoComplete="false" value="Sales Rep" readOnly disabled />
                                        <AvInput type="hidden" name="updateType" value='0' />
                                    </Col>
                                </AvGroup>                            
                            </React.Fragment>}

                            {this.props.typeForm == 'team' && <React.Fragment>
                                <AvGroup row>
                                    <Col sm={12}>
                                        <Label for="example">Assign to Team</Label>
                                        <Select
                                            onChange={this.onChangeTeamList}
                                            value={this.state.assignTeam}
                                            // isMulti={true}
                                            options={this.state.listTeam}
                                            className="react-select"
                                            classNamePrefix="react-select"
                                            placeholder={'Select a Team'}
                                        />
                                    </Col>
                                </AvGroup>
                                <AvInput type="hidden" name="updateType" value="1" />
                            </React.Fragment>}
                            
                            <AvGroup row>
                                <Col sm={6} >
                                    <Button onClick={this.props.toggle} style={{float: 'right'}} className="btn btn-primary cancel-btn" type="button">
                                        Cancel
                                    </Button>
                                </Col>
                                <Col sm={6}>
                                    <AvInput type="hidden" name="submitType" value={agentData.submitType} />
                                    <AvInput type="hidden" name="agentID" value={agentData.agentID} />
                                    <AvInput type="hidden" name="addedBy" value={this.props.user.id} />
                                    <Button color="primary" type="submit" disabled={this.state.isProcessing}>
                                        { this.props.bName == 'Update Agent' && <React.Fragment>
                                            Update Agent
                                        </React.Fragment>}
                                        { this.props.bName != 'Update Agent' && <React.Fragment>
                                            Create Agent
                                        </React.Fragment>}
                                    </Button>
                                </Col>
                            </AvGroup>
                            {this.state.isSuccess && <React.Fragment>
                                <AvGroup row style={{textAlign:'center'}}>
                                    <Col sm={12}>
                                        {this.state.message}
                                        {this.state.error && <Alert color={this.state.errorColor} isOpen={this.state.error ? true : false}>
                                            <div>{this.state.errorMessage}</div>
                                        </Alert>}
                                    </Col>
                                </AvGroup>
                            </React.Fragment>}
                            
                        </AvForm>
                    </CardBody>
                </Card>
            </React.Fragment>
        )
    }
}

const mapStateToProps = (state) => {
    // const { user, loading, error } = state.Auth;
    return state.Auth;
};
export default connect(mapStateToProps)(AddAgent);