import React, { Component } from 'react';
import { Row, Col, Form, FormGroup, Label, Input, FormText, Button, Card, CardBody } from 'reactstrap';
import { AvForm, AvGroup, AvInput, AvFeedback, AvField } from 'availity-reactstrap-validation';
import { servicePost } from "./../../helpers/api";
import ReactMultiSelectCheckboxes from 'react-multiselect-checkboxes';
import { connect } from 'react-redux';
import { toast } from 'react-toastify';
import Select from 'react-select';
class AddTeam extends Component {
    constructor(props){
        super(props);

        this.state = {
            isSuccess: false,
            message: '',
            agentListOpt: '',
            selectLibrary: '',
            teamError: 0,
            libraryName: ''
            // tableRecords: this.props.tableRow
        }
        this.handleSubmit = this.handleSubmit.bind(this);
        // HEADERS
        this.headers= {
            "Content-Type": 'application/json',
            "Authorization": 'JWT '+this.props.user.token,
    }

        
    }


    /** GET AGENTS LIST */
    agentList = async () => {
        try{
        let agentListOpt = []
        await servicePost('api/v1/library/getLibraryList',{},this.headers)
            .then((res) => {
                if(res.status == 1){
                    
                    for( var l=0; l<res.data.length; l++ ){
                        agentListOpt.push({label: res.data[l].libraryName, value: res.data[l]._id});
                    }
                }
                this.setState({
                    agentListOpt: agentListOpt,

                })
            })
            .catch((err)=> {
                console.log(err);
            })
        }catch(err){
            console.log(err);
        }
    }

    

    /**
     * Handles the submit
     */
    handleSubmit = async (event, values) => {
        event.preventDefault();
        try{
            let successMessage = '';

            let data = {
                libraryName: (this.state.libraryName)? this.state.libraryName: values.libraryName,
                callId: values.callId,
                libraryComment: values.libraryComments
            }
        
           await servicePost('api/v1/library/addCallLibrary',data,this.headers)
            .then((res) => {
                
                
                if(res.status == 1){
                    toast( 'Added to Library' ,{bodyClassName:'success-toast'});
                    this.props.toggle()
                    if( values.callId == '' ){
                        this.props.view()
                    }
                    
                }else if(res.status == 0){                    
                    toast(res.error,{bodyClassName:'error-toast',hideProgressBar: true,}); 
                }else {
                    toast('Something went wrongg',{bodyClassName:'error-toast',hideProgressBar: true,}); 
                }

            })
            .catch((err)=> {
                console.log(err);
                toast('Something went wrong',{bodyClassName:'error-toast',hideProgressBar: true,}); 
            })
        }catch(err){
            console.log(err);
            toast('Something went wrong',{bodyClassName:'error-toast',hideProgressBar: true,}); 
        }
    }

    componentDidMount = async () => {
        this.agentList()
        }

    onChangeLibraryList = async (selectedValue) => {
        console.log('selectedList',selectedValue);
        this.setState({
            libraryName: selectedValue[0].label,
            selectLibrary: selectedValue 
        })
    }

    appendInput() {
        this.setState({
            isShow: true
        });
    }

    removeInput() {
        this.setState({
            isShow: false
        });
    }

    render(){
        let teamData = {teamName: '', teamLead: '', agents: '', teamId: ''}
        if(this.props.data){
            teamData = {
                teamName: this.props.data.teamName,
                teamLead: this.props.data.teamLead,
                agents: this.props.data.assignedAgent,
                teamId: this.props.data._id,
            }
        }
        return(
            <React.Fragment>
                <Card>
                    <CardBody>
                        <AvForm onValidSubmit={this.handleSubmit}>
                            {this.props.callId != '' && <React.Fragment>
                            <AvGroup row>
                                <Col sm={11}>
                                <label for="example">Select an existing Playlist</label>
                                <Select
                                    onChange={this.onChangeLibraryList}
                                    // value={this.state.selectedAgentList}
                                    isMulti={true}
                                    options={this.state.agentListOpt}
                                    className="react-select"
                                    classNamePrefix="react-select"
                                    placeholder={'Select an existing Playlist'}
                                />
                                </Col>
                                <Col sm={1}>
                                    {!this.state.isShow && <React.Fragment>
                                    <Col sm={'1 pt-4 mt-2'}><i class="uil uil-plus-circle font-size-22" onClick={ () => this.appendInput() }></i></Col>
                                    </React.Fragment>}
    
                                    {this.state.isShow && <React.Fragment>
                                    <Col sm={'1 pt-4 mt-2'}><i class="uil uil-minus-circle font-size-22" onClick={ () => this.removeInput() }></i></Col>
                                    </React.Fragment>}
                                 </Col>
                            </AvGroup>
                            {this.state.isShow && <React.Fragment>
                            <AvGroup row>  
                                <Col sm={11}>                              
                                    <Label for="example">Create a new Playlist</Label>
                                    <AvInput type="text" name="libraryName" id="libraryName" value={ teamData.teamName } autoComplete="false" placeholder="Create a new Playlist" />
                                </Col>
                            </AvGroup>
                            </React.Fragment>}
                            <AvGroup row>
                                <Col sm={11}>
                                    <Label for="example">Call comments</Label>
                                    <AvInput type="text" name="libraryComments" id="libraryComments" value={ teamData.teamName } autoComplete="false" placeholder="Add comments for easy identification" />
                                </Col>
                            
                            </AvGroup>
                            </React.Fragment>}
                            
                            {this.props.callId == '' && <React.Fragment>
                            <AvGroup row>  
                                <Col sm={11}>                              
                                    <Label for="example">Create a new Playlist</Label>
                                    <AvInput type="text" name="libraryName" id="libraryName" value={ teamData.teamName } autoComplete="false" placeholder="Create a new Playlist" />
                                </Col>
                            </AvGroup>
                            </React.Fragment>}                            
                            <AvInput type="hidden" name="callId" id="callId" autoComplete="false" value={ this.props.callId } />
                            <AvGroup row>                            
                                <Col sm={6} >                                    
                                    <Button onClick={this.props.toggle} style={{float: 'right'}} className="btn btn-primary cancel-btn" type="button">
                                        Cancel
                                    </Button>
                                </Col>
                                <Col sm={6}>
                                    <Button color="primary" type="submit">
                                        {`${(this.props.bName)? this.props.bName : 'Save'}`}
                                    </Button>
                                </Col>
                            </AvGroup>
                            {this.state.isSuccess && <React.Fragment>
                                <AvGroup row>
                                    {this.state.message}
                                </AvGroup>
                            </React.Fragment>}
                        </AvForm>
                    </CardBody>
                </Card>
            </React.Fragment>
        )
    }
}

const mapStateToProps = (state) => {
    // const { user, loading, error } = state.Auth;
    return state.Auth;
};
export default connect(mapStateToProps)(AddTeam);