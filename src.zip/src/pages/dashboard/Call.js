import React, { Component } from 'react';
import {
    Row,
    Col,
    Card,
    CardBody,
    Table,
    Badge,
    Button,
    UncontrolledTooltip,
    Modal,
    ModalHeader,
    ModalBody,
    NavLink,
    Collapse,
    CardHeader,
    Nav,
    NavItem,
    TabContent,
    TabPane,
    Progress,
} from 'reactstrap';
import { AvForm, AvGroup, AvInput, AvFeedback, AvField } from 'availity-reactstrap-validation';

import PageTitle from '../../components/PageTitle';
import { getLoggedInUser } from '../../helpers/authUtils';
import Loader from '../../components/Loader';
import { connect } from 'react-redux';
import 'react-tippy/dist/tippy.css';
import { Tooltip } from 'react-tippy';
import TimeChart from './../charts/timeSeriesChart';
import classnames from 'classnames';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { servicePost } from './../../helpers/api';
import * as FeatherIcon from 'react-feather';
import { dateFormat } from './../../helpers/common';
import Moment from 'react-moment';
import { toast } from 'react-toastify';

import { EditorState, convertToRaw, ContentState } from 'draft-js';
import { Editor } from 'react-draft-wysiwyg';
import draftToHtml from 'draftjs-to-html';
import htmlToDraft from 'html-to-draftjs';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import { caseInsensitiveSubStrMatch } from './../../helpers/common';
import { Play } from 'react-feather';
import { Document, Packer, Paragraph, HeadingLevel, TextRun, saveAs } from 'docx';
import RegexEscape from 'regex-escape';
import { Stage, Layer, Rect, Text, Circle, Line } from 'react-konva';
import { SERVICE_URL } from './../../constants/utility';
import socketIOClient from 'socket.io-client';
const { randomHexColorWithArray } = require('random-hex-color-generator');

let colorList = randomHexColorWithArray(100);

let moment = require('moment');

require('moment-precise-range-plugin');

let ctx = null;
class Call extends React.Component {
    constructor(props) {
        super(props);
        const defaultPlayerRect = { left: 0, width: 0 };
        this.frameMap = new Map();
        this.socket = socketIOClient(SERVICE_URL);
        this.processor = {};
        this.state = {
            user: getLoggedInUser(),
            activeTab: '1',
            activeChatDialog: null,
            chatMessages: '',
            loader: true,
            call: null,
            // MODAL
            modal: false,
            modalLibrary: false,
            // ACCORDION
            panel1: true,
            feedbackId: 0,
            editorState: EditorState.createEmpty(),
            isHidden: false,
            statistics: null,
            isStatisticsLoading: true,
            callDuration: null,
            searchResultsCount: null,
            searchResults: [],
            searchResultsIds: [],
            currentSelected: null,
            containerRect: defaultPlayerRect,
            timeDuration: -1,
            frame : -1,
            isPlaying: false,
            formFactor : 0,
            fps : 30
        };
        this.player = React.createRef();
        this.canvas = React.createRef();
        this.onEditorStateChange = this.onEditorStateChange.bind(this);
        this.getRectsInterval = undefined;

        if (!('requestVideoFrameCallback' in HTMLVideoElement.prototype)) {
            // The API is supported!
            alert("YOUR BROWSER DOESN'T SUPPORT LATEST VIDEO STANDARDS. PLEASE UPDATE!") 
          }
    }

    // Function to draw the rectangle in info we send x, y , w, h
    // style consists of border-color
    drawRect = (info, style = {}) => {
        // dynamically assign the width and height to canvas

        var canvas = document.getElementById('c1');

        var ctx = canvas.getContext('2d');
        var ctxImage = canvas.getContext('2d');

        const { x, y, w, h } = info;
        const { borderColor = 'black', borderWidth = 1 } = style;
        // ctxImage.drawImage(this.player, 0, 0, canvas.width, canvas.height);
        // const frame = ctxImage.getImageData(0, 0, canvas.width, canvas.height);
        // ctxImage.putImageData(frame, 0, 0);

        ctx.beginPath();
        ctx.strokeStyle = borderColor;
        ctx.lineWidth = borderWidth;
        ctx.rect(canvas.width * x, canvas.height * y, canvas.width * w, canvas.height * h);
        ctx.stroke();
    };

    drawBackground = () => {
        var canvas = document.getElementById('c1');

        var ctxImage = canvas.getContext('2d');
        ctxImage.drawImage(this.player, 0, 0, canvas.width, canvas.height);
        const frame = ctxImage.getImageData(0, 0, canvas.width, canvas.height);
        ctxImage.putImageData(frame, 0, 0);
    };

    // Function to clear the canvas
    clearRect = () => {
        // dynamically assign the width and height to canvas

        const canvasEle = document.getElementById('c1');
        ctx = canvasEle.getContext('2d');

        ctx.clearRect(0, 0, canvasEle.width, canvasEle.height);
        // get context of the canvas
    };

    // Function that renders frame for specific time duration
    renderFrames = (seconds) => {
        console.log(`Actual Duration : ${seconds}`);
        this.setState({
            timeDuration: Math.round(seconds * this.state.fps),
        });
        seconds = Math.round(seconds * this.state.fps);
        
        // For every change in time duration we clear the canvas
        this.clearRect();
        this.drawBackground();
        // For every frame found in map
        if (this.frameMap.has(Number(seconds))) {
            // We get the seconds
            let frameData = this.frameMap.get(Number(seconds));

            // Get the list of framedata values like all the different objects captured at that moment
            let frameList = Array.from(frameData.values());

            // Iterate over every object found
            frameList.map((f, index) => {
                if (typeof f.bbox === 'string') {
                    f.bbox = f.bbox.split(':');
                }

                // We draw the squares
                const r1Info = {
                    x: Number(f.bbox[0]),
                    y: Number(f.bbox[1]),
                    w: Number(f.bbox[2]),
                    h: Number(f.bbox[3]),
                };
                const r1Style = { borderColor: colorList[index], borderWidth: 2 };
                this.drawRect(r1Info, r1Style);

                return f;
            });
        }
    };

    drawCanvas = (now, metadata) => {
        // Print the frame
        console.log(`Video registered Frame ${Number(metadata.presentedFrames)}`);
        console.log();
         // For every change in time duration we clear the canvas
         this.clearRect();
         this.drawBackground();
         this.renderFrames(Number(metadata.presentedFrames));

         this.setState({
            frame :  Number(metadata.presentedFrames)
         })

        
        // Re-register the callback to be notified about the next frame.
        this.player.requestVideoFrameCallback(this.drawCanvas);
      };

    // Function retrieves the call data from API
    componentDidMount = async () => {
        try {
            let headers = {
                'Content-Type': 'application/json',
                Authorization: 'JWT ' + this.props.user.token,
            };
            let callData = await servicePost(
                'api/v1/analyse/get/call',
                { callId: this.props.match.params.callId },
                headers
            );

            callData.data.transcription.map((record, index) => {
                
                if(record.fps !== this.state.fps){
                    this.setState({
                        fps : record.fps
                    })
                }
                record.data.map((_transcript) => {
                    if (typeof _transcript === 'object') {
                        _transcript['frame_id'] = record.frame_id;
                        if (this.frameMap.has(record.frame_id)) {
                            let frameData = this.frameMap.get(record.frame_id);
                            if (!frameData.has(`${_transcript.type}:${_transcript.name}`)) {
                                frameData.set(`${_transcript.type}:${_transcript.name}`, _transcript);
                            }
                            this.frameMap.set(record.frame_id, frameData);
                        } else {
                            let dataMap = new Map();

                            this.frameMap.set(
                                record.frame_id,
                                dataMap.set(`${_transcript.type}:${_transcript.name}`, _transcript)
                            );
                        }
                    }
                });
            });

            // Socket functionality to map the data received in real-time
            this.socket.on('transcript', (data) => {
                if(data.fps !== this.state.fps){
                    this.setState({
                        fps : data.fps
                    })
                }
                data.data.map((_transcript) => {
                    if (typeof _transcript === 'object') {
                        _transcript['frame_id'] = data.frame_id;
                        if (this.frameMap.has(data.frame_id)) {
                            let frameData = this.frameMap.get(data.frame_id);
                            if (!frameData.has(`${_transcript.type}:${_transcript.name}`)) {
                                frameData.set(`${_transcript.type}:${_transcript.name}`, _transcript);
                            }
                            this.frameMap.set(data.frame_id, frameData);
                        } else {
                            let dataMap = new Map();

                            this.frameMap.set(
                                data.frame_id,
                                dataMap.set(`${_transcript.type}:${_transcript.name}`, _transcript)
                            );
                        }
                    }
                });
            });

            this.setState({
                call: callData.data.call,
                transcription: callData.data.transcription,
                loader: false,
            });
        } catch (error) {
            alert(error);
            console.log(error);
        }

        // Event fires when video meta data is loaded
        this.player.onloadedmetadata = () => {
        
            // Interval is made to keep checking the <video> tag size and update it
            this.getRectsInterval = setInterval(() => {
                let dimensions = this.player.getBoundingClientRect();
                // console.log(dimensions);

                this.setState({
                    containerRect: dimensions,
                });
            }, 100);


            this.setState({
                callDuration: this.player.duration.toFixed(0),
            });
        };

        // A function is mounted that listens to time update in audio file player
        this.player.addEventListener('timeupdate', (e) => {
            
            // Pauses the video when end is reached
            if(!isNaN(this.player.currentTime) && !isNaN(this.player.duration) && this.player.currentTime === this.player.duration){
                this.setState(
                    {
                        isPlaying: false,
                    },
                    () => {
                        this.player.pause();
                    }
                )
            }
            // On every time duration change we render Frames
            // this.renderFrames(Number(this.player.currentTime).toFixed(0));
        });

        let self = this;

       
            this.player.addEventListener(
            'play',
            (e) => {
                console.log('H');
                this.timerCallback();
                // On every time duration change we render Frames
                // this.renderFrames(Number(this.player.currentTime).toFixed(0));
            },
            false
        );
         
        
    };

    timerCallback = () => {
        if (this.player.paused || this.player.ended) {
            return;
        }
        // this.computeFrame();

        this.renderFrames(Number(this.player.currentTime));
        let self = this;
        setTimeout(function () {
            self.timerCallback();
        }, 0);
        
    };

    computeFrame = () => {
        let c1 = document.getElementById('c1');
        let ctx1 = c1.getContext('2d');
        ctx1.drawImage(this.player, 0, 0, c1.width, c1.height);
        const frame = ctx1.getImageData(0, 0, c1.width, c1.height);
        const length = frame.data.length;

        ctx1.putImageData(frame, 0, 0);
    };

    componentWillUnmount() {
        this.player.removeEventListener('timeupdate', () => {});
        clearInterval(this.getRectsInterval);
    }

    onEditorStateChange = (editorState) => {
        this.setState({
            editorState,
        });
        const body = draftToHtml(convertToRaw(editorState.getCurrentContent()));
        this.props.onEditorContentChange && this.props.onEditorContentChange(body);
        this.setState({
            body,
        });
    };

    // Function to render the table for object detection
    renderTable = () => {
        let m = [];

        if (this.frameMap.has(Number(this.state.timeDuration))) {
            let frameData = this.frameMap.get(Number(this.state.timeDuration));

            let frameList = Array.from(frameData.values());
            frameList.map((f, index) => {
                if (typeof f.bbox === 'string') {
                    f.bbox = f.bbox.split(':');
                }

                m.push(
                    <tr style={{ background: colorList[index], color: 'white' }} key={index}>
                        <td style={{ width: '20%' }} scope="row" className={'mt-2'}>
                            {f.frame_id}
                        </td>
                        <td style={{ width: '30%' }} className={'mt-2'}>
                            {f.type}
                        </td>
                        <td style={{ width: '30%' }} className={'mt-2'}>
                            {f.name}
                        </td>
                        <td style={{ width: '20%' }}>{f.score}</td>
                    </tr>
                );
                return f;
            });
        }
        return m;
    };

    render() {
        const height = this.props.height || '320px';

        // Until data from API is fetched
        if (this.state.loader) {
            return (
                <Row className="page-title mt-4">
                    <Col xl={12} md={12}>
                        <Loader />
                    </Col>
                </Row>
            );
        }
        var defSearchId = 0;

        let transcription = [];
        this.state.transcription.map((record, index) => {
            record.data.map((_transcript) => {
                if (typeof _transcript === 'object') {
                    _transcript['frame_id'] = record.frame_id;
                    transcription.push(_transcript);
                }
            });
        });

        return (
            <React.Fragment>
                <div className="">
                    {/* preloader */}

                    <Row className="page-title align-items-center">
                        <Col sm={8} xl={6}></Col>
                    </Row>

                    <Row>
                        <Col xl={12} md={12}>
                            <Card>
                                <CardBody>
                                    <Row>
                                        <Col
                                            className=""
                                            sm={12}
                                            xl={12}
                                            style={{ textAlign: 'center', pointerEvents: 'none' }}>
                                            <video
                                                ref={(ref) => (this.player = ref)}
                                                style={{
                                                    display : 'none',
                                                    width: '50%',
                                                    borderRadius: '0.3rem',
                                                    border: '8px solid #F3F4F7',
                                                    pointerEvents: 'auto',
                                                }}
                                                className="player mt-2"
                                                controls
                                                preload="auto"
                                                crossOrigin="anonymous"
                                                id="callvideo"
                                                >
                                                <source src={this.state.call.recordingUrl} />
                                            </video>
                                        </Col>
                                        <Col md={4}></Col>
                                        <Col md={12} style={{ textAlign: 'center' }}>
                                            <canvas
                                                id="c1"
                                                style={{
                                                    width: '480px',
                                                    height: 'auto',
                                                }}></canvas>
                                            <hr />
                                            <div style={{}}>
                                            <Tooltip
                                                    // options
                                                    title={`Fast Backward (10 Sec)`}
                                                    position="bottom"
                                                    trigger="mouseenter">
                                                    
                                                        <FeatherIcon.ChevronsLeft
                                                            onClick={(e) => {
                                                                this.player.currentTime -= 10
                                                            }}
                                                        />
                                                    
                                                    
                                                </Tooltip>

                                                <Tooltip
                                                    // options
                                                    title={`Backward (5 Sec)`}
                                                    position="bottom"
                                                    trigger="mouseenter">
                                                    
                                                        <FeatherIcon.ChevronLeft
                                                            onClick={(e) => {
                                                                this.player.currentTime -=  5
                                                            }}
                                                        />
                                                    
                                                    
                                                </Tooltip>
                                                <Tooltip
                                                    // options
                                                    title={`${this.state.isPlaying ? 'Pause' : 'Play'}`}
                                                    position="bottom"
                                                    trigger="mouseenter">
                                                    {this.state.isPlaying && (
                                                        <FeatherIcon.Pause
                                                            onClick={(e) => {
                                                                this.setState(
                                                                    {
                                                                        isPlaying: false,
                                                                    },
                                                                    () => {
                                                                        this.player.pause();
                                                                    }
                                                                );
                                                            }}
                                                        />
                                                    )}
                                                    {!this.state.isPlaying && (
                                                        <FeatherIcon.Play
                                                            onClick={(e) => {
                                                                this.setState(
                                                                    {
                                                                        isPlaying: true,
                                                                    },
                                                                    () => {
                                                                        this.player.play();
                                                                    }
                                                                );
                                                            }}
                                                        />
                                                    )}
                                                </Tooltip>
                                                <Tooltip
                                                    // options
                                                    title={`Forward (5 Sec)`}
                                                    position="bottom"
                                                    trigger="mouseenter">
                                                    
                                                        <FeatherIcon.ChevronRight
                                                            onClick={(e) => {
                                                                this.player.currentTime += 5
                                                            }}
                                                        />
                                                    
                                                    
                                                </Tooltip>
                                                <Tooltip
                                                    // options
                                                    title={`Fast Forward (10 Sec)`}
                                                    position="bottom"
                                                    trigger="mouseenter">
                                                    
                                                        <FeatherIcon.ChevronsRight
                                                            onClick={(e) => {
                                                                this.player.currentTime +=  10
                                                               
                                                            }}
                                                            
                                                        />
                                                    
                                                    
                                                </Tooltip>
                                            </div>
                                            <hr />
                                        </Col>
                                        <Col md={4}></Col>

                                        <Col md={12} className="mt-2">
                                            <Table hover responsive={true} className="mb-0" size="sm">
                                                <thead>
                                                    <tr>
                                                        <th style={{ width: '20%' }}>Frame No</th>
                                                        <th style={{ width: '30%' }}>Type</th>
                                                        <th style={{ width: '30%' }}>Name</th>
                                                        <th style={{ width: '20%' }}>Score</th>

                                                        {/* <th></th> */}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {this.renderTable().map((t) => {
                                                        return t;
                                                    })}
                                                </tbody>
                                            </Table>
                                        </Col>
                                    </Row>
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>
                </div>
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    // const { user, loading, error } = state.Auth;
    return state.Auth;
};

export default connect(mapStateToProps)(Call);
