import React, { Component } from 'react';
import {
    Row,
    Col,
    Card,
    CardBody,
    Table,
    Badge,
    Button,
    UncontrolledTooltip,
    Modal,
    ModalHeader,
    ModalBody,
    NavLink,
    Collapse,
    CardHeader,
    Nav,
    NavItem,
    TabContent,
    TabPane,
    Alert,
    Progress,
} from 'reactstrap';
import { AvForm, AvGroup, AvInput, AvFeedback, AvField } from 'availity-reactstrap-validation';

import PageTitle from '../../components/PageTitle';
import { getLoggedInUser } from '../../helpers/authUtils';
import Loader from '../../components/Loader';
import { connect } from 'react-redux';
import 'react-tippy/dist/tippy.css';
import { Tooltip } from 'react-tippy';
import TimeChart from '../charts/timeSeriesChart';
import classnames from 'classnames';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { servicePost } from '../../helpers/api';
import * as FeatherIcon from 'react-feather';
import { dateFormat } from '../../helpers/common';
import Moment from 'react-moment';
import { toast } from 'react-toastify';

import { EditorState, convertToRaw, ContentState } from 'draft-js';
import { Editor } from 'react-draft-wysiwyg';
import draftToHtml from 'draftjs-to-html';
import htmlToDraft from 'html-to-draftjs';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import { caseInsensitiveSubStrMatch } from '../../helpers/common';
import { Play } from 'react-feather';
import SlidingPanel from 'react-sliding-side-panel';

import AddModal from '../settings/AddModal';

import * as fs from 'fs';
import { Document, Packer, Paragraph, HeadingLevel, TextRun, saveAs } from 'docx';
import Container from 'reactstrap/lib/Container';

import logo from '../../assets/images/logo.png';
import Label from 'reactstrap/lib/Label';
import InputGroup from 'reactstrap/lib/InputGroup';
import InputGroupAddon from 'reactstrap/lib/InputGroupAddon';
import { Link } from 'react-router-dom';
import FormGroup from 'reactstrap/lib/FormGroup';

import FileUploader from './../../components/FileUploader';
import ModalFooter from 'reactstrap/lib/ModalFooter';
import CustomInput from 'reactstrap/lib/CustomInput';

let moment = require('moment');

require('moment-precise-range-plugin');

class Call extends React.Component {
    constructor(props) {
        super(props);

        let token = new URLSearchParams(props.location.search).get('token');

        console.log(token);

        this.state = {
            user: getLoggedInUser(),
            agents: [],
            activeTab: '1',
            activeChatDialog: null,
            chatMessages: '',
            loader: true,
            fileUploader: false,
            call: null,
            className: 'modal-dialog-centered',
            // MODAL
            modal: false,
            modalLibrary: false,
            // ACCORDION
            panel1: true,
            feedbackId: 0,
            editorState: EditorState.createEmpty(),
            isHidden: false,
            statistics: null,
            isStatisticsLoading: true,
            callDuration: null,
            jwtToken: token,
            selectedAgent: null,
            userEmail: null,
            companyLogo: null,
            calls: [],
            error: null,
            uploadComplete: false,
            // height,
            containerHeight: '75vh',
            detectionType: 'OBJECT',
        };
        this.player = React.createRef();
        this.toggle = this.toggle.bind(this);
        this.toggleModal = this.toggleModal.bind(this);
        this.toggleModalLibrary = this.toggleModalLibrary.bind(this);
        this.togglePanel = this.togglePanel.bind(this);
        this.onEditorStateChange = this.onEditorStateChange.bind(this);
    }

    /**
     * Toggle the tab
     */
    toggle = (tab) => {
        this.setState((prevState, props) => ({
            modal: !prevState.modal,
        }));
    };

    /**
     * Show/hide the modal
     */
    toggleModal = () => {
        this.setState((prevState) => ({
            modal: !prevState.modal,
        }));
    };

    /**
     * Show/hide the modal library
     */
    toggleModalLibrary = () => {
        this.setState((prevState) => ({
            modalLibrary: !prevState.modalLibrary,
        }));
    };

    togglePanel(panel) {
        var state = { ...this.state };
        state[panel] = !state[panel];
        this.setState(state);
    }

    componentDidMount = async () => {
        // this.getCallStatistics();
        try {
            let headers = {
                'Content-Type': 'application/json',
                Authorization: 'JWT ' + this.props.user.token,
            };
            let agentsData = await servicePost('agent/getAgents', {}, headers);
            console.log('fetching now');
            if (agentsData.data !== null) {
                this.setState({
                    agents: agentsData.data,
                    loader: false,
                    userEmail: agentsData.user.userEmail,
                    companyLogo: agentsData.user.companyLogo,
                    // editorState: EditorState.createWithContent(callData.data.callFeedback.userFeedback)
                });
            } else {
                this.setState({
                    agents: agentsData.data,
                    loader: false,
                    userEmail: agentsData.user.userEmail,
                    companyLogo: agentsData.user.companyLogo,
                });
            }
        } catch (error) {
            this.setState({
                loader: false,
            });
            console.log('fetching now');
            console.log(error);
        }
    };

    /**
     * Opens large modal
     */
    openModalWithSize = (size) => {
        this.setState({ size: size, className: null });
        this.toggleModal();
    };

    handleValidSubmit = async (event, values) => {
        console.log('submit valid');
        event.preventDefault();
        if (this.state.calls.length == 0) {
            alert('Please add Video Files');
            return;
        }
        this.setState({
            fileUploader: true,
            error: null,
        });
        // console.log('==editor',this.props.onEditorContentChange(body))
        let formData = new FormData();
        // Create instance of FileReader
        this.state.calls.forEach((call, index) => {
            formData.append(`call`, call);
        });
        formData.append('agentId', this.state.selectedAgent);
        formData.append('detectionType', this.state.detectionType);

        console.log(formData);
        try {
            let headers = {
                Authorization: 'JWT ' + this.props.user.token,
            };
            servicePost('upload-calls', formData, headers)
                .then((res) => {
                    this.setState({
                        fileUploader: false,
                        modal: true,
                        uploadComplete: true,
                        calls: [],
                    });
                })
                .catch((e) => {
                    console.log(e);
                    this.setState({
                        fileUploader: false,
                        modal: true,
                        error: e,
                    });
                });
        } catch (err) {
            console.log(err);
            this.setState({
                fileUploader: false,
                modal: true,
                error: err,
            });
        }
    };

    onEditorStateChange = (editorState) => {
        this.setState({
            editorState,
        });
        const body = draftToHtml(convertToRaw(editorState.getCurrentContent()));
        this.props.onEditorContentChange && this.props.onEditorContentChange(body);
        this.setState({
            body,
        });
    };

    toggleSlider = () => {
        this.setState({
            isHidden: !this.state.isHidden,
        });
    };

    // OPEN LIBRARY MODAL
    libModal = () => {
        this.setState({
            modalLibrary: true,
        });
    };

    pad(num) {
        return ('0' + num).slice(-2);
    }
    hhmmss(secs) {
        var minutes = Math.floor(secs / 60);
        secs = secs % 60;
        var hours = Math.floor(minutes / 60);
        minutes = minutes % 60;
        return `${this.pad(hours)}:${this.pad(minutes)}:${this.pad(secs)}`;
        // return pad(hours)+":"+pad(minutes)+":"+pad(secs); for old browsers
    }
    filterAgent = (e) => {
        console.log(e.target.value);
        if (e.target.value == '0') {
            return;
        }
        this.setState({
            selectedAgent: e.target.value,
        });
    };

    handleInvalidUpload = (val) => {
        this.setState({ invalidFile: val });
    };

    setContainerHeight = (val) => {
        this.setState({ containerHeight: val });
    };

    render() {
        return (
            <React.Fragment>
                {/* {this.state.loader && <Loader />} */}
                {/* <Row className="page-title">
                    <Col md={12}>
                        <PageTitle
                            breadCrumbItems={[{ label: 'Call Summary', path: '/call-summary', active: false },
                            { label: 'Call Analysis', path: '/analyse/calls', active: false },
                            { label: 'Call Name', path: '/analyse/calls', active: true }
                        ]}
                        />
                    </Col>
                </Row> */}
                <Container style={{ height: this.state.containerHeight }} className="call-upload-container">
                    {console.log(this.state)}
                    <Row>
                        <Col md={3}></Col>
                        <Col md={6}>
                            <Card className="mt-4">
                                <CardBody>
                                    <Row className="page-title">
                                        <Col style={{ textAlign: 'center' }} md={12}>
                                            {!this.state.loader ? (
                                                <img
                                                    src={!this.state.companyLogo ? logo : this.state.companyLogo}
                                                    alt=""
                                                    height="42"
                                                />
                                            ) : null}
                                            <h5 className="mt-4">Call Upload</h5>
                                            <p></p>
                                        </Col>
                                        <Col classnames="px-2" md={12}>
                                            <AvForm
                                                onValidSubmit={this.handleValidSubmit}
                                                className="authentication-form">
                                                <AvGroup className="">
                                                    <Label for="email">Admin Email Address</Label>
                                                    <InputGroup>
                                                        <InputGroupAddon addonType="prepend">
                                                            <span className="input-group-text">
                                                                <FeatherIcon.Mail className="icon-dual" />
                                                            </span>
                                                        </InputGroupAddon>
                                                        <AvInput
                                                            type="email"
                                                            name="email_address"
                                                            autocomplete="false"
                                                            id="email_address"
                                                            placeholder="Agent's Email Address"
                                                            value={this.state.userEmail}
                                                            disabled
                                                        />
                                                    </InputGroup>

                                                    <AvFeedback>This field is invalid</AvFeedback>
                                                </AvGroup>

                                                <AvGroup className="">
                                                    <Label for="email">Agent</Label>
                                                    <InputGroup>
                                                        <InputGroupAddon addonType="prepend">
                                                            <span className="input-group-text">
                                                                <FeatherIcon.Users className="icon-dual" />
                                                            </span>
                                                        </InputGroupAddon>

                                                        <AvInput
                                                            type="select"
                                                            onChange={this.filterAgent.bind(this)}
                                                            name="agent"
                                                            class="mb-0"
                                                            value={this.state.selectedAgent}
                                                            required>
                                                            <option value="0">Select Agent</option>
                                                            {this.state.agents.sort().map((data, index) => {
                                                                return <option value={data._id}>{data.name}</option>;
                                                            })}
                                                        </AvInput>
                                                    </InputGroup>

                                                    <AvFeedback>This field is invalid</AvFeedback>
                                                </AvGroup>
                                                <AvGroup>
                                                    <Label for="exampleCheckbox">Detection Type</Label>
                                                    <div>
                                                        <CustomInput
                                                            type="radio"
                                                            id="exampleCustomRadio"
                                                            name="DETECTION"
                                                            value="OBJECT"
                                                            checked={
                                                                this.state.detectionType === 'OBJECT' ? true : false
                                                            }
                                                            onChange={(e) => {
                                                                this.setState({
                                                                    detectionType: 'OBJECT',
                                                                });
                                                            }}
                                                            label="Objects"
                                                            inline
                                                        />
                                                        <CustomInput
                                                            type="radio"
                                                            id="exampleCustomRadio3"
                                                            name="DETECTION"
                                                            value="FACE"
                                                            onChange={(e) => {
                                                                this.setState({
                                                                    detectionType: 'FACE',
                                                                });
                                                            }}
                                                            checked={this.state.detectionType === 'FACE' ? true : false}
                                                            label="Faces"
                                                            inline
                                                        />
                                                    </div>
                                                </AvGroup>
                                                <div>
                                                    {!this.state.invalidFile ? null : (
                                                        <Alert color="danger">
                                                            {' '}
                                                            Not a valid file <br /> Please select file with format mp3,
                                                            wav & aac
                                                        </Alert>
                                                    )}
                                                </div>

                                                <AvGroup>
                                                    <FileUploader
                                                        uploadComplete={this.state.uploadComplete}
                                                        setUploadComplete={() => {
                                                            this.setState({ uploadComplete: false });
                                                        }}
                                                        setContainerHeight={this.setContainerHeight}
                                                        handleInvalidUpload={this.handleInvalidUpload}
                                                        onFileUpload={(files) => {
                                                            this.setState({
                                                                calls: files,
                                                            });
                                                        }}
                                                    />
                                                </AvGroup>
                                                {this.state.fileUploader && (
                                                    <Progress animated color="primary" className="mb-4" value="100" />
                                                )}

                                                <FormGroup className="form-group mb-0 text-center">
                                                    {this.state.fileUploader && (
                                                        <Button color="primary" disabled className="btn-block">
                                                            Uploading...
                                                        </Button>
                                                    )}
                                                    {!this.state.fileUploader && (
                                                        <Button color="primary" className="btn-block">
                                                            Submit
                                                        </Button>
                                                    )}
                                                </FormGroup>

                                                {/*
                                                    <Col className="col-12 pt-3 text-center">
                                                        <p className="text-muted">Don't have an account? <Link to="/register" className="text-primary font-weight-bold ml-1">Sign Up</Link></p>
                                                    </Col>
                                                    */}
                                            </AvForm>
                                        </Col>
                                    </Row>
                                </CardBody>
                            </Card>
                        </Col>
                        <Col md={3}></Col>
                    </Row>
                </Container>
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    // const { user, loading, error } = state.Auth;
    return state.Auth;
};

export default connect(mapStateToProps)(Call);
