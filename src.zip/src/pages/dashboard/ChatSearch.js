import React, { Component } from 'react';
import RegexEscape from 'regex-escape';

import { ChevronDown, ChevronUp, X } from 'react-feather';

class ChatSearch extends Component {
    constructor(props) {
        super(props);
        this.state = {
            searchString: '',
            indexDisplayed: 0,
            actualIndex: -1,
        };
    }
    componentDidMount = async () => {
        // let checkToken = await this.checkToken();
        // return checkToken;
    };

    render() {
        const {
            searchResultsCount,
            searchResults,
            handleChatSearchChange,
            seekToKeyword,
            handleCurrentSelected,
        } = this.props;
        var timestampArr = [];
        searchResults &&
            searchResults.map((res) => {
                var res = JSON.parse(res);
                var temp = res.text;
                var re = new RegExp(`${RegexEscape(this.state.searchString)}`, 'ig');

                var count = (temp.match(re) || []).length;
                for (var i = 0; i < count; i++) {
                    timestampArr.push({ time: res.start_time, iteration: i });
                }
            });
        return (
            <React.Fragment>
                <div className="cs-container">
                    <div className="left">
                        <form
                            onSubmit={(e) => {
                                e.preventDefault();
                            }}>
                            <input
                                style={{ color: '#6C757D' }}
                                placeholder="Search in chat"
                                onChange={(e) => {
                                    handleChatSearchChange(e.target.value);
                                    this.setState({ indexDisplayed: 0 });
                                    this.setState({ actualIndex: -1 });
                                    this.setState({ searchString: e.target.value });
                                }}
                                value={this.state.searchString}
                                type="text"
                            />
                        </form>
                    </div>
                    <div className="right">
                        {this.props.searchResultsCount ? (
                            <div className="count">
                                {this.state.indexDisplayed}/{searchResultsCount}
                            </div>
                        ) : this.state.searchString !== '' ? (
                            <div className="count">0/0</div>
                        ) : null}

                        <div className="buttons">
                            <ChevronUp
                                onClick={() => {
                                    if (this.state.indexDisplayed > 1) {
                                        this.setState({ indexDisplayed: this.state.indexDisplayed - 1 });
                                        seekToKeyword(timestampArr && timestampArr[this.state.actualIndex - 1].time);
                                        handleCurrentSelected(timestampArr && timestampArr[this.state.actualIndex - 1]);
                                        this.setState({ actualIndex: this.state.actualIndex - 1 });
                                    }
                                }}></ChevronUp>
                            <ChevronDown
                                onClick={() => {
                                    if (this.state.indexDisplayed < searchResultsCount) {
                                        this.setState({ indexDisplayed: this.state.indexDisplayed + 1 });
                                        seekToKeyword(timestampArr && timestampArr[this.state.actualIndex + 1].time);
                                        handleCurrentSelected(timestampArr && timestampArr[this.state.actualIndex + 1]);
                                        this.setState({ actualIndex: this.state.actualIndex + 1 });
                                    }
                                }}
                            />
                            <X
                                onClick={() => {
                                    handleChatSearchChange('');
                                    this.setState({ searchString: '', indexDisplayed: 0 });
                                }}
                            />
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default ChatSearch;

// import React, { Component } from 'react';
// import { ChevronDown, ChevronUp, X } from 'react-feather';

// class ChatSearch extends Component {
//     constructor(props) {
//         super(props);
//         this.state = {
//             searchString: '',
//             indexDisplayed: 0,
//         };
//     }
//     componentDidMount = async () => {
//         // let checkToken = await this.checkToken();
//         // return checkToken;
//     };

//     render() {
//         const {
//             searchResultsCount,
//             searchResults,
//             handleChatSearchChange,
//             seekToKeyword,
//             handleCurrentSelected,
//         } = this.props;
//         var timestampArr = [];
//         searchResults &&
//             searchResults.map((res) => {
//                 var res = JSON.parse(res);
//                 var temp = res.text;
//                 var re = new RegExp(`${this.state.searchString}`, 'ig');
//                 var count = (temp.match(re) || []).length;
//                 for (var i = 0; i < count; i++) {
//                     timestampArr.push({ time: res.start_time, iteration: i });
//                 }
//             });
//         return (
//             <React.Fragment>
//                 <div className="cs-container">
//                     <div className="left">
//                         <form
//                             onSubmit={(e) => {
//                                 e.preventDefault();
//                             }}>
//                             <input
//                                 style={{ color: '#6C757D' }}
//                                 placeholder="Search in chat"
//                                 onChange={(e) => {
//                                     handleChatSearchChange(e.target.value);
//                                     this.setState({ searchString: e.target.value });
//                                 }}
//                                 value={this.state.searchString}
//                                 type="text"
//                             />
//                         </form>
//                     </div>
//                     <div className="right">
//                         {this.props.searchResultsCount ? (
//                             <div className="count">
//                                 {this.state.indexDisplayed}/{searchResultsCount}
//                             </div>
//                         ) : null}

//                         <div className="buttons">
//                             <ChevronUp
//                                 onClick={() => {
//                                     console.log(this.state.indexDisplayed);
//                                     if (this.state.indexDisplayed > 0) {
// seekToKeyword(timestampArr && timestampArr[this.state.indexDisplayed - 1].time);
//                                         handleCurrentSelected(
//                                             timestampArr && timestampArr[this.state.indexDisplayed - 1]
//                                         );

//                                         var newIndex = this.state.indexDisplayed - 1;
//                                         this.setState({ indexDisplayed: newIndex });
//                                     }
//                                     if (this.state.indexDisplayed === 1) {
//                                     }
//                                 }}></ChevronUp>
//                             <ChevronDown
//                                 onClick={() => {
//                                     if (this.state.indexDisplayed < searchResultsCount) {
//                                         handleCurrentSelected(timestampArr && timestampArr[this.state.indexDisplayed]);
//                                         seekToKeyword(timestampArr && timestampArr[this.state.indexDisplayed].time);
//                                         var newIndex = this.state.indexDisplayed + 1;
//                                         this.setState({ indexDisplayed: newIndex });
//                                     }
//                                 }}
//                             />
//                             <X
//                                 onClick={() => {
//                                     handleChatSearchChange('');
//                                     this.setState({ searchString: '', indexDisplayed: 0 });
//                                 }}
//                             />
//                         </div>
//                     </div>
//                 </div>
//             </React.Fragment>
//         );
//     }
// }

// export default ChatSearch;
