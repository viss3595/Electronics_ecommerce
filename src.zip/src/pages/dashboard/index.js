import React, { Component } from 'react';
import { Row, Col, UncontrolledButtonDropdown, DropdownMenu, DropdownItem, DropdownToggle } from 'reactstrap';
import Flatpickr from 'react-flatpickr'
import { ChevronDown, Mail, Printer, File, Users, Image, ShoppingBag, ChevronUp } from 'react-feather';

import { getLoggedInUser } from '../../helpers/authUtils';
import Loader from '../../components/Loader';
import OverviewWidget from '../../components/OverviewWidget';

import Statistics from './Statistics';
import RevenueChart from './RevenueChart';
import TargetChart from './TargetChart';
import SalesChart from './SalesChart';
import Orders from './Orders';
import Performers from './Performers';
import Tasks from './Tasks';
import Chat from './Chat';
import Chart from 'react-apexcharts';
import profilePic from '../../assets/images/users/avatar-7.jpg';
import StatisticsChartWidget from '../../components/StatisticsChartWidget';
import { serviceGet } from '../../helpers/api';
import Select from 'react-select';
 import AvGroup from 'availity-reactstrap-validation/lib/AvGroup';

import AnalyticsDashboardImg from '../../assets/images/dashboard/AnalyticsDashboard.png';
import DailyagentregisterImg from '../../assets/images/dashboard/Dailyagentregister.png';
import DailycustomersImg from '../../assets/images/dashboard/Dailycustomers.png';
import DailyexpendfeeImg from '../../assets/images/dashboard/Dailyexpendfee.png';
import DailySaleImg from '../../assets/images/dashboard/DailySale.png';
import {dashbordFilterOption} from '../../enums/DashboardDateFilterOptions';
const ApplicationChart = (saleData, commissionData, xLabel) => {



    const series = {
        series: [{
            name: "Sale Value",
            data: saleData
        },
        {
            name: "Commission Fee",
            data: commissionData
        }]
    }

    const options = {
        options: {
            chart: {
              height: 350,
              type: 'line',
              zoom: {
                enabled: false
              }
            },
            dataLabels: {
              enabled: false
            },
            stroke: {
              curve: 'straight'
            },
            grid: {
              row: {
                colors: ['transparent'], // takes an array which will be repeated on columns
                opacity: 0.5
              },
            },
            xaxis: {
                tickAmount: 8,
                tickPlacement: 'between',
              categories: xLabel,
            }
          }
    }

    return (
                <Chart
                    options={options.options}
                    series={series.series}
                    type="line"
                    // className="apex-charts mt-3"
                    height={277}
                />
    );
};

const SaleChart = (saleData, commissionData, xLabel) => {



    const series = {
        series: [{
            name: "Sale Value",
            data: saleData
        }]
    }

    const options = {
        options: {
            plotOptions: {
                bar: {
                    columnWidth: '70%',
                }
            },
            colors:['#cccccd'],
            chart: {
              height: 100,
              type: 'bar',
              zoom: {
                enabled: false
              },
              toolbar: {
                show: false
              },
            },
            dataLabels: {
              enabled: false
            },
            grid: {
              row: {
                colors: ['transparent'], // takes an array which will be repeated on columns
                opacity: 0.5
              },
            },
            xaxis: {
              labels: {
                show: false,
              }
            },
            yaxis :{
                labels: {
                    show: false,
                  }
            }
          }
    }

    return (
                <Chart
                    options={options.options}
                    series={[{
                        name: 'series-1',
                        data: [30, 40, 45, 50, 49, 60, 70, 91, 40, 45, 50, 49, 60, 70, 91, 40, 45, 50, 49, 60, 70, 91, 40, 45, 50, 49, 60, 70, 91, 40, 45, 50, 49, 60, 70, 91, 40, 45, 50, 49, 60, 70, 91]
                      }]}
                    type="bar"
                    // className="apex-charts mt-3"
                  
                />
    );
};

const CommissionChart = (commissionData, xLabel) => {



    const series = {
        series: [
        {
            name: "Commission Fee",
            data: commissionData
        }]
    }

    const options = {
        options: {
            plotOptions: {
                bar: {
                    columnWidth: '70%',
                }
            },
          
            colors:['#cccccd'],
            chart: {
              height: 350,
              zoom: {
                enabled: false
              },
              toolbar: {
                show: false
              },
            },
            plotOptions: {
                bar: {
                  borderRadius: 10,
                  dataLabels: {
                    position: 'top', // top, center, bottom
                  },
                }
              },
            dataLabels: {
              enabled: false
            },
            grid: {
              row: {
                colors: ['transparent'], // takes an array which will be repeated on columns
                opacity: 0.0
              },
            },
            xaxis: {
              axisTicks: {
                show: false
              },
              labels: {
                show: false,
              }
            },
            yaxis :{
                labels: {
                    show: false,
                  }
            }

          }
    }

    return (
                <Chart
                    options={options.options}
                    series={[{
                        name: 'series-1',
                        data: [30, 40, 45, 50, 49, 60, 70, 91, 40, 45, 50, 49, 60, 70, 91, 40, 45, 50, 49, 60, 70, 91, 40, 45, 50, 49, 60, 70, 91, 40, 45, 50, 49, 60, 70, 91, 40, 45, 50, 49, 60, 70, 91]

                      }]}
                    type="bar"
                    // className="apex-charts mt-3"
                    height={150}
                />
    );
};

class Dashboard extends Component {

    constructor(props) {
        super(props);

        var oneWeekAgo = new Date();
        oneWeekAgo.setDate(oneWeekAgo.getDate() - 15);

        var Last7Days = new Date();
        Last7Days.setDate(Last7Days.getDate() - 7);

        this.state = {
            user: getLoggedInUser(),
            filterDate: [oneWeekAgo, new Date()],
            saleData: [],
            commissionData: [],
            xLabel: [],
            type: 'day',
            limit: {
                'value': dashbordFilterOption.Last7Days.value,
                'label': dashbordFilterOption.Last7Days.label
            },
            performanceFilterDate :{
                startDate : Last7Days,
                endDate : new Date()
            },
            performantData: null,
            performantLoading: false,
            loading: false
        };
        console.log("StartDate",this.state.performanceFilterDate.startDate);
        console.log("EndDate",this.state.performanceFilterDate.endDate);
        this.getGraphData = this.getGraphData.bind(this);
        this.getPerformantData = this.getPerformantData.bind(this);
    }

    componentDidMount() {
        this.getPerformantData();
        this.getGraphData();
    }

    getPerformantData = () => {
       // debugger;
        this.setState({
            performantData: null,
            performantLoading: true
        })
        let url = `api/v1/dashboard/performant?startDate=${this.state.performanceFilterDate.startDate}&endDate=${this.state.performanceFilterDate.endDate}`;
        serviceGet(url,{
             'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
        .then((res) => {
              if(res.data) {
                this.setState({
                    performantData: res.data,
                    performantLoading: false
                })
             }
        }).catch((error) => {
            console.log(error);
            this.setState({
                performantLoading: false
            })
        });   
    }

    getGraphData = () => {
        this.setState({
            saleData: [],
            commissionData: [],
            xLabel: [],
            loading: true
        })
        let url = `api/v1/dashboard/graph-data?type=${this.state.type}`;
        serviceGet(url,{
             'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
        .then((res) => {
              if(res.data) {
                this.setState({
                    saleData: res.data.saleData,
                    commissionData: res.data.commissionData,
                    xLabel: res.data.xLabel,
                    loading: false
                })
             }
        }).catch((error) => {
            console.log(error);
            this.setState({
                 loading: false
            })
        });
    }

    changeType = (type) => {
        this.setState({
          type: type
        },() => {this.getGraphData()});
    }

    onChangeLimit = async (selectedValue) => {
        console.log(selectedValue);
        var startDate,endDate;
        switch (selectedValue.value) {
            case dashbordFilterOption.Last7Days.value: // Last 7 days
                endDate = new Date();
                startDate = new Date();
                startDate.setDate(startDate.getDate() - 7);
                break;
            case dashbordFilterOption.LastMonth.value: // Last Month
                endDate = new Date();
                startDate = new Date();
                startDate.setMonth(startDate.getMonth()-1);
                break;
            case dashbordFilterOption.LastYear.value: 
                endDate = new Date(new Date().getFullYear(), 0, 1);
                startDate = new Date(new Date().getFullYear()-1, 0, 1);
                break;
            case dashbordFilterOption.ThisYear.value:
                endDate = new Date();
                startDate = new Date(new Date().getFullYear(), 0, 1);
                break;
            default:
                endDate = new Date();
                startDate = new Date();
                startDate.setDate(startDate.getDate() - 7);
                break;
        }
        console.log("endDate",endDate);
        console.log("startDate",startDate);
        this.setState({
            limit : selectedValue,
            performanceFilterDate :{
                startDate : startDate,
                endDate : endDate
            }
        },() => {this.getPerformantData()});
    }

    render() {

        return (
            <React.Fragment>
            <div className="container-fluid">
                 <div className="card shadow mt-4">
                    <div className="card-header page-heading pt-4 pb-3 dashboard-title">
                         <img src={AnalyticsDashboardImg} className="avatar-sm"></img>
                        <span className="font-size-20 font-weight-bold pl-3">Analytics Dashboard</span>
                        <div className="pl-5 text-muted">
                          <small>This is data dashboard to using analysis the business</small>
                        </div>
                    </div>
                 </div>
            </div>
            <div className="container-fluid">
                 <div className="card shadow mt-4">
                    <div className="card-header page-heading pt-4 pb-3 title-border">
                        <div class="row">
                        <span className="col-sm-2 font-size-20 font-weight-bold">Data Performant</span>
                        <span className="col-sm-5 limit-container mt-n1">
                            <Col sm={4}>
                            <Select
                                onChange={this.onChangeLimit}
                                value={[{
                                value: this.state.limit?.value,
                                label: this.state.limit?.label
                                }]}
                                 options={[
                                    { value: dashbordFilterOption.Last7Days.value, label: dashbordFilterOption.Last7Days.label },
                                    { value: dashbordFilterOption.LastMonth.value, label:  dashbordFilterOption.LastMonth.lable },
                                    { value: dashbordFilterOption.ThisYear.value, label: dashbordFilterOption.ThisYear.label },
                                    { value: dashbordFilterOption.LastYear.value, label: dashbordFilterOption.LastYear.label },
                                ]}
                                className="react-select dashboard-filter-dropdown"
                                classNamePrefix="react-select"
                            />
                            </Col>
                        </span>
                        </div>
                    </div>
                    <div className="card-body">
                        {this.state.performantLoading ? <Loader/> :
                            <div className="row">
                                <div className="col-md-3">
                                    <div className="row">
                                            <div className="col-md-2 pt-3">
                                                <img src={DailyagentregisterImg} className="rounded-circle avatar-sm"></img>
                                            </div>
                                            <div className="col-md-10 pl-3">
                                                <div className="text-muted">Daily agent register</div>
                                                    <div className="font-size-18 font-weight-bold">
                                                        {
                                                            this.state.performantData == null ? 0 : this.state.performantData != null && this.state.performantData.agentCount 
                                                        }
                                                    </div>
                                                <div className="font-size-12 pt-2">
                                                    <span className={this.state.performantData != null && this.state.performantData.percentageAgent >0?"text-success pr-1":"text-danger pr-1"}><ChevronUp size={11}/>{this.state.performantData != null && this.state.performantData.percentageAgent }</span>
                                                    <span>{this.state.performantData != null &&  this.state.performantData.percentageAgent >0?'Increase Register':'Decrease Register'}</span>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                <div className="col-md-3">
                                    <div className="row">
                                            <div className="col-md-2 pt-3">
                                                <img src={DailySaleImg} className="rounded-circle avatar-sm"></img>
                                            </div>
                                            <div className="col-md-10 pl-3">
                                                <div className="text-muted pt-n4">Daily customers</div>
                                                <div className="font-size-18 font-weight-bold">
                                                    {this.state.performantData == null ? 0 : this.state.performantData != null && this.state.performantData.customerCount}
                                                    </div>
                                                <div className="font-size-12 pt-2">
                                                    <span className={this.state.performantData != null && this.state.performantData.percentageCustomer>0?"text-success pr-1":"text-danger pr-1"}><ChevronDown size={11}/>{this.state.performantData != null && this.state.performantData.percentageCustomer}</span>
                                                    <span>{this.state.performantData != null && this.state.performantData.percentageCustomer>0?'More ':'Less Buy'}</span>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                <div className="col-md-3">
                                    <div className="row">
                                            <div className="col-md-2 pt-3">
                                                <img src={DailySaleImg} className="rounded-circle avatar-sm"></img>
                                            </div>
                                            <div className="col-md-10 pl-3">
                                                <div className="text-muted pt-n4">Daily Sale</div>
 
                                                <div className="font-size-18 font-weight-bold">{"$ "} {this.state.performantData == null ? 0 : this.state.performantData != null && this.state.performantData.salesCount[0]?.sum}</div>
                                                <div className="font-size-12 pt-2">
                                                    <span className="text-success pr-1"><ChevronUp size={11}/>{this.state.performantData != null && this.state.performantData.percentageSale}</span>
                                                    <span>{this.state.performantData != null && this.state.performantData.percentageSale>0?"Increase Sale":"Decrease Sale"}</span>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                <div className="col-md-3">
                                    <div className="row">
                                            <div className="col-md-2 pt-3">
                                                <img src={DailyexpendfeeImg} className="rounded-circle avatar-sm"></img>
                                            </div>
                                            <div className="col-md-10 pl-3">
                                                <div className="text-muted pt-n4">Daily expand fee</div>
                                                <div className="font-size-18 font-weight-bold">{"$ "}{this.state.performantData == null ? 0 : this.state.performantData != null && this.state.performantData.settledAmount[0].sum}</div>
                                                <div className="font-size-12 pt-2">
                                                    <span className={this.state.performantData != null
                                                         && 
                                                         this.state.performantData.settledAmountExpFeeCount>0?"text-success pr-1":"text-danger pr-1"}><ChevronUp size={11}/>{this.state.performantData != null && this.state.performantData.settledAmountExpFeeCount}</span>
                                                    <span>{this.state.performantData != null
                                                         && 
                                                         this.state.performantData.settledAmountExpFeeCount>0?"Increase":"Decrease"}</span>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                            </div> 
                        }
                    </div>
                 </div>
            </div>
            <div className="container-fluid">
                 <div className="card shadow mt-4">
                    {/* <div className="card-header page-heading pt-4 pb-3 dashboard-title">
                        <span className="font-size-20 font-weight-bold">Overview</span>
                        <div className="pt-2 pl-3 cursor-pointer">
                            {this.state.type === 'day'?<span className="pr-3"><span className="text-info type-border text-center" onClick={()=>{this.changeType('day')}}>Day</span> </span>:<span className="pr-3" onClick={()=>{this.changeType('day')}}>Day</span>}
                            {this.state.type === 'week'?<span className="pr-3"><span className="text-info type-border text-center" onClick={()=>{this.changeType('week')}}>Week</span> </span>:<span className="pr-3" onClick={()=>{this.changeType('week')}}>Week</span>}
                            {this.state.type === 'month'?<span className="pr-3"><span className="text-info type-border text-center" onClick={()=>{this.changeType('month')}}>Month</span> </span>:<span className="pr-3" onClick={()=>{this.changeType('month')}}>Month</span>}
                            {this.state.type === 'year'?<span className="pr-3"><span className="text-info type-border text-center" onClick={()=>{this.changeType('year')}}>Year</span> </span>:<span className="pr-3" onClick={()=>{this.changeType('year')}}>Year</span>}
                        </div>
                    </div> */}
                    <div className="card-body p-0">
                       
                        
                    { this.state.loading ? <Loader/> : 
                        <>
                            <div className="row">
                                <div className="col-9 p-3">
                                    <div className="col-12">
                                        <span className="font-size-20 font-weight-bold">Overview</span>
                                        <div className="pt-2 pl-3 cursor-pointer">
                                            {this.state.type === 'day'?<span className="pr-3"><span className="text-info type-border text-center" onClick={()=>{this.changeType('day')}}>Day</span> </span>:<span className="pr-3" onClick={()=>{this.changeType('day')}}>Day</span>}
                                            {this.state.type === 'week'?<span className="pr-3"><span className="text-info type-border text-center" onClick={()=>{this.changeType('week')}}>Week</span> </span>:<span className="pr-3" onClick={()=>{this.changeType('week')}}>Week</span>}
                                            {this.state.type === 'month'?<span className="pr-3"><span className="text-info type-border text-center" onClick={()=>{this.changeType('month')}}>Month</span> </span>:<span className="pr-3" onClick={()=>{this.changeType('month')}}>Month</span>}
                                            {this.state.type === 'year'?<span className="pr-3"><span className="text-info type-border text-center" onClick={()=>{this.changeType('year')}}>Year</span> </span>:<span className="pr-3" onClick={()=>{this.changeType('year')}}>Year</span>}
                                        </div>
                                    </div>
                                    <div className="col-12">
                                        {ApplicationChart(this.state.saleData, this.state.commissionData, this.state.xLabel)}
                                    </div>
                                   
                                </div>
                                <div className="col-3 bg-light">
                                    <div className="col-12">
                                        <div className="min-chart-header mt-4">
                                            <h6>120,495</h6>
                                            <span>Sale value</span>
                                        </div>
                                        
                                        {SaleChart(this.state.saleData, this.state.xLabel)}
                                    </div>
                                    <div className="col-12">
                                        <div className="min-chart-header">
                                            <h6>$ 120,495</h6>
                                            <span>Commission fee</span>
                                        </div>
                                        {CommissionChart(this.state.commissionData, this.state.xLabel)}
                                    </div>
                                </div>
                            </div>
                        </>
                        
                    }
                    </div>
                  </div>
            </div>
            </React.Fragment>
        )
    }
}


export default Dashboard;