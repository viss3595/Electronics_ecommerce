import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect, Link } from 'react-router-dom'

import { Container, Row, Col, Card, CardBody, } from 'reactstrap';

import { isUserAuthenticated } from '../../helpers/authUtils';
import logo from '../../assets/images/logo.png';

import { servicePost,serviceGet } from "./../../helpers/api";

class AccountVerification extends Component {
    _isMounted = false;

    constructor(props) {
        super(props);
        this.state = {
            emailStatus: false
        }
    }

    componentDidMount() {
        this._isMounted = true;
        document.body.classList.add('authentication-bg');
        try{
            servicePost('verificationAccount',{ email: this.props.match.params.email })
            .then((res) => {
                this.setState({
                    emailStatus: true
                })
            })
            .catch((err)=> {
                console.log(err);
            })
        }catch(err){
            console.log(err);
        }
    }

    componentWillUnmount() {
        this._isMounted = false;
        document.body.classList.remove('authentication-bg');
    }

    /**
     * Redirect to root
     */
    // renderRedirectToRoot = () => {
    //     const isAuthTokenValid = isUserAuthenticated();
    //     if (isAuthTokenValid) {
    //         return <Redirect to='/' />
    //     }
    // }

    
    
    render() {
        function emailHtml(){
            if(!this.state.emailStatus){
                return `<h6 className="h5 mb-0 mt-4">Confirm your email</h6>
                <p className="text-muted mt-3 mb-3">Account Verification</p>`
            }else{
                return `<h6 className="h5 mb-0 mt-4">Email confirmed</h6>`
            }
        }
        const isAuthTokenValid = isUserAuthenticated();
       
        return (
            <React.Fragment>
                {(this._isMounted || !isAuthTokenValid) && <div className="account-pages my-5">
                    <Container>
                        <Row className="justify-content-center">
                            <Col md={8} lg={6} xl={5}>
                                <Card className="text-center">
                                    <CardBody className="p-4">
                                        <div className="mx-auto mb-5">
                                            <a href="/">
                                                <img src={logo} alt="" height="24" />
                                                <h3 className="d-inline align-middle ml-1 text-logo"></h3>
                                            </a>
                                        </div>
                                        
                                    </CardBody>
                                </Card>
                            </Col>
                        </Row>
                        <Row className="mt-3">
                            <Col className="text-center">
                                <p className="text-muted">Return to <Link to="/login" className="text-primary font-weight-bold ml-1">Login</Link></p>
                            </Col>
                        </Row>
                    </Container>
                </div>}
            </React.Fragment>
        )
    }
}

export default connect()(AccountVerification);