import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect, Link } from 'react-router-dom';

import {
    Container,
    Row,
    Col,
    Card,
    CardBody,
    FormGroup,
    Button,
    Alert,
    Label,
    InputGroup,
    InputGroupAddon,
} from 'reactstrap';
import { AvForm, AvGroup, AvInput, AvFeedback } from 'availity-reactstrap-validation';
import { Mail } from 'react-feather';
import quotes from '../../assets/images/quotes.svg';
import clientImg from '../../assets/images/clients/c.jpg';
import software from '../../assets/images/brands/SpaceO_format.png';
import SuperProcure from '../../assets/images/brands/SuperProcure.png';
import SocialPilot from '../../assets/images/brands/SocialPilot.png';
import { servicePost } from '../../helpers/api';

import { isUserAuthenticated } from '../../helpers/authUtils';
import Loader from '../../components/Loader';
import logo from '../../assets/images/logo.png';

class ForgetPassword extends Component {
    _isMounted = false;

    constructor(props) {
        super(props);

        this.handleValidSubmit = this.handleValidSubmit.bind(this);
        this.onDismiss = this.onDismiss.bind(this);
        this.state = {
            passwordResetSuccessful: false,
            isLoading: false,
            alert: false,
        };
    }

    componentDidMount() {
        this._isMounted = true;
        document.body.classList.add('authentication-bg');
    }

    componentWillUnmount() {
        this._isMounted = false;
        document.body.classList.remove('authentication-bg');
    }

    /**
     * On error dismiss
     */
    onDismiss() {
        this.setState({ passwordResetSuccessful: false });
    }

    /**
     * Handles the submit
     */
    handleValidSubmit = async (e, values) => {
        e.preventDefault();

        var headers = {
            'Content-Type': 'application/json',
        };
        const res = await servicePost('forgot-password', { email: values.email }, headers);
        console.log(res);
        if (res.message === 'SUCCESS') {
            this.setState({
                alert: true,
                alertcolor: 'success',
                alertMessage: 'An email containing password reset link has been sent to you ',
            });
        } else if (res.message === 'FAILED' && res.statusCode === 200) {
            this.setState({
                alert: true,
                alertcolor: 'danger',
                alertMessage: 'User does not exist',
            });
        } else {
            this.setState({
                alert: true,
                alertcolor: 'danger',
                alertMessage: 'An error occured',
            });
        }
    };

    /**
     * Redirect to root
     */
    renderRedirectToRoot = () => {
        const isAuthTokenValid = isUserAuthenticated();
        if (isAuthTokenValid) {
            return <Redirect to="/" />;
        }
    };

    render() {
        const isAuthTokenValid = isUserAuthenticated();
        return (
            <React.Fragment>
                {this.renderRedirectToRoot()}

                {(this._isMounted || !isAuthTokenValid) && (
                    <div className="account-pages my-5">
                        <Container>
                            <Row className="justify-content-center">
                                <Col xl={10}>
                                    <Card className="">
                                        <CardBody className="p-0">
                                            <Row>
                                                <Col md={6} className="p-5 position-relative">
                                                    {/* preloader */}
                                                    {this.state.isLoading && <Loader spinner />}

                                                    <div className="mx-auto mb-5">
                                                        <a href="/">
                                                            <img src={logo} alt="" height="24" />
                                                        </a>
                                                    </div>

                                                    <h6 className="h5 mb-0 mt-4">Reset Password</h6>
                                                    <p className="text-muted mt-1 mb-4">
                                                        Enter your email address and we'll send you an email with
                                                        instructions to reset your password.
                                                    </p>
                                                    <Alert
                                                        color={this.state.alertcolor}
                                                        isOpen={this.state.alert ? true : false}>
                                                        <div
                                                            dangerouslySetInnerHTML={{
                                                                __html: this.state.alertMessage,
                                                            }}></div>
                                                    </Alert>

                                                    {this.props.error && (
                                                        <Alert color="danger" isOpen={this.props.error ? true : false}>
                                                            <div>{this.props.error}</div>
                                                        </Alert>
                                                    )}

                                                    <AvForm
                                                        onValidSubmit={this.handleValidSubmit}
                                                        className="authentication-form">
                                                        <AvGroup className="">
                                                            <Label for="email">Email Address</Label>
                                                            <InputGroup>
                                                                <InputGroupAddon addonType="prepend">
                                                                    <span className="input-group-text">
                                                                        <Mail className="icon-dual" />
                                                                    </span>
                                                                </InputGroupAddon>
                                                                <AvInput
                                                                    type="text"
                                                                    name="email"
                                                                    id="email"
                                                                    placeholder="hello@coderthemes.com"
                                                                    value={this.state.email}
                                                                    required
                                                                />
                                                            </InputGroup>

                                                            <AvFeedback>This field is invalid</AvFeedback>
                                                        </AvGroup>

                                                        <FormGroup className="form-group mb-0 text-center">
                                                            <Button color="primary" className="btn-block">
                                                                Submit
                                                            </Button>
                                                        </FormGroup>
                                                    </AvForm>
                                                </Col>

                                                <Col md={6} className="d-none d-md-inline-block">
                                                    <div
                                                        className="auth-page-sidebar"
                                                        style={{
                                                            backgroundImage: 'none',
                                                            position: 'unset !important',
                                                        }}>
                                                        <div className="col-12 py-3 px-5">
                                                            <img src={quotes} alt="" height="40" />
                                                            <p className="font-size-16 font-weight-bold line-height-30">
                                                               Description here
                                                            </p>

                                                            <div className="col-12 d-flex p-2 py-3">
                                                                <div class="col-3 p-0">
                                                                    <img
                                                                        width="80%"
                                                                        src=""
                                                                        style={{ borderRadius: '50%' }}
                                                                    />
                                                                </div>
                                                                <div className="col-9 p-2">
                                                                    <div className="font-weight-bold">
                                                                        Khushbu Tekchandani
                                                                    </div>
                                                                    <div className="">Sales Head, Software Suggest</div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="auth-user-testimonial hide-md padding-t-10 padding-xl-t-49">
                                                            <h3 className="font-size-16 text-left">
                                                                Trusted by users across leading brands
                                                            </h3>
                                                            <div class="row">
                                                                
                                                                <div class="col-4">
                                                                    <img
                                                                        src={software}
                                                                        class="opacity-3"
                                                                        alt="software"
                                                                        height="70%"
                                                                        resizeMode="cover"
                                                                        width="100%"
                                                                    />
                                                                </div>
                                                                <div class="col-4">
                                                                    <img
                                                                        src={SuperProcure}
                                                                        class="opacity-3"
                                                                        alt="SuperProcure"
                                                                        height="80%"
                                                                        width="100%"
                                                                    />
                                                                </div>
                                                                <div class="col-4">
                                                                    <img
                                                                        src={SocialPilot}
                                                                        class="opacity-3"
                                                                        alt="SuperProcure"
                                                                        height="80%"
                                                                        width="100%"
                                                                    />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </Col>
                                            </Row>
                                        </CardBody>
                                    </Card>
                                </Col>
                            </Row>

                            <Row className="mt-1">
                                <Col className="col-12 text-center">
                                    <p className="texttext-muted">
                                        Back to{' '}
                                        <Link to="/login" className="text-primary font-weight-bold ml-1">
                                            Login
                                        </Link>
                                    </p>
                                </Col>
                            </Row>
                        </Container>
                    </div>
                )}
            </React.Fragment>
        );
    }
}

export default connect()(ForgetPassword);
