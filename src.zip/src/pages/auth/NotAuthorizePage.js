import React from 'react'
import { Redirect } from 'react-router-dom'
class NotAuthorizePage  extends React.Component {
  render () {
      
    return (
      //  <div>
      //      <h3>You have not Authorize this page!</h3>
      //  </div>
      <div className="jumbotron text-center">
        <h1>Access denied</h1>
        <p>You are not authorized to access this page.</p>
      </div>
    )
  }
}
export default NotAuthorizePage;