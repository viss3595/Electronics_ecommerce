import React, { useState, useEffect, Component } from 'react';
import { Redirect, Link } from 'react-router-dom';

import axios from 'axios';
import { connect } from 'react-redux';
import { AvForm, AvGroup, AvInput, AvFeedback } from 'availity-reactstrap-validation';
import { Key } from 'react-feather';
import logo from '../../assets/images/logo.png';
import quotes from '../../assets/images/quotes.svg';
import clientImg from '../../assets/images/clients/c.jpg';

import {
    Container,
    Row,
    Col,
    Card,
    CardBody,
    FormGroup,
    Button,
    Alert,
    Label,
    InputGroup,
    InputGroupAddon,
} from 'reactstrap';
import { servicePost } from '../../helpers/api';

class ResetPassword extends Component {
    constructor(props) {
        super(props);
        this.state = {
            disable: false,
            tokenVerified: false,
            password: '',
            alert: false,
            alertMessage: '',
            alertColor: 'danger',
            token: props.match.params.token,
        };
    }
    // const [disable, setdisable] = useState(false);
    // const [tokenVerified, setverified] = useState(false);
    // const [password, setpassword] = useState('');
    // const [alert, setalert] = useState(false);
    // const [alertMessage, setalertMessage] = useState('');
    // const [alertcolor, setalertcolor] = useState('danger');

    // const { token } = props.match.params;

    checkToken = async (token) => {
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'JWT ' + this.state.token,
        };
        let response = await servicePost('authenticate', {}, headers);
        console.log(response);

        if (response.message === 'SUCCESS') {
            this.setState({
                tokenVerified: true,
            });
        } else {
            this.setState({
                alert: true,
                alertMessage: 'Something is wrong with your Token. Try Again!',
            });
        }
    };
    // useEffect(() => {
    //     checkToken(token);
    // });

    // console.log(tokenVerified);
    componentDidMount = async () => {
        let checkToken = await this.checkToken();
        return checkToken;
    };

    handleSubmit = async (e, values) => {
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'JWT ' + this.state.token,
        };
        console.log(values);

        let response = await servicePost('auth/reset-password', { password: values.password }, headers);
        console.log(response);

        if (response.message === 'SUCCESS') {
            this.setState({
                disable: true,
                alertMessage:
                    '<span>Password added successfully. <br/> You can now login <a href="/"> Here</a> </span>',
                alertColor: 'success',
                alert: true,
            });
            setTimeout(() => {
                return <Redirect to="/" />;
            }, 2000);
        } else {
            this.setState({
                alertMessage: '<span>Error saving password try again</span>',
                alert: true,
            });
        }

        // const config = { headers: { 'Content-Type': 'application/json', Authorization: `JWT ${token}` } };

        // const body = JSON.stringify({ password });
        // const res = await axios.post('http://localhost:3001/auth/reset-password', body, config);
        // console.log(res.data);
        // if (res.status === 500) {
        //     setalertMessage('An internal server Error occured');
        //     setalert(true);
        // }
        // if (res.data.statusCode === 400) {
        //     setalertMessage('Error saving password try again');
        //     setalert(true);
        // }
        // if (res.data.statusCode === 200) {
        //     setdisable(true);
        //     setalertMessage('Password added successfully You can now login');
        //     setalertcolor('success');
        //     setalert(true);
        //     setTimeout(() => {
        //         return <Redirect to="/" />;
        //     }, 2000);
        // }
    };

    render() {
        return (
            <React.Fragment>
                <div className="account-pages my-5">
                    <Container>
                        <Row className="justify-content-center">
                            <Col xl={10}>
                                <Card className="">
                                    <CardBody className="p-0">
                                        <Row>
                                            <Col md={6} className="p-5 position-relative">
                                                <div className="mx-auto mb-5">
                                                    <a href="/">
                                                        <img src={logo} alt="" height="24" />
                                                    </a>
                                                </div>

                                                <h6 className="h5 mb-0 mt-4">Set up your Password</h6>
                                                <p className="text-muted mt-1 mb-4">
                                                    Once you submit your password you'll be able to login with your
                                                    credentials from <Link>here</Link>
                                                </p>
                                                <Alert
                                                    color={this.state.alertcolor}
                                                    isOpen={this.state.alert ? true : false}>
                                                    <div
                                                        dangerouslySetInnerHTML={{
                                                            __html: this.state.alertMessage,
                                                        }}></div>
                                                </Alert>
                                                {this.state.tokenVerified ? (
                                                    <AvForm
                                                        onValidSubmit={this.handleSubmit}
                                                        className="authentication-form">
                                                        <AvGroup className="">
                                                            <Label for="email">Password</Label>
                                                            <InputGroup>
                                                                <InputGroupAddon addonType="prepend">
                                                                    <span className="input-group-text">
                                                                        <Key className="icon-dual" />
                                                                    </span>
                                                                </InputGroupAddon>
                                                                <AvInput
                                                                    type="password"
                                                                    name="password"
                                                                    id="password"
                                                                    placeholder="Set up your password"
                                                                    required
                                                                />
                                                            </InputGroup>

                                                            <AvFeedback>This field is invalid</AvFeedback>
                                                        </AvGroup>

                                                        <FormGroup className="form-group mb-0 text-center">
                                                            <Button
                                                                disabled={this.state.disable}
                                                                color="primary"
                                                                className="btn-block">
                                                                Submit
                                                            </Button>
                                                        </FormGroup>
                                                    </AvForm>
                                                ) : null}
                                            </Col>

                                            <Col md={6} className="d-none d-md-inline-block reset-password">
                                                <div className="">
                                                    <div className="overlay"></div>
                                                    <div className="col-12 py-3 px-5">
                                                        <img src={quotes} alt="" height="40" />
                                                        <p className="font-size-16 font-weight-bold line-height-30">
                                                           Description here
                                                        </p>

                                                        <div className="col-12 d-flex p-2 py-3">
                                                            <div class="col-3 p-0">
                                                                <img
                                                                    width="80%"
                                                                    src={clientImg}
                                                                    style={{ borderRadius: '50%' }}
                                                                />
                                                            </div>
                                                            <div className="col-9 p-2">
                                                                <div
                                                                    style={{ color: '#fdfdfd' }}
                                                                    className="font-weight-bold">
                                                                    Chitranshu Sharma
                                                                </div>
                                                                <div style={{ color: '#fdfdfd' }} className="">
                                                                    Founder, Woo Technologies
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </CardBody>
                                </Card>
                            </Col>
                        </Row>

                        <Row className="mt-1">
                            <Col className="col-12 text-center">
                                <p className="texttext-muted">
                                    Back to{' '}
                                    <Link to="/login" className="text-primary font-weight-bold ml-1">
                                        Login
                                    </Link>
                                </p>
                            </Col>
                        </Row>
                    </Container>
                </div>
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    return state;
};

export default connect()(ResetPassword);
