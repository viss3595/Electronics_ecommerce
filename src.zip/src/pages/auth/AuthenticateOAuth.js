import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Container, Row, Col, Card, CardBody } from 'reactstrap';
import { Redirect, Link } from 'react-router-dom'

import { loginUser, loginUserSuccess } from '../../redux/actions';
import { servicePost } from './../../helpers/api';
import { isUserAuthenticated } from '../../helpers/authUtils';
import { Cookies } from 'react-cookie';
import Loader from '../../components/Loader';

class AuthenticateOAuth extends Component {
    _isMounted = false;

    constructor(props) {
        super(props);
        let token = new URLSearchParams(props.location.search).get("token");
        this.state = {
            loading : true,
            error : null,
            token : token
        }
    }
    setSession = user => {
        let cookies = new Cookies();
        if (user) cookies.set('user', JSON.stringify(user), { path: '/' });
        else cookies.remove('user', { path: '/' });
    };

    async componentDidMount() {
        this._isMounted = true;

        console.log(this.props);

        document.body.classList.add('authentication-bg');
        var tokenData = await servicePost(
            'authenticate/token',
            { token: this.state.token },
        );

        console.log(tokenData);

        if(tokenData.message == "SUCCESS"){
           
            this.setSession(tokenData.data)
            this.props.loginUserSuccess(tokenData.data);
            this.setState({
                loading : false,
            })
        }
        else{
            this.setState({
                loading : false,
                error : tokenData.error
            })
        }

    }

    componentWillUnmount() {
        this._isMounted = false;
        document.body.classList.remove('authentication-bg');
    }
    /**
     * Redirect to root
     */
    renderRedirectToRoot = () => {
        const isAuthTokenValid = isUserAuthenticated();
        if (isAuthTokenValid) {
            return <Redirect to='/' />
        }
    }

    render() {
     
        return (
            <React.Fragment>
                {(!this.state.loading && this.state.error == null)  && this.renderRedirectToRoot()}
                <div className="account-pages my-5">
                    <Container>
                        <Row className="justify-content-center">
                            <Col xl={10}>
                                <Card className="p-3">
                                    <CardBody className="p-0">
                                        <Row className="">
                                            <Col md={12} xl={12}>
                                                {this.state.loading && <h4>Please wait, Logging you in....</h4>}
                                                {(this.state.error != null) && <h4>{this.state.error}</h4>}
                                            </Col>
                                        </Row>
                                    </CardBody>
                                </Card>
                            </Col>
                        </Row>
                    </Container>
                </div>
            </React.Fragment>
        )
    }
}


const mapStateToProps = (state) => {
    const { user, loading, error } = state.Auth;
    return { user, loading, error };
};

export default connect(mapStateToProps, { loginUser, loginUserSuccess })(AuthenticateOAuth);