import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect, Link } from 'react-router-dom';
import loginLogo from '../../assets/images/icons/icon_building.png';

import {
    Container,
    Row,
    Col,
    Card,
    CardBody,
    Label,
    FormGroup,
    Button,
    Alert,
    InputGroup,
    InputGroupAddon,
} from 'reactstrap';
import { AvForm, AvGroup, AvInput, AvFeedback } from 'availity-reactstrap-validation';
import { Mail, Lock } from 'react-feather';

import { loginUser } from '../../redux/actions';
import { isUserAuthenticated } from '../../helpers/authUtils';
import Loader from '../../components/Loader';

class Login extends Component {
    _isMounted = false;

    constructor(props) {
        super(props);

        this.handleValidSubmit = this.handleValidSubmit.bind(this);
        this.state = {
            email: 'abc@test.com',
            password: 'test',
            showPassword: false
        };
    }

    componentDidMount() {
        this._isMounted = true;

        document.body.classList.add('authentication-bg');
    }

    componentWillUnmount() {
        this._isMounted = false;
        document.body.classList.remove('authentication-bg');
    }

    /**
     * Handles the submit
     */
    handleValidSubmit = (event, values) => {
        // alert(values.email_address)
        this.props.loginUser(values.email_address, values.password, this.props.history);
    };

    /**
     * Redirect to root
     */
    renderRedirectToRoot = () => {
        const isAuthTokenValid = isUserAuthenticated();
        if (isAuthTokenValid) {
            return <Redirect to="/" />;
        }
    };

    togglePasswordVisibility = () => {
        this.setState({
            showPassword: !this.state.showPassword
        })     
    }

    render() {
        const isAuthTokenValid = isUserAuthenticated();
        return (
            <React.Fragment>
                {this.renderRedirectToRoot()}

                {(this._isMounted || !isAuthTokenValid) && (
                    <div className="account-pages my-5">
                        <Container>
                            <Row className="justify-content-center">
                                <Col xl={4} md={6} xs={10}>
                                    <Card>
                                        <CardBody className="p-0">
                                            <Row className="">
                                            <Col xl={12} md={12} xs={12} className="p-4 position-relative">
                                            {/* <div class="row"> */}
                                                <div className=" heading-div">
                                                    <img
                                                    src={loginLogo}
                                                    className="opacity-3"
                                                    alt="software"
                                                    height="60%"
                                                    resizemode="cover"
                                                    width="70%"
                                                    />
                                                </div>
                                                {/* <div className="heading-div">
                                                    <span className="top-heading">REAL ESTATE</span>
                                                </div>
                                                &nbsp;&nbsp; */}
                                                <div className="heading-div">
                                                    <span className="bottom-heading">Affiliate System</span>
                                                </div>
                                            </Col>
                                            </Row>
                                            <Row className="">
                                                <Col xl={12} md={12} xs={12} className="p-5 position-relative login-box">
                                                    {/* preloader */}
                                                    {this.props.loading && <Loader spinner />}

                                                    {/* <div className="mx-auto mb-4">
                                                        <a href="/">
                                                            <img src={logo} alt="" height="24" />
                                                            <h3 className="d-inline align-middle ml-1 text-logo"></h3>
                                                        </a>
                                                    </div>

                                                    <h6 className="h5 mb-0 mt-1">Welcome back!</h6>
                                                    <p className="text-muted mt-1 mb-4">
                                                        Enter your email address and password to access admin panel.
                                                    </p> */}

                                                    {this.props.error && (
                                                        <Alert color="danger" isOpen={this.props.error ? true : false}>
                                                            <div>{this.props.error}</div>
                                                        </Alert>
                                                    )}

                                                    <AvForm
                                                        onValidSubmit={this.handleValidSubmit}
                                                        className="authentication-form">
                                                        <AvGroup className="login-group">
                                                            {/* <Label for="email">Email Address</Label> */}
                                                                {/* <InputGroupAddon addonType="prepend"> */}
                                                                    {/* <span className="input-group-text white-background"> */}
                                                                        <i className="uil uil-user-circle login-icon"></i>
                                                                    {/* </span> */}
                                                                {/* </InputGroupAddon> */}
                                                                <AvInput
                                                                    type="email"
                                                                    name="email_address"
                                                                    autoComplete="false"
                                                                    id="email_address"
                                                                    placeholder="User Name"
                                                                    value=""
                                                                    required
                                                                />

                                                            <AvFeedback>This field is invalid</AvFeedback>
                                                        </AvGroup>

                                                        <AvGroup className="mb-3 login-group">
                                                            {/* <Label for="password">Password</Label> */}
                                                            {/* <Link
                                                                to="/forget-password"
                                                                className="float-right text-muted text-unline-dashed ml-1">
                                                                Forgot your password?
                                                            </Link> */}
                                                                {/* <InputGroupAddon addonType="prepend"> */}
                                                                    {/* <span className="input-group-text white-background"> */}
                                                                        <i className="uil uil-padlock login-icon"></i>
                                                                    {/* </span> */}
                                                                {/* </InputGroupAddon> */}
                                                                {
                                                                    !this.state.showPassword ? <i className="uil uil-eye password-eye-icon" onClick={this.togglePasswordVisibility}></i> :
                                                                    <i className="uil uil-eye-slash password-eye-icon" onClick={this.togglePasswordVisibility}></i>
                                                                }
                                                                <AvInput
                                                                    type={this.state.showPassword ? "text" : "password"}
                                                                    name="password"
                                                                    id="password"
                                                                    autoComplete="false"
                                                                    placeholder="Password"
                                                                    value=""
                                                                    required
                                                                />
                                                            <AvFeedback>This field is invalid</AvFeedback>
                                                        </AvGroup>

                                                        <FormGroup className="form-group mb-0 text-center">
                                                            <Button color="" className="btn-block login-button">
                                                                LOGIN
                                                            </Button>
                                                        </FormGroup>

                                                        
                                                    {/* <Col className="col-12 pt-3 text-center">
                                                        <p className="text-muted">Don't have an account? <Link to="/register" className="text-primary font-weight-bold ml-1">Sign Up</Link></p>
                                                    </Col> */}
                                                   
                                                    </AvForm>
                                                </Col>

                                                {/* <Col md={6} className="d-none d-md-inline-block">
                                                    <div
                                                        className="auth-page-sidebar"
                                                        style={{
                                                            backgroundImage: 'none',
                                                            position: 'unset !important',
                                                        }}>
                                                        <div className="col-12 py-3 px-5">
                                                            
                                                        </div>

                                                        <div className="auth-user-testimonial hide-md padding-t-10 padding-xl-t-49">
                                                            
                                                            <div class="row">
                                                                <div class="col-4">
                                                                    <img
                                                                        src={software}
                                                                        class="opacity-3"
                                                                        alt="software"
                                                                        height="70%"
                                                                        resizeMode="cover"
                                                                        width="100%"
                                                                    />
                                                                </div>
                                                                <div class="col-4">
                                                                    <img
                                                                        src={SuperProcure}
                                                                        class="opacity-3"
                                                                        alt="SuperProcure"
                                                                        height="80%"
                                                                        width="100%"
                                                                    />
                                                                </div>
                                                                <div class="col-4">
                                                                    <img
                                                                        src={SocialPilot}
                                                                        class="opacity-3"
                                                                        alt="SuperProcure"
                                                                        height="80%"
                                                                        width="100%"
                                                                    />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </Col> */}
                                            </Row>
                                        </CardBody>
                                    </Card>
                                </Col>
                            </Row>
                        </Container>
                    </div>
                )}
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    const { user, loading, error } = state.Auth;
    return { user, loading, error };
};

export default connect(mapStateToProps, { loginUser })(Login);
