import AvField from 'availity-reactstrap-validation/lib/AvField';
import AvForm from 'availity-reactstrap-validation/lib/AvForm';
import AvGroup from 'availity-reactstrap-validation/lib/AvGroup';
import React,{Component} from 'react';
import Select from 'react-select';
import { Modal,ModalFooter,Col,ModalBody,ModalHeader,Row, Table,CustomInput } from 'reactstrap';
import Label from 'reactstrap/lib/Label';
import { getLoggedInUser } from '../../helpers/authUtils';
import { dateFormat } from '../../helpers/common';
import { serviceGet, servicePost,servicePut } from './../../helpers/api';
import ReactPaginate from 'react-paginate';
import Loader from '../../components/Loader';
import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import moment from 'moment';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import { toast } from 'react-toastify';
class Sales extends Component
{
        constructor(props) {
        super(props);
        this.state = {
            user: getLoggedInUser(),
            modal: false,
            loading: true,
            pageLoading: false,
            salesList: [],
            name:'',
            saleId:null,
            idCard:'',
            phoneNumber:0,
            seller:'',
            currentPage:0,
            size:10,
            pageCount:1,
            sellers:[],
            products:[],
            paymentStatuses:[],
            searchName: '',
            modalLoader: false
        };
        this.toggle = this.toggle.bind(this);
        this.getSalesList= this.getSalesList.bind(this);
        this.createSale= this.createSale.bind(this);
        this.getSellers= this.getSellers.bind(this);
        this.onChangeSeller = this.onChangeSeller.bind(this);
        this.onChangeProduct = this.onChangeProduct.bind(this);
        this.onChangePayment = this.onChangePayment.bind(this);
    }
    
    componentDidMount(){     
        this.getSalesList();
        this.getProducts();
        this.getPaymentStatuses();
    }

    getProducts = () => {
      serviceGet('api/v1/product/search?isEnabled=true',{
        'Content-Type': 'application/json',
         Authorization: 'Bearer ' + this.state.user.token
      })
      .then((res)=>{
          let productObj=[];
              for(var i=0; i < res.data.responseObject.length; i++) {
                  productObj.push({
                      'value':res.data.responseObject[i]._id,
                      'label':res.data.responseObject[i].typeName
                  });
              }
            //   if(res.data){
                this.setState({
                    products: productObj,
                    productsList: res.data
                });
            //  }
      });
    }

    getPaymentStatuses = () => {
      serviceGet('api/v1/payment/search?isEnabled=true',{
        'Content-Type': 'application/json',
         Authorization: 'Bearer ' + this.state.user.token
      })
      .then((res) => {
          let paymentStatusObj=[];
              for(var i=0; i < res.data.responseObject.length; i++) {
                  paymentStatusObj.push({
                      'value':res.data.responseObject[i]._id,
                      'label':res.data.responseObject[i].statusName
                  });
              }
            //   if(res.data){
                this.setState({
                    paymentStatuses: paymentStatusObj
                });
            //  }
      });
    }

    getSalesList = () => {
        this.setState({
            salesList: [],
            loading: true
        })
        let url = `api/v1/sale/list?name=${this.state.searchName}&page=${this.state.page}&size=${this.state.size}`;
        if(this.state.startDate && this.state.endDate){
          url+= `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
        }else if(this.state.startDate && (!this.state.endDate)){
          url+= `&startDate=${this.state.startDate}`;
        }else if(this.state.endDate && (!this.state.startDate)){
          url+= `&endDate=${this.state.endDate}`;
        }

        console.log("url ===>    ",url)
        serviceGet(url,{
             'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
          .then((res)=>{
              if(res.data){
                this.setState({
                    salesList: res.data.responseObject,
                    pageCount: res.data.totalElements <10 ? 1 : Math.ceil(res.data.totalElements / 10),
                    loading: false
                },()=>{this.salesList = this.state.salesList;console.log(this.salesList)})
             }
        }).catch((error) => {
            console.log(error);
            this.setState({
                 loading: false
        })
    });
    }

    getSalesListParam = (field,sort) => {
        this.setState({
            salesList: [],
            loading: true
        })
        let url = `api/v1/sale/list?name=${this.state.searchName}&page=${this.state.page}&size=${this.state.size}`;
        if(this.state.startDate && this.state.endDate){
          url+= `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
        }else if(this.state.startDate && (!this.state.endDate)){
          url+= `&startDate=${this.state.startDate}`;
        }else if(this.state.endDate && (!this.state.startDate)){
          url+= `&endDate=${this.state.endDate}`;
        }

        else if(field && field == "sales_id"){
            url+= `&sortBy=sales_id&orderBy=${sort}`;
          }

          else if(field && field == "customer_name"){
            url+= `&sortBy=customer_name&orderBy=${sort}`;
          }

          else if(field && field == "productType.typeName"){
            url+= `&sortBy=typeName&orderBy=${sort}`;
          }
          else if(field && field == "price"){
            url+= `&sortBy=price&orderBy=${sort}`;
          }
          else if(field && field == "createdAt"){
            url+= `&sortBy=createdAt&orderBy=${sort}`;
          }
          else if(field && field == "createdAt"){
            url+= `&sortBy=createdAt&orderBy=${sort}`;
          }
          else if(field && field == "seller.name"){
            url+= `&sortBy=seller_agent&orderBy=${sort}`;
          }

          else if(field && field == "paymentStatus.statusName"){
            url+= `&sortBy=statusName&orderBy=${sort}`;
          }


          
          
          
 

        serviceGet(url,{
             'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
          .then((res)=>{
              if(res.data){
                this.setState({
                    salesList: res.data.responseObject,
                    pageCount: res.data.totalElements <10 ? 1 : Math.ceil(res.data.totalElements / 10),
                    loading: false
                },()=>{this.salesList = this.state.salesList;console.log(this.salesList)})
             }
        }).catch((error) => {
            console.log(error);
            this.setState({
                 loading: false
        })
    });
    }

    createSale = () =>{
        if(this.state.customer === null || this.state.customer === undefined || this.state.customer === "" ||
        this.state.seller === null || this.state.seller === undefined || this.state.seller === "" || 
        
        
        this.state.productType === null || this.state.productType === undefined || this.state.productType === "" 
        || this.state.paymentStatus === null || this.state.paymentStatus === undefined || this.state.paymentStatus === ""
        
        ){
            toast('Please fill all the fields.',{bodyClassName:'error-toast'});
            return;
        }
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
         this.setState(()=>({modalLoader: true}));
        let sale = {
            'customerId':this.state.customer.value,
            "price": this.state.price,
            "seller": this.state.seller.value,
            "productId": this.state.productType.value,
            "paymentStatusId": this.state.paymentStatus.value,
            "saleId":this.state.saleId
        }
        if(this.state.saleId){
            servicePost(`api/v1/sale/saleUpdate`,
            JSON.stringify(sale),
            headers,)
            .then((res)=>{
                if(res.data){    
                    toast('Sale updated successfully',{bodyClassName:'success-toast'});
                    this.getSalesList();
                    this.toggle();
                    this.setState(()=>({modalLoader: false}));
                }
            });
        } else {
        servicePost('api/v1/sale',JSON.stringify(sale),headers)
        .then((res) => {
            if(res.data) {
                toast('Sale created successfully',{bodyClassName:'success-toast'});
                this.getSalesList();
                this.toggle();
                this.setState(()=>({modalLoader: false}));
            }
         });
      }
    }

    toggle = (modal, sale) => {
        debugger;
        if(sale != null) {
            let seller = {
                'label':sale.seller_agent?.name,
                'value':sale.seller_agent?._id
            }
            let customer = {
                'label':sale.customer_name,
                'value':sale.customer_id
            }
            let paymentStatus = {
                'label':sale.paymentStatus.statusName,
                'value':sale.paymentStatus._id
            }
            let productType = {
                'label':sale.product_id?.typeName,
                'value':sale.product_id?._id
            }
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                saleId:sale._id,
                price:sale.product_id.price,
                seller:seller,
                customer:customer,
                productType:productType,
                paymentStatus:paymentStatus
            }))
        } else {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                saleId:null,
                customer: '',
                price:null,
                seller:'',
                productType:'',
                paymentStatus:''
            }))
        }
    };

    getSellers=(seller)=>{
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        if(seller.length > 0){
       serviceGet(`api/v1/agent/list?name=${seller}&page=${1}&size=${10}`,headers)
          .then((res)=>{
              let sellerObj=[];
              for(var i=0;i<res.data.responseObject.length;i++){
                  sellerObj.push({
                      'value':res.data.responseObject[i]._id,
                      'label':res.data.responseObject[i].name
                  });
              }
            //   if(res.data){
                this.setState({
                    sellers: sellerObj
                });
            //  }
         });
      }
    }
    getCustomers=(customer)=>{
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        if(customer.length > 0){
       serviceGet(`api/v1/customer/list?keyword=${customer}&page=${1}&size=${100}`,headers)
          .then((res)=>{
              let customerObj=[];
              customerObj = res.data.responseObject.map(data=>{ return { value:data._id,label:data.name,seller: data.seller} });
            //   for(var i=0;i<res.data.responseObject.length;i++){
            //       customerObj.push({
            //           'value':res.data.responseObject[i]._id,
            //           'label':res.data.responseObject[i].name
            //       });
            //   }
            //   if(res.data){
                this.setState({
                    customers: customerObj
                });
            //  }
         });
      }
    }

    onChangeSeller = async (selectedValue) =>{
        this.setState({
            seller:selectedValue
        });
    }
    onChangeCustomer = async (selectedValue) =>{
        debugger;
        this.setState({
            customer:selectedValue,
            seller: {
                label : selectedValue.seller.name,
                value : selectedValue.seller._id,
            }
        });
        
    }
    onChangeProduct = async (selectedValue) =>{
      console.log(selectedValue);
      console.log(this.state.productsList);
      let selectedProduct = this.state.productsList.responseObject.filter((item)=>{
        return item._id === selectedValue.value
      });
      this.setState({
          productType:selectedValue,
          price: selectedProduct[0].price
        });
    }
    onChangePayment = async (selectedValue) =>{
      console.log(selectedValue)
        this.setState({
            paymentStatus:selectedValue
        });
    }

    handleChange = (event) => {
        console.log("============================= ",event.target)
        if(event.target.name === 'startDate' || event.target.name === 'endDate'){
          let date = new Date(event.target.value);
          date.setHours(0,0,0,0);

          this.setState({
            [event.target.name]: date.toISOString()
          },()=>{
            this.setState({page :1},()=>{
                if(this.state.startDate != null && this.state.endDate != null){
                    this.getSalesListParam();
                }
            });
          });


        }else{
        this.setState({
            [event.target.name]: event.target.value
        });
       }
    }

    searchByName = (name) =>{
        if(!name){
            this.setState({
                searchName: ''
            }, () => this.getSalesList())
        } else {
            let headers = {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.state.user.token
            };
            console.log("test");
            if(name.length >= 1) {
                this.setState({
                    salesList: [],
                    searchName: name,
                    loading: true
                })
                let url = `api/v1/sale/list?name=${this.state.searchName}&page=${1}&size=${this.state.size}`;
                if(this.state.startDate && this.state.endDate){
                url+= `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
                }else if(this.state.startDate && (!this.state.endDate)){
                url+= `&startDate=${this.state.startDate}`;
                }else if(this.state.endDate && (!this.state.startDate)){
                url+= `&endDate=${this.state.endDate}`;
                }
                serviceGet(url,headers)
                .then((res) => {
                    if(res.data) {
                        this.setState({
                            page : 1, 
                            currentPage : 0,
                            loading: false,
                            salesList: res.data.responseObject,
                            pageCount: res.data.totalElements <10 ? 1 : Math.ceil(res.data.totalElements / 10)
                        });
                    }
                }).catch((error) => {
                    console.log(error);
                    this.setState({
                         loading: false
                    })
                });
            }
        }
    }

    changePage = ({selected})=>{
       this.setState({
            page : selected + 1,
            currentPage: selected,
            salesList: [],
       },()=>{this.getSalesList()});
    }
    getExportData = (cutomerName = null, callback) => {
        this.setState({
            searchName: cutomerName
        })
        if (cutomerName == null) { cutomerName = "" }
        let url = `api/v1/sale/report/export?name=${cutomerName}&page=${this.state.page}&size=${this.state.size}`;
        if (this.state.startDate && this.state.endDate) {
            url += `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
        } else if (this.state.startDate && (!this.state.endDate)) {
            url += `&startDate=${this.state.startDate}`;
        } else if (this.state.endDate && (!this.state.startDate)) {
            url += `&endDate=${this.state.endDate}`;
        }
        serviceGet(url, {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
            .then((res) => {
                if (res.data) {
                    console.log("DATA EX", res.data.responseObject);
                    callback(res.data.responseObject)
                    console.log(res.data.responseObject);
                }
            }).catch((error) => {
                console.log(error);
                this.setState({
                    loading: false
                })
            });
    }
    render() {
        const MyExportCSV = (props) => {
            const handleClick = () => {
                this.getExportData(this.state.searchName, (responseObject) => {
                    props.onExport(responseObject);
                });
            };
            return (
                <div>
                    <button className="btn btn-sm btn-outline-success" onClick={handleClick}>
                        <i className="uil uil-file-download-alt mr-2"></i>
                        Export to CSV
                    </button>
                </div>
            );
        };
            const saleColumns = [
            {
                dataField: '_id',
                text: <CustomInput type="checkbox"/>,
                formatter : (cell,row,index)=>{
                  return (<React.Fragment><CustomInput 
                    className="rowCheckbox" type="checkbox" id={row._id}/></React.Fragment>)
                },
                csvExport: false,
            },    
            {
                dataField: 'sales_id',
                text: 'Sales ID',
                // style: { width: '10%' },
                sort: true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            {row.sales_id}
                        </React.Fragment>)
                },
                onSort: (field, order) => {
                  
                    this.getSalesListParam(field, order)
                  
                   }

            },
            {
                dataField: 'customer_name',
                text: 'Customer Name',
                sort:true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            {row.customer_name}
                        </React.Fragment>)
                },
                onSort: (field, order) => {
                  
                    this.getSalesListParam(field, order)
                  
                   }
            },
            {  
                dataField: 'product_id.typeName',
                text: 'Product Type',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            {row.product_id.typeName}
                        </React.Fragment>)
                },
                onSort: (field, order) => {
                  
                    this.getSalesListParam(field, order)
                  
                   }
            },
            { 
                dataField: 'product_id.price',
                text: 'Price',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            {"$ "+row.product_id.price}
                        </React.Fragment>)
                }
                ,
                onSort: (field, order) => {
                  
                    this.getSalesListParam(field, order)
                }
                
            },
            {   
                dataField: 'createdAt',
                text: 'Buy Time/Date',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <div>{moment(cell).format('MM-DD-YYYY')}</div>
                        </React.Fragment>)
                }
                ,
                onSort: (field, order) => {
                  
                    this.getSalesListParam(field, order)
                }

            },
            {   
                dataField: 'seller_agent.name',
                text: 'Seller',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            {
                            row.seller_agent.name
                            }
                        </React.Fragment>)
                } , onSort: (field, order) => {
                  
                    this.getSalesListParam(field, order)
                  
                   }
            },
            {   
                dataField: 'paymentStatus.statusName',
                text: 'Payment Status',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            {row.paymentStatus.statusName}
                        </React.Fragment>)
                }
                , onSort: (field, order) => {
                  
                    this.getSalesListParam(field, order)
                  
                   }
            },
            {   
                dataField: 'position',
                text: 'Action',
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>  
                            <div className="text-success pl-3"><i className="uil uil-edit" onClick={(e) => {this.toggle('editSale',row);}}></i></div>
                        </React.Fragment>)
                },
                csvExport: false,
            },
        ]
        return (
             <React.Fragment>
                 { this.state.pageLoading ? <Loader/> : 
            <div className="container-fluid">
                <div className="card shadow mt-4">
                    <div className="card-header page-heading pt-4 pb-3">
                        <div className="row">
                          <div className="col-md-12">
                                <h3 className="text-dark">List of Sale Operation</h3>
                            </div>
                            <div className="col-md-3 pt-3">
                                <div className="text-md-left dataTables_filter search-box-div" id="dataTable_filter">
                                  <i className="uil uil-search search-icon"></i>
                                  {/* <input type="search" id="searchByName" className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search" onChange={(event)=>{this.searchByName(event.target.value)}}/> */}
                                  <input type="search"  id="searchByName" value={this.state.searchName} className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search" onChange={(event)=>{
                                        this.setState({
                                            searchName : event.target.value
                                        },()=>{
                                            this.searchByName(this.state.searchName)
                                        })
                                    }}/>
                                </div>
                            </div>
                            <div className="col-md-3 pt-3">
                                <div className="input-group">
                                   <label className="mt-2 mr-1">Start Date</label>
                                   <input type="date" id="startDate" name="startDate" className="form-control date-box" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={this.handleChange}/>
                                </div>
                            </div>
                            <div className="col-md-3 pt-3">
                                <div className="input-group">
                                   <label className="mt-2 mr-1">End Date</label>
                                   <input type="date" id="endDate" name="endDate" className="form-control date-box" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={this.handleChange}/>
                                </div>
                            </div>
                            <div className="col-md-2 text-md-right pt-3">
                            { this.state.user.roles.indexOf('addSale') > -1 ?
                                <button type="button" className="btn btn-sm btn-primary px-3 py-2" onClick={(e) => {this.toggle();}}>Add Sale</button> : null
                            }
                            </div>
                            <div className="col-md-1 mt-2 font-size-20 pt-3">
                                <i className="uil uil-sync" onClick={(e)=>{
                                        this.setState({
                                            searchName : '',
                                            startDate : null,
                                            endDate : null,
                                            currentPage : 0,
                                            page:1
                                        },()=>{
                                            document.getElementById("startDate").value = "";
                                            document.getElementById("endDate").value = "";
                                            this.getSalesList()
                                        })
                                    }}></i>
                            </div>
                        </div>
                    </div>
                    <div className="card-body p-0">       
                        <div className="table-responsive table" id="dataTable" role="grid" aria-describedby="dataTable_info">
                            <ToolkitProvider
                                bootstrap4
                                keyField="id"
                                data={this.state.salesList}
                                columns={saleColumns}
                                exportCSV={{
                                    fileName: 'SalesList_Report_' + Date.now() + '.csv',
                                }}
                                
                                // search
                                // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                                >
                                {props => (
                                    <React.Fragment>
                                         <div className="grid-action-row border-top p-2 pl-4">
                                                <MyExportCSV {...props.csvProps} />
                                            </div>
                                        <BootstrapTable
                                            {...props.baseProps}
                                            bordered={false}
                                            wrapperClasses="table-responsive pl-3 pr-3"
                                            noDataIndication={ this.state.loading ? <Loader/> : 'No Data Found'}
                                        />
                                    </React.Fragment>
                                )}
                            </ToolkitProvider>  
                        </div> 
                    </div>
                </div>
                <div className="row">
                    <div className="text-nowrap mt-4">
                                {/* <div id="dataTable_length" className="dataTables_length" aria-controls="dataTable"><label>Show&nbsp;<select className="form-control form-control-sm custom-select custom-select-sm"><option value="10" selected="">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select>&nbsp;</label></div> */}
                                <ReactPaginate previousLabel={"Previous"} 
                                pageCount={this.state.pageCount}
                                nextLabel={"Next"} 
                                forcePage={this.state.currentPage}
                                onPageChange={this.changePage} 
                                containerClassName={"paginationBttns"}
                                previousLinkClassName={"previousBttn"} nextLinkClassName={"nextBttn"}
                                activeLinkClassName={"paginationActive"} disabledClassName={"paginationDisabled"}></ReactPaginate>
                    </div>
                </div>
                <Modal
                    isOpen={this.state.modal}
                    toggle={this.toggle}
                    className={this.state.className}
                    size='lg'>
                        <div><ModalHeader toggle={this.toggle}>{this.state.modalType === 'editSale'? 'Update Sale Operation' : 'Create Sale Operation'}</ModalHeader>
                         <AvForm onValidSubmit={this.createSale}>
                            <ModalBody>
                                {this.state.modalLoader? <Loader/> : <Row>
                                    <Col md={6}>
                                        <AvGroup row>
                                            <Col sm={12}>
                                                <Label for="example">Customer Name</Label>
                                                <Select
                                                  onInputChange={(value) => this.getCustomers(value)}
                                                  onChange={this.onChangeCustomer}
                                                  value={[{'value':this.state.customer?.value,'label':this.state.customer?.label}]}
                                                   // isMulti={true}
                                                   options={this.state.customers}
                                                   className="react-select"
                                                   classNamePrefix="react-select"
                                                   placeholder={'Search customer'}
                                                 />
                                          </Col>
                                         </AvGroup>
                                    </Col>
                                    <Col md={6}>
                                        <AvGroup row>
                                            <Col sm={12}>
                                                <Label for="example">Product Type</Label>
                                                <Select
                                                  onChange={this.onChangeProduct}
                                                  value={[{'value':this.state.productType?.value,'label':this.state.productType?.label}]}
                                                   // isMulti={true}
                                                   options={this.state.products}
                                                   className="react-select"
                                                   classNamePrefix="react-select"
                                                   placeholder={'Select product type'}
                                                 />
                                          </Col>
                                         </AvGroup>
                                    </Col>
                                    <Col md={6}>
                                        <AvField name="price" label="Price" type="text" required placeholder="Enter Price" autoComplete="false" value={this.state.price} onChange={this.handleChange}
                                          validate = {{required: {value: true}}} disabled/>
                                    </Col>
                                    <Col md={6}>
                                        <AvGroup row>
                                            <Col sm={12}>
                                                <Label for="example">Seller</Label>
                                                <Select
                                                  onInputChange={(value) => this.getSellers(value)}
                                                  onChange={this.onChangeSeller}
                                                  value={[{'value':this.state.seller?.value,'label':this.state.seller?.label}]}
                                                   // isMulti={true}
                                                   options={this.state.sellers}
                                                   className="react-select"
                                                   classNamePrefix="react-select"
                                                   placeholder={'Search seller'}
                                                 />
                                          </Col>
                                         </AvGroup>
                                    </Col>
                                    <Col md={6}>
                                        <AvGroup row>
                                            <Col sm={12}>
                                                <Label for="example">Payment Status</Label>
                                                <Select
                                                  onChange={this.onChangePayment}
                                                  value={[{'value':this.state.paymentStatus?.value,'label':this.state.paymentStatus?.label}]}
                                                   // isMulti={true}
                                                   options={this.state.paymentStatuses}
                                                   className="react-select"
                                                   classNamePrefix="react-select"
                                                   placeholder={'Select payment status'}
                                                 />
                                          </Col>
                                         </AvGroup>
                                    </Col>
                                </Row>}
                            </ModalBody>
                            <ModalFooter>
                                <button className="btn btn-outline-primary btn-lg">{this.state.modalType === 'editSale'? 'Update' : 'Create'}</button>
                                <button className="btn btn-outline-danger btn-lg" onClick={this.toggle}>Cancel</button>
                            </ModalFooter>
                          </AvForm> 
                       </div>
                </Modal>
            </div>
            }
            </React.Fragment>
        )
    }
}
export default Sales;