import AvField from 'availity-reactstrap-validation/lib/AvField';
import AvForm from 'availity-reactstrap-validation/lib/AvForm';
import React, { Component } from 'react';
import Loader from '../../components/Loader';
import ReactPaginate from 'react-paginate';
import { Modal, ModalFooter, Col, ModalBody, ModalHeader, Row, Button, Table, CustomInput } from 'reactstrap';
import { getLoggedInUser } from '../../helpers/authUtils';
import { serviceGet, servicePost, servicePut } from './../../helpers/api';
import profilePic from '../../assets/images/users/avatar-7.jpg';
import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import { toast } from 'react-toastify';
import moment from 'moment';
import { SERVICE_URL, DEFAULT_SERVICE_VERSION } from '../../constants/utility';
class ViewSettlementCommissionDetails extends Component {
    constructor(props) {
        super(props);

        this.state = {
            user: getLoggedInUser(),
            modal: false,
            loading: true,
            pageLoading: false,
            salesList: [],
            name: '',
            paymentStatusId: null,
            currentPage: 1,
            size: 3,
            pageCount: 1,
            statusName: null,
            description: null,
            settleAmount: null,
            saleId: null,
            sale: null,
            agent: this.props.location.state !== undefined ? this.props.location.state.agent : null,
            totalPrice: 0,
            totalEarnings: 0,
            totalSettlement:0
        };
        this.changePage = this.changePage.bind(this);
        this.getSalesList = this.getSalesList.bind(this);
        this.settleCommission = this.settleCommission.bind(this);
    }

    componentDidMount() {
        this.getSalesList();
    }

    getSalesList = () => {
        this.setState({
            salesList: [],
            loading: false
        })
        console.log(this.props.location);
        if (this.state.agent) {
            this.setState({
                salesList: [],
                loading: true
            })
            let url = 'api/v1/sale/list/agent/byAgent'




            // ?agentId=${this.state.agent._id}&page=${this.state.currentPage}&size=${this.state.size}`;
            // if(this.state.startDate && this.state.endDate){
            // url+= `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
            // }else if(this.state.startDate && (!this.state.endDate)){
            // url+= `&startDate=${this.state.startDate}`;
            // }else if(this.state.endDate && (!this.state.startDate)){
            // url+= `&endDate=${this.state.endDate}`;
            // }

            let obj = {}
            obj.agentId = this.state.agent._id
            obj.page = this.state.currentPage
            obj.size = this.state.size
            obj.startDate = this.state.startDate
            obj.endDate = this.state.endDate


            servicePost(url, obj, {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.state.user.token
            })
                .then(async (res) => {
                    if (res.data) {

                        console.log("&************** ==>   " + JSON.stringify(res.data.responseObject));
                        await this.gettotalPrice(res.data.responseObject)
                        this.setState({
                            salesList: res.data.responseObject,
                            pageCount: res.data.totalElements < 10 ? 1 : Math.ceil(res.data.totalElements / 10),
                            loading: false
                        }, () => { this.salesList = this.state.salesList; console.log(this.salesList) })
                    }
                }).catch((error) => {
                    console.log(error);
                    this.setState({
                        loading: false
                    })
                });
        }
    }

    settleCommission = () => {
        console.log("inside settle Commission");
        if (this.state.settleAmount === null) {
            toast('Please add settlement amount.', { bodyClassName: 'error-toast' });
            return;
        } else if (this.state.sale.earnings < this.state.settleAmount) {
            toast('Settlement amount must be less than earnings', { bodyClassName: 'error-toast' });
            return;
        }
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        let settlement = {
            'settledAmount': this.state.settleAmount,
            'agentId': this.state.agent._id,
            'sales_id': this.state.saleId,
            'paymentstatus': this.state.paymentStatusId
        }
        console.log(this.state.saleId);
        if (this.state.saleId) {
            servicePut(`api/v1/agent/sale/${this.state.saleId}/settle`,
                JSON.stringify(settlement), headers)
                .then((res) => {
                    if (res.data) {
                        this.toggle();
                        toast('Product Settled successfully', { bodyClassName: 'success-toast' });
                        this.getSalesList();
                    }
                }).catch((error) => {
                    console.log(error);
                    this.setState({
                        loading: false
                    })
                    toast('Some error Occured', { bodyClassName: 'error-toast' });
                })
        }
    }

    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });
    }

    changePage = ({ selected }) => {
        this.setState({
            currentPage: selected + 1,
            salesList: []
        }, () => { this.getSalesList() });
    }


    toggle = (modal, sale) => {
        if (sale != null) {

            //console.log("*************************** sale",JSON.stringify(sale))
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                saleId: sale._id,
                sale: sale,
                settleAmount: sale.settleAmount,
                paymentStatusId: sale.paymentStatus._id
            }))
        } else {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                sale: null,
                saleId: null,
                settleAmount: null,
                paymentStatusId: null

            }))
        }
    };
    async gettotalPrice(arr) {
        let price = 0;
        let earns = 0;
        let settment= 0;
        if (arr && arr.length > 0) {
            for (let a = 0; a < arr.length; a++) {
                let a_ = arr[a]
                price = price + Number(a_.productsData.price)
                earns = earns + Number(a_.settleAmount)
                settment = settment + Number((a_.settlledAmount)?a_.settlledAmount:0)
            }
        }
       

        this.setState({
            totalPrice: price,
            totalEarnings: earns,
            totalSettlement:settment
        })

    }

    render() {

        const saleColumns = [
            {
                dataField: '_id',
                text: <CustomInput type="checkbox" />,
                formatter: (cell, row, index) => {
                    return (<React.Fragment><CustomInput className="rowCheckbox" type="checkbox" id={row._id} /></React.Fragment>)
                },
                footer: ''
            },
            {
                dataField: 'sales.sales_id',
                text: 'Sales ID',
                // style: { width: '10%' },
                sort: true,
                footer: '',

                // formatter: (cell, row, rowIndex) => {
                //     return (<React.Fragment>
                //         {row.sales_id}
                //     </React.Fragment>)
                // }
            },
            {
                dataField: 'sales.customer_name',
                text: 'Customer Name',
                sort: true,
                // formatter: (cell, row, rowIndex) => {
                //     return (<React.Fragment>
                //         {row.customer_name}
                //     </React.Fragment>)
                // },
                footer: ''
            },
            {
                dataField: 'productsData.typeName',
                text: 'Product Type',
                sort: true,
                // formatter: (cell, row, rowIndex) => {
                //     return (<React.Fragment>
                //         {row.product_id.typeName}
                //     </React.Fragment>)
                // },
                 footer: ''
            },
            {
                dataField: 'productsData.price',
                text: 'Price',
                sort: true,
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>
                        {"$ "+row.productsData.price}
                    </React.Fragment>)
                },

                footer: "$ " + this.state.totalPrice
            },
            {
                dataField: 'settleAmount',
                text: 'Earning',
                sort: true,
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>
                        {'$ ' + row.settleAmount}
                    </React.Fragment>)
                }, 
                footer: "$ " + this.state.totalEarnings
            },
            {
                dataField: 'settleAmount',
                text: 'Settle Amount',
                sort: true,
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>
                        {                           
                         '$ ' + row.settlledAmount
                        }
                    </React.Fragment>)
             }, footer: "$ " + this.state.totalSettlement


            },
            {
                dataField: 'settlementDate',
                text: 'Buy Time/Date',
                sort: true,
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>

                        <div>{row.settlementDate ? moment(row.settlementDate).format('MM-DD-YYYY') : '-'}</div>



                    </React.Fragment>)
                }
            },
            {
                dataField: 'payment.statusName',
                text: 'Payment Status',
                sort: true,
                // formatter: (cell, row, rowIndex) => {
                //     return (<React.Fragment>
                //         {row.paymentStatus.statusName}
                //     </React.Fragment>)
                // }
            },
            {
                dataField: 'position',
                text: 'Action',
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>
                        <div className="text-success pl-3"><i className="uil uil-edit" onClick={(e) => { this.toggle('editSettlementCommission', row); }}></i></div>
                    </React.Fragment>)
                }
            },
        ]
       
        return (
            
            <React.Fragment>{this.state.pageLoading ? <Loader /> : <>
                <div className="container-fluid">
                    <div className="card mt-4">
                        <div className="card-header page-heading pt-4 pb-3">
                            <div className="row">
                                <div className="col-md-12">
                                    <h4 className="text-muted">
                                        <span>Settlement Commission Details</span>
                                        <span className="float-right"><i className="uil uil-sync pr-2" onClick={() => this.getSalesList()}></i></span>
                                    </h4>
                                </div>
                            </div>
                        </div>
                        <div className="card-body p-0">
                            <div className="row pb-4">
                                <div class="col-md-2 col-sm-4 col-xs-6 text-center">

                                    {/* <img style={{
                                        margin: 10,
                                        width: '160px',
                                        height: '160px'
                                    }} 
                                    src={
                                        this.props.location.state.agent ?
                                            this.props.location.state.agent.profile_pic
                                            : ""
                                    } className="rounded-circle" alt="user" /> */}

<img src={SERVICE_URL +"/"+ this.props.location.state.agent.profile_pic} className="rounded-circle"  onError={(e)=>{e.target.onerror = null; e.target.src=""+SERVICE_URL +"/default.png"}} alt="user" style={{
                                        margin: 10,
                                        width: '160px',
                                        height: '160px'
                                    }} />


                                    {/* <span className="avatar-sm rounded-circle mr-2 profile-pic" id="profile_pic"></span> */}
                                </div>
                                <div className="col-md-8 col-sm-7 col-xs-6 font-size-18 mt-4 ml-3 settlement-details">
                                    <div>{this.state.agent.name}</div>
                                    <div>{this.state.agent.phoneNumber}</div>
                                    {/* <div>Sangkat Tumnub Tek, # 31 វɧថªĢយĺម©ន, 12306</div> */}
                                    <div>{this.state.agent.email}</div>
                                </div>
                            </div>
                            <div className="row pb-3 float-right font-size-16 pr-5">Register Date : {moment(this.state.agent.createdAt).format('MM-DD-YYYY')}</div>
                            <div className="col-md-12 p-4"><hr /></div>
                        </div>
                    </div>
                </div>
                <div className="container-fluid">
                    <div className="card shadow mt-4">
                        <div className="card-header page-heading pt-4 pb-3">
                            <div className="row">
                                <div className="col-md-12">
                                    <h3 className="text-dark">List of Sale Product</h3>
                                </div>
                            </div>
                        </div>
                        <div className="card-body p-0">
                            <ToolkitProvider
                                bootstrap4
                                keyField="id"
                                data={this.state.salesList}
                                columns={saleColumns}
                            // search
                            // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                            >
                                {props => (
                                    <React.Fragment>
                                        <BootstrapTable
                                            {...props.baseProps}
                                            bordered={false}
                                            wrapperClasses="table-responsive pl-3 pr-3"
                                            noDataIndication={this.state.loading ? <Loader /> : 'No Data Found'}
                                        />
                                    </React.Fragment>
                                )}
                            </ToolkitProvider>


                        </div>
                    </div>
                    {// the pagination part
                    }
                    <div className="row">
                        <div className="text-nowrap mt-4">
                            <ReactPaginate previousLabel={"Previous"}
                                pageCount={this.state.pageCount}
                                nextLabel={"Next"}
                                onPageChange={this.changePage}
                                containerClassName={"paginationBttns"}
                                previousLinkClassName={"previousBttn"} nextLinkClassName={"nextBttn"}
                                activeLinkClassName={"paginationActive"} disabledClassName={"paginationDisabled"}>
                            </ReactPaginate>
                        </div>
                    </div>
                    <Modal
                        isOpen={this.state.modal}
                        toggle={this.toggle}
                        className={this.state.className}
                        size='md'>
                        <div><ModalHeader toggle={this.toggle}>Settle Commission Fee</ModalHeader>
                            <AvForm onValidSubmit={this.settleCommission}>
                                <ModalBody>
                                    <Row className="pb-2 pl-2 font-size-16">
                                        <div className="col-xs-4 text-dark ml-3">Agent Name:</div>
                                        <div className="col-xs-7 text-muted ml-3">{this.state.agent.name}</div>
                                    </Row>
                                    <Row className="pb-2 pl-2 font-size-16">
                                        <div className="col-xs-4 text-dark ml-3">Phone Number:</div>
                                        <div className="col-xs-7 text-muted ml-3">{this.state.agent.phoneNumber}</div>
                                    </Row>
                                    <Row className="pb-2 pl-2 font-size-16">
                                        <div className="col-xs-3 text-dark ml-3">Total earned:</div>
                                        <div className="col-xs-7 text-muted ml-3">{'$ ' + this.state.agent.earned}</div>
                                    </Row>
                                    <Row className="pb-2 pl-2 font-size-16">
                                        <Col md={12}>
                                            <label>Amount to settle</label><span className="text-danger pt-2"><sup>*</sup></span>
                                            <AvField name="settleAmount" type="text" required placeholder="Enter Amount" autoComplete="false" value={this.state.settleAmount} onChange={this.handleChange}
                                                validate={{ required: { value: true } }} />
                                        </Col>
                                    </Row>
                                </ModalBody>
                                <ModalFooter>
                                    <button className="btn btn-outline-primary btn-lg"  >{this.state.modalType === 'editSettlementCommission' ? 'Update' : 'Create'}</button>
                                    <button className="btn btn-outline-danger btn-lg" onClick={this.toggle}>Cancel</button>
                                </ModalFooter>
                            </AvForm>
                        </div>
                    </Modal>
                </div> </>
            }
            </React.Fragment>
        )
    }
}
export default ViewSettlementCommissionDetails;