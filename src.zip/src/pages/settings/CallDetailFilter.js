import React, { Component } from 'react';
import {
    Row,
    Col,
    Card,
    CardBody,
    TabContent,
    TabPane,
    Nav,
    NavItem,
    NavLink,
    Input,
    Button,
    Badge,
    UncontrolledTooltip,
    CustomInput,
} from 'reactstrap';
import classnames from 'classnames';
import PageTitle from '../../components/PageTitle';
import BootstrapTable from 'react-bootstrap-table-next';
import ToolkitProvider, { Search, CSVExport } from 'react-bootstrap-table2-toolkit';
import paginationFactory from 'react-bootstrap-table2-paginator';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import filterFactory, { selectFilter } from 'react-bootstrap-table2-filter';
import 'react-bootstrap-table2-filter/dist/react-bootstrap-table2-filter.min.css';
import { servicePost } from './../../helpers/api';
import { dateFormat, capitalize } from './../../helpers/common';
import { connect } from 'react-redux';
import { setDateRange } from '../../redux/actions';
import Moment from 'react-moment';
import { color } from 'd3';
import Loader from '../../components/Loader';
import UniversalDatePicker from '../miscellaneous/UniversalDatePicker';
import Select from 'react-select';
import * as FeatherIcon from 'react-feather';
import overlayFactory from 'react-bootstrap-table2-overlay';
import { Eye } from 'react-feather';
import SlidingPanel from 'react-sliding-side-panel';
import 'react-tippy/dist/tippy.css';
import { Tooltip } from 'react-tippy';
import InputRange from 'react-input-range';
import 'react-input-range/lib/css/index.css';
import { indexOf } from 'lodash';
import BetterDatePicker from '../miscellaneous/BetterDatePicker';
const queryString = require('query-string');

// const sizePerPageRenderer = ({ options, currSizePerPage, onSizePerPageChange }) => (
//     <React.Fragment>
//         <label className="d-inline mr-1">Show</label>
//         <Input
//             type="select"
//             name="select"
//             id="no-entries"
//             className="custom-select custom-select-sm d-inline col-2"
//             defaultValue={currSizePerPage}
//             onChange={(e) => onSizePerPageChange(e.target.value)}>
//             {options.map((option, idx) => {
//                 return <option key={idx}>{option.text}</option>;
//             })}
//         </Input>
//         <label className="d-inline ml-1">entries</label>
//     </React.Fragment>
// );
const sizePerPageRenderer = ({ options, currSizePerPage, onSizePerPageChange }) => (
    <React.Fragment>
        <label className="d-inline mr-1">Show</label>
        <Input
            type="select"
            name="select"
            id="no-entries"
            className="custom-select custom-select-sm d-inline col-2"
            defaultValue={currSizePerPage}
            onChange={(e) => onSizePerPageChange(e.target.value)}>
            {options.map((option, idx) => {
                return <option key={idx}>{option.text}</option>;
            })}
        </Input>
        <label className="d-inline ml-1">entries</label>
    </React.Fragment>
);

const { SearchBar } = Search;
const TableWithSearch = (props) => {
    const records = props.records;

    const isCallCompleted = (status) => {
        if (status == 'COMPLETED') {
            return true;
        }
        return false;
    };

    const tagToHtml = (str) => {
        if (str === null || str === '') return false;
        else str = str.toString();
        // Regular expression to identify HTML tags in
        // the input string. Replacing the identified
        // HTML tag with a null string.
        return str.replace(/(<([^>]+)>)/gi, '').substring(0, 50);
        // return contentValue
    };

    const getFormattedStatus = (status) => {
        if (status === 'COMPLETED') {
            return 'Review';
        } else if (status === 'WAITING') {
            return 'Waiting';
        } else if (status === 'ERROR') {
            return 'Error';
        }
        return 'Processing';
        // let formattedStatus = status.toLowerCase().split("_").join(" ");
        // return formattedStatus
    };

    const columns = [
        // {
        //     dataField: 'index',
        //     text: 'S No.',
        //     sort: true,
        //     style: { width: '7%' }
        // },

        {
            dataField: 'time',
            text: 'Call date/time',
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                    <Moment format="DD MMM YYYY">{row.time}</Moment> <Moment format="hh:mm A">{row.time}</Moment>
                </React.Fragment>
            ),
            sort: false,
            style: { width: '16.66%' },
            headerFormatter: (column, colIndex) => {
                return (
                    <div>
                        <div>{column.text}</div>
                        <div style={{ color: 'white' }}>()</div>
                    </div>
                );
            },
        },
        {
            dataField: 'callDuration',
            text: 'Duration',
            sort: true,
            // filter: selectFilter({
            //     options: callTypes,
            //     placeholder: 'All Call Types',
            // })
            style: { width: '16.66%' },
            headerFormatter: (column, colIndex) => {
                return (
                    <div>
                        <div class="text-right">{column.text}</div>
                        <div class="text-right">(mm:ss)</div>
                    </div>
                );
            },
        },
        {
            dataField: 'caller',
            text: 'Agent',
            sort: true,
            // style: { width: '10%' },
            // filter: selectFilter({
            //     options: agents,
            //     placeholder: 'All Agents',
            // })
            style: { width: '16.66%' },
            headerFormatter: (column, colIndex) => {
                return (
                    <div>
                        <div>{column.text}</div>
                        <div style={{ color: 'white' }}>()</div>
                    </div>
                );
            },
        },
        {
            dataField: 'to',
            text: 'To \r\n From',
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                    <div>{`${records[rowIndex].to}`}</div> <div>{records[rowIndex].from}</div>
                </React.Fragment>
            ),
            sort: false,
            style: { width: '16.66%' },
            headerFormatter: (column, colIndex) => {
                return (
                    <div>
                        <div class="text-right">{column.text}</div>
                        <div style={{ color: 'white' }}>()</div>
                    </div>
                );
            },
        },
        {
            dataField: 'callType',
            text: 'Type',
            sort: true,
            // filter: selectFilter({
            //     options: callTypes,
            //     placeholder: 'All Call Types',
            // })
            style: { width: '16.66%', textAlign: 'center' },
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                    {cell === 'Outgoing' ? (
                        <FeatherIcon.PhoneOutgoing id={'tbn-' + rowIndex} />
                    ) : (
                        <FeatherIcon.PhoneIncoming id={'tbn-' + rowIndex} />
                    )}
                    <UncontrolledTooltip placement="top" target={'tbn-' + rowIndex}>
                        {cell}
                    </UncontrolledTooltip>
                </React.Fragment>
            ),
            headerFormatter: (column, colIndex) => {
                return (
                    <div>
                        <div style={{ textAlign: 'center' }}>{column.text}</div>
                        <div style={{ color: 'white' }}>()</div>
                    </div>
                );
            },
        },
        {
            dataField: 'transcriptionJobStatus',
            text: 'Action',
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                    {isCallCompleted(records[rowIndex].transcriptionJobStatus) ? (
                        <Row>
                            <Col style={{ paddingRight: '0px' }} md={ 8 }>
                                <a
                                    target="_blank"
                                    style={{ color: 'white' }}
                                    href={`/analyse/calls/${records[rowIndex]._id}`}>
                                    <button
                                        style={{ width: '100%' }}
                                        className={`btn btn-${
                                        'primary'
                                        } btn-sm`}>
                                        {getFormattedStatus(records[rowIndex].transcriptionJobStatus)}
                                    </button>
                                </a>
                            </Col>
                        </Row>
                    ) : (
                        <button style={{ width: '100%' }} className="btn btn-secondary btn-sm">
                            {getFormattedStatus(records[rowIndex].transcriptionJobStatus)}
                        </button>
                    )}
                </React.Fragment>
            ),
            sort: false,
            style: { width: '16.66%' },
            headerFormatter: (column, colIndex) => {
                return (
                    <div>
                        <div>{column.text}</div>
                        <div style={{ color: 'white' }}>()</div>
                    </div>
                );
            },
        },
    ];

    const defaultSorted = [
        {
            dataField: 'id',
            order: 'asc',
        },
    ];

    const onTableChangeInternal = props.onTableChange;
    const totalSize = props.totalSize;
    const sizePerPage = props.sizePerPage;
    const isTableLoading = props.isTableLoading;

    return (
        <Card>
            <CardBody>
                {/* <h4 className="header-title mt-0 mb-1">Team List</h4> */}
                <ToolkitProvider
                    bootstrap4
                    keyField="id"
                    data={records}
                    columns={columns}
                    // search
                    exportCSV={{ onlyExportFiltered: true, exportAll: false }}>
                    {(props) => (
                        <React.Fragment>
                            <BootstrapTable
                                {...props.baseProps}
                                loading={isTableLoading}
                                bordered={false}
                                defaultSorted={defaultSorted}
                                pagination={paginationFactory({
                                    sizePerPage: sizePerPage,
                                    sizePerPageRenderer: sizePerPageRenderer,
                                    sizePerPageList: [
                                        { text: '5', value: 5 },
                                        { text: '10', value: 10 },
                                        { text: '25', value: 25 },
                                    ],
                                    totalSize: totalSize,
                                })}
                                wrapperClasses="table-responsive"
                                id="analysisTbl"
                                filter={filterFactory()}
                                remote={true}
                                onTableChange={onTableChangeInternal}
                                overlay={overlayFactory({
                                    spinner: true,
                                    styles: {
                                        overlay: (base) => ({ ...base, background: 'rgba(0, 0, 0, 0.4)', zIndex: 99 }),
                                    },
                                })}
                            />
                        </React.Fragment>
                    )}
                </ToolkitProvider>
            </CardBody>
        </Card>
    );
};
// Bhasad cause
// overlay={overlayFactory({
//                                     spinner: true,
//                                     styles: {
//                                         overlay: (base) => ({ ...base, background: 'rgba(0, 0, 0, 0.4)', zIndex: 99 }),
//                                     },
//                                 })}

const TableNegative = (props) => {
    console.log('tableNegative', props);
    const recordNeg = props.negRecords;
    const records = props.negRecords;

    const isCallCompleted = (status) => {
        if (status == 'COMPLETED') {
            return true;
        }
        return false;
    };

    const tagToHtml = (str) => {
        if (str === null || str === '') return false;
        else str = str.toString();
        // Regular expression to identify HTML tags in
        // the input string. Replacing the identified
        // HTML tag with a null string.
        return str.replace(/(<([^>]+)>)/gi, '').substring(0, 50);
        // return contentValue
    };

    const getFormattedStatus = (status) => {
        if (status === 'COMPLETED') {
            return 'Review';
        } else if (status === 'WAITING') {
            return 'Waiting';
        } else if (status === 'ERROR') {
            return 'Error';
        }
        return 'Processing';
        // let formattedStatus = status.toLowerCase().split("_").join(" ");
        // return formattedStatus
    };

    const columnsNeg = [
        // {
        //     dataField: 'index',
        //     text: 'S No.',
        //     sort: true,
        //     style: { width: '7%' }
        // },

        {
            dataField: 'time',
            text: 'Call date/time',
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                    <Moment format="DD MMM YYYY">{row.time}</Moment> <Moment format="hh:mm A">{row.time}</Moment>
                </React.Fragment>
            ),
            sort: false,
            style: { width: '16.66%' },
            headerFormatter: (column, colIndex) => {
                return (
                    <div>
                        <div>{column.text}</div>
                        <div style={{ color: 'white' }}>()</div>
                    </div>
                );
            },
        },
        {
            dataField: 'callDuration',
            text: 'Duration',
            sort: true,
            // filter: selectFilter({
            //     options: callTypes,
            //     placeholder: 'All Call Types',
            // })
            style: { width: '16.66%' },
            headerFormatter: (column, colIndex) => {
                return (
                    <div>
                        <div class="text-right">{column.text}</div>
                        <div class="text-right">(mm:ss)</div>
                    </div>
                );
            },
        },
        {
            dataField: 'caller',
            text: 'Agent',
            sort: true,
            style: { width: '16.66%' },
            // filter: selectFilter({
            //     options: agents,
            //     placeholder: 'All Agents',
            // })

            headerFormatter: (column, colIndex) => {
                return (
                    <div>
                        <div>{column.text}</div>
                        <div style={{ color: 'white' }}>()</div>
                    </div>
                );
            },
        },
        {
            dataField: 'to',
            text: 'To \r\n From',
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                    <div>{`${recordNeg[rowIndex].to}`}</div> <div>{recordNeg[rowIndex].from}</div>
                </React.Fragment>
            ),
            sort: false,
            style: { width: '16.66%' },
            headerFormatter: (column, colIndex) => {
                return (
                    <div>
                        <div class="text-right">{column.text}</div>
                        <div style={{ color: 'white' }}>()</div>
                    </div>
                );
            },
        },
        {
            dataField: 'callType',
            text: 'Type',
            sort: true,
            // filter: selectFilter({
            //     options: callTypes,
            //     placeholder: 'All Call Types',
            // })
            style: { width: '16.66%', textAlign: 'center' },
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                    {cell === 'Outgoing' ? (
                        <FeatherIcon.PhoneOutgoing id={'tbn-' + rowIndex} />
                    ) : (
                        <FeatherIcon.PhoneIncoming id={'tbn-' + rowIndex} />
                    )}
                    <UncontrolledTooltip placement="top" target={'tbn-' + rowIndex}>
                        {cell}
                    </UncontrolledTooltip>
                </React.Fragment>
            ),
            headerFormatter: (column, colIndex) => {
                return (
                    <div>
                        <div style={{ textAlign: 'center' }}>{column.text}</div>
                        <div style={{ color: 'white' }}>()</div>
                    </div>
                );
            },
        },
        // {
        //     dataField: 'feedbacks',
        //     text: 'Feedback',
        //     sort: true,
        //     // filter: selectFilter({
        //     //     options: callTypes,
        //     //     placeholder: 'All Call Types',
        //     // })
        //     style: { width: '15%' },
        //     formatter: (cell, row, rowIndex) => (
        //         <React.Fragment>
        //             {cell.length !== 0 ? (
        //                 <span
        //                     onClick={(e) => props.toggleSlider(cell[0].callId, cell[0].feedbackFormId)}
        //                     class="mr-1 badge font-weight-500 font-size-13 mt-1 badge badge-soft-secondary"
        //                     style={{ cursor: 'pointer' }}>
        //                     {
        //                         <div>
        //                             <div style={{ textAlign: 'left' }}>
        //                                 {cell[0].response.title}
        //                                 <Eye
        //                                     style={{ cursor: 'pointer', float: 'right' }}
        //                                     onClick={() => {
        //                                         //   props.seekToTime(keyword.keyword);
        //                                     }}
        //                                     className="ml-2"
        //                                     size={12}
        //                                 />
        //                             </div>

        //                             <div className="mt-1" style={{ fontSize: '.82em' }}>
        //                                 <Moment format="DD MMM YYYY">{cell[0].response.createdAt}</Moment>{' '}
        //                                 <Moment format="hh:mm A">{cell[0].response.createdAt}</Moment>
        //                             </div>
        //                         </div>
        //                     }
        //                 </span>
        //             ) : (
        //                 ''
        //             )}
        //         </React.Fragment>
        //     ),
        //     headerFormatter: (column, colIndex) => {
        //         return (
        //             <div>
        //                 <div>{column.text}</div>
        //                 <div style={{ color: 'white' }}>()</div>
        //             </div>
        //         );
        //     },
        // },

        // {
        //     dataField: 'callId',
        //     text: '',
        //     headerFormatter:(column, colIndex)=> {return ( <div><div class="text-right">Moment groups</div><div class="text-right">achieved</div></div>);
        //     },
        //     // headerFormatter: (column, colIndex, components) =><React.Fragment>Moment groups<br/>achieved</React.Fragment>,
        //     formatter: (cell, row, rowIndex) =><React.Fragment><div style={{ textAlign : "center"}}>{`${(isCallCompleted(records[rowIndex].transcriptionJobStatus)) ? `${records[rowIndex].moment.momentGroupsAchieved}/${records[rowIndex].moment.totalMomentGroups}`: '-'}`}</div></React.Fragment>,
        //     sort: false,
        //     style: { width: '17%' },
        // },
        // {
        //     dataField: 'callId',
        //     text: '',
        //     headerFormatter: (column, colIndex, components) =><React.Fragment>Moments<br/>achieved</React.Fragment>,
        //     formatter: (cell, row, rowIndex) =><React.Fragment><div style={{ textAlign : "center"}}>{`${(isCallCompleted(records[rowIndex].transcriptionJobStatus)) ? `${records[rowIndex].moment.momentsAchieved}/${records[rowIndex].moment.totalMoments}` : '-'}`}</div></React.Fragment>,
        //     sort: false,
        //     style: { width: '15%' },
        // },
        // {
        //     dataField: 'words',
        //     text: 'Keywords',
        //     sort: false,
        //     formatter: (cell, row) =><React.Fragment><Badge color={`soft-secondary`} key="secondary" className="mr-1 badge call-badges font-weight-500 font-size-14">{row.words}</Badge></React.Fragment>,
        //     filter: selectFilter({
        //         options: swearWords,
        //         placeholder: 'All Swear Words',
        //     })
        // },
        {
            dataField: 'transcriptionJobStatus',
            text: 'Action',
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                    {isCallCompleted(records[rowIndex].transcriptionJobStatus) ? (
                        <Row>
                            <Col style={{ paddingRight: '0px' }} md={records[rowIndex].feedbacks.length > 0 ? 8 : 12}>
                                <a
                                    target="_blank"
                                    style={{ color: 'white' }}
                                    href={`/analyse/calls/${records[rowIndex]._id}`}>
                                    <button
                                        style={{ width: '100%' }}
                                        className={`btn btn-${
                                            records[rowIndex].feedbacks.length > 0 ? 'success' : 'primary'
                                        } btn-sm`}>
                                        {records[rowIndex].feedbacks.length > 0 ? 'Reviewed' : 'Review'}
                                    </button>
                                </a>
                            </Col>
                            {records[rowIndex].feedbacks.length > 0 && (
                                <Col style={{ paddingRight: '0px' }} md={4}>
                                    <Tooltip
                                        // options
                                        title={`View Feedback`}
                                        position="top-end"
                                        arrow={true}
                                        trigger="mouseenter">
                                        <button
                                            onClick={(e) =>
                                                props.toggleSlider(
                                                    records[rowIndex].feedbacks[0].callId,
                                                    records[rowIndex].feedbacks[0].feedbackFormId
                                                )
                                            }
                                            style={{ width: '100%' }}
                                            className={'btn btn-secondary btn-sm'}>
                                            <Eye style={{ cursor: 'pointer' }} size={12} />
                                        </button>
                                    </Tooltip>
                                </Col>
                            )}
                        </Row>
                    ) : (
                        <button style={{ width: '100%' }} className="btn btn-secondary btn-sm">
                            {getFormattedStatus(records[rowIndex].transcriptionJobStatus)}
                        </button>
                    )}
                </React.Fragment>
            ),
            sort: false,
            style: { width: '16.66%' },
            headerFormatter: (column, colIndex) => {
                return (
                    <div>
                        <div>{column.text}</div>
                        <div style={{ color: 'white' }}>()</div>
                    </div>
                );
            },
        },
    ];

    const defaultSorted1 = [
        {
            dataField: 'id',
            order: 'asc',
        },
    ];

    const onTableChangeInternalNegative = props.onTableChangeNeg;
    const totalSize1 = props.totalSize1;
    const sizePerPage1 = props.sizePerPage1;
    const isTableLoading1 = props.isTableLoading1;

    return (
        <Card>
            <CardBody>
                {/* <h4 className="header-title mt-0 mb-1">Team List</h4> */}
                <ToolkitProvider
                    bootstrap4
                    keyField="id"
                    data={recordNeg}
                    columns={columnsNeg}
                    // search
                    // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                >
                    {(props) => (
                        <React.Fragment>
                            <BootstrapTable
                                {...props.baseProps}
                                loading={isTableLoading1}
                                bordered={false}
                                defaultSorted={defaultSorted1}
                                pagination={paginationFactory({
                                    sizePerPage: sizePerPage1,
                                    sizePerPageRenderer: sizePerPageRenderer,
                                    sizePerPageList: [
                                        { text: '5', value: 5 },
                                        { text: '10', value: 10 },
                                        { text: '25', value: 25 },
                                    ],
                                    totalSize: totalSize1,
                                })}
                                wrapperClasses="table-responsive"
                                id="analysisTbl"
                                filter={filterFactory()}
                                remote={true}
                                onTableChange={onTableChangeInternalNegative}
                                overlay={overlayFactory({
                                    spinner: true,
                                    styles: {
                                        overlay: (base) => ({ ...base, background: 'rgba(0, 0, 0, 0.4)', zIndex: 99 }),
                                    },
                                })}
                            />
                            {/* <BootstrapTable
                                    {...props.baseProps}
                                    bordered={false}
                                    defaultSorted={defaultSorted1}
                                    pagination={paginationFactory({ sizePerPage: 10,  sizePerPageList: [{ text: '5', value: 5, }, { text: '10', value: 10 }, { text: '25', value: 25 }] })}
                                    wrapperClasses="table-responsive"
                                /> */}
                        </React.Fragment>
                    )}
                </ToolkitProvider>
            </CardBody>
        </Card>
    );
};

class CallDetail extends Component {
    constructor(props) {
        super(props);
        console.log(props);
        this.state = {
            activeTab: '1',
            records: [],
            loading: false,
            tableLoader: false,
            momentData: '',
            groupData: '',
            agentTotalCall: '',
            currentTotal: '',
            callerName: '',
            agentsOptions: '',
            teamOptions: '',
            selectAgent: [],
            selectMoment: '',
            selectedTeam: '',
            selectedGroup: '',
            sizePerPage: 25,
            page: 1,
            total: 0,
            isTableLoading: false,
            getTotalCalls: false,
            dateRange: this.props.dateRange,
            negRecords: [],
            pageNeg: 1,
            sizePerPageNeg: 25,
            isTableLoadingNeg: false,
            totalFalse: 0,
            isFeedbackHidden: false,
            formId: null,
            formCallId: null,
            option: 1,
            callDuration: { min: 0, max: 60 },
            callType: 'all',
            callTypeOption: { value: 'all', label: 'All' },
            headers: {
                'Content-Type': 'application/json',
                Authorization: 'JWT ' + this.props.user.token,
            },
        };

        console.log(this.props);

        this.toggle = this.toggle.bind(this);
        this.toggleSlider = this.toggleSlider.bind(this);
        this.changedSwitch = this.changedSwitch.bind(this);
        // this.handleChange = this.handleChange.bind(this)
    }

    /**
     * Toggle the tab
     */
    toggle = (tab) => {
        if (this.state.activeTab !== tab) {
            this.setState({
                activeTab: tab,
            });
        }
    };

    getDate = (days) => {
        let today;
        //FIND DATE FOR LAST N DAYS
        if (days) {
            var date = new Date();
            today = new Date(date.getTime() - days * 24 * 60 * 60 * 1000);
        } else {
            //FIND TODAY DATE
            today = new Date();
        }
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();
        today = yyyy + '-' + mm + '-' + dd;
        return today;
    };

    agentDataReq = (agentData) => {
        let agentSelect = [];
        for (let j = 0; j < agentData.length; j++) {
            agentSelect.push(agentData[j].value);
        }
        return agentSelect;
    };

    groupDataReq = (groupData, typeData) => {
        let groupSelect = [];
        if (groupData != null) {
            for (let j = 0; j < groupData.length; j++) {
                if (typeData == 0) {
                    groupSelect.push(groupData[j].label);
                }
                if (typeData == 1) {
                    groupSelect.push(groupData[j].value);
                }
            }
        }
        return groupSelect;
    };

    momentDataReq = (momentData, typeData) => {
        let momentSelect = [];
        if (momentData != null) {
            for (let j = 0; j < momentData.length; j++) {
                if (typeData == 0) {
                    momentSelect.push(momentData[j].label);
                }
                if (typeData == 1) {
                    momentSelect.push(momentData[j].value);
                }
            }
        }
        return momentSelect;
    };

    onChangeTeam = async (selectedTeam) => {
        try {
            this.setState({
                selectedTeam: selectedTeam,
            });

            let teamUsers = await servicePost(
                'team/getTeamByID',
                {
                    id: selectedTeam.value,
                },
                this.state.headers
            );

            console.log(teamUsers);
            teamUsers = teamUsers.data[0].teamData;
            let teamUsersOpt = [];

            for (var j = 0; j < teamUsers.length; j++) {
                teamUsersOpt.push({ value: teamUsers[j]._id, label: teamUsers[j].name });
            }

            this.setState({
                agentsOptions: teamUsersOpt,
            });
        } catch (error) {
            alert('Error: Failed to find agents to corresponding Team');
        }

        // Call API to Fetch all the User
    };

    onChangeAgent = async (selectedAgent) => {
        // selectedAgent.push(selectedAgent);
        let agents = await this.agentDataReq(selectedAgent);
        this.setState({
            selectAgent: selectedAgent,
            sizePerPage: 25,
            page: 1,
        });

        await this.getfilterCall(
            this.momentDataReq(this.state.selectMoment, 1),
            this.groupDataReq(this.state.selectedGroup, 1),
            agents,
            true,
            1,
            25,
            this.state.dateRange,
            this.state.callDuration,
            this.state.callType
        );

        await this.getfilterNegativeCall(
            this.momentDataReq(this.state.selectMoment, 1),
            this.groupDataReq(this.state.selectedGroup, 1),
            agents,
            false,
            1,
            25,
            this.state.dateRange,
            this.state.callDuration,
            this.state.callType
        );

        // SELECTION REQUEST FOR AGENTS TOTAL CALLS
        // this.getTotalAchievedCalls(this.momentDataReq(this.state.selectMoment,1),this.groupDataReq(this.state.selectedGroup,1),agents)
    };

    onChangeGroup = async (selectedGroup) => {
        let groups = await this.groupDataReq(selectedGroup, 1);
        this.setState({
            selectedGroup: groups,
            sizePerPage: 25,
            page: 1,
            // momentsOptions: await this.momentList(groups),
        });

        /** CALL MOMENTS ACCORDING TO GROUP ID */
        let selectList = this.momentList(selectedGroup);
        // CREATE AN ARRAY AND PUSH MOMENT LIST INTO IT.

        await this.getfilterCall(
            this.momentDataReq(this.state.selectMoment, 1),
            groups,
            this.agentDataReq(this.state.selectAgent),
            true,
            1,
            25,
            this.state.dateRange,
            this.state.callDuration,
            this.state.callType
        );

        await this.getfilterNegativeCall(
            this.momentDataReq(this.state.selectMoment, 1),
            groups,
            this.agentDataReq(this.state.selectAgent),
            false,
            1,
            25,
            this.state.dateRange,
            this.state.callDuration,
            this.state.callType
        );
    };

    onChangeMoment = async (selectedMoment) => {
        let moments = await this.momentDataReq(selectedMoment, 1);
        this.setState({
            selectMoment: moments,
            sizePerPage: 25,
            page: 1,
        });
        await this.getfilterCall(
            moments,
            this.groupDataReq(this.state.selectedGroup, 1),
            this.agentDataReq(this.state.selectAgent),
            true,
            1,
            25,
            this.state.dateRange,
            this.state.callDuration,
            this.state.callType
        );

        await this.getfilterNegativeCall(
            moments,
            this.groupDataReq(this.state.selectedGroup, 1),
            this.agentDataReq(this.state.selectAgent),
            false,
            1,
            25,
            this.state.dateRange,
            this.state.callDuration,
            this.state.callType
        );
        // SELECTION REQUEST FOR MOMENT TOTAL CALLS
        // this.getTotalAchievedCalls(moments,this.groupDataReq(this.state.selectedGroup,1),this.agentDataReq(this.state.selectAgent))
    };

    onChangeCallType = async (callType) => {
        this.setState({
            callType: callType.value,
            callTypeOption: callType,
            sizePerPage: 25,
            page: 1,
        });
        await this.getfilterCall(
            this.momentDataReq(this.state.selectMoment, 1),
            this.groupDataReq(this.state.selectedGroup, 1),
            this.agentDataReq(this.state.selectAgent),
            true,
            1,
            25,
            this.state.dateRange,
            this.state.callDuration,
            callType.value
        );

        await this.getfilterNegativeCall(
            this.momentDataReq(this.state.selectMoment, 1),
            this.groupDataReq(this.state.selectedGroup, 1),
            this.agentDataReq(this.state.selectAgent),
            false,
            1,
            25,
            this.state.dateRange,
            this.state.callDuration,
            callType.value
        );
    };

    /** CHANGE VALUE OF CALL DURATION  */
    durationChange = (duration) => {
        console.log('duration===>', duration);
        this.setState({
            callDuration: duration,
        });

        this.getfilterNegativeCall(
            this.momentDataReq(this.state.selectMoment, 1),
            this.groupDataReq(this.state.selectedGroup, 1),
            this.agentDataReq(this.state.selectAgent),
            false,
            1,
            25,
            this.state.dateRange,
            this.state.callDuration,
            this.state.callType
        );

        this.getfilterCall(
            this.momentDataReq(this.state.selectMoment, 1),
            this.groupDataReq(this.state.selectedGroup, 1),
            this.agentDataReq(this.state.selectAgent),
            true,
            1,
            25,
            this.state.dateRange,
            this.state.callDuration,
            this.state.callType
        );
    };

    // call filter
    getfilterCall = async (
        momentID,
        groupID,
        callerNames,
        achievedStatus,
        pageNo,
        sizePerPage,
        dateRange,
        durationRange,
        callType
    ) => {
        try {
            this.setState({
                getTotalCalls: true,
            });
            if (pageNo == 1) {
                this.setState({ tableLoader: true });
            }

            await servicePost(
                'api/v1/analyse/get/callAgentFilter',
                {
                    dateRange: this.props.dateRange,
                    date: this.getDate(),
                    applyFilter: {
                        momentId: momentID,
                        groupId: groupID,
                        callerName: callerNames,
                        page: pageNo,
                        pagination: sizePerPage,
                        dateRange: dateRange,
                        achievedStatus: achievedStatus,
                        callDuration: durationRange,
                        callType: callType,
                    },
                },
                this.state.headers
            )
                .then((callRecords) => {
                    // if(callRecords !== ''){
                    console.log('_____', callRecords.data);
                    // CREATE ONE COLUMN FOR SHOW TO/FROM IN ONE COLUMN
                    for (var i = 0; i < callRecords.data.agentCallData.length; i++) {
                        callRecords.data.agentCallData[i].toFrom =
                            callRecords.data.agentCallData[i].to + '\\r\\n' + callRecords.data.agentCallData[i].from;
                        callRecords.data.agentCallData[i].date = dateFormat(callRecords.data.agentCallData[i].date, 1);
                    }

                    this.setState({
                        records: callRecords.data.agentCallData,
                        tableLoader: false,
                        momentData: callRecords.data.MomentData,
                        groupData: callRecords.data.groupData,
                        callerName: callRecords.data.callerName,
                        total: callRecords.data.totalAgentCall,
                        agentTotalCall: callRecords.data.agentTotalCall,
                        page: pageNo,
                        sizePerPage: sizePerPage,
                        loading: false,
                        isTableLoading: false,
                    });

                    // SETTING AGENT DATA
                    let agentSelect = [];
                    // let callterData = callRecords.data.callerName;
                    // for (let k = 0; k < callterData.length; k++) {
                    //     const ele = callterData[k];
                    //     agentSelect.push({ value: ele, label: ele });
                    // }
                    // this.setState({
                    //     selectAgent: selectAgent,
                    // });

                    // GROUP DATA
                    let groupSelect = [];
                    let grpData = callRecords.data.groupData;
                    for (let k = 0; k < grpData.length; k++) {
                        const ele = grpData[k];
                        groupSelect.push({ value: ele._id, label: ele.groupName });
                    }
                    this.setState({
                        selectedGroup: groupSelect,
                    });

                    // MOMENT DATA
                    let momentSelect = [];
                    let momData = callRecords.data.MomentData;
                    for (let k = 0; k < momData.length; k++) {
                        const ele = momData[k];
                        momentSelect.push({ value: ele._id, label: ele.momentName });
                    }
                    this.setState({
                        selectMoment: momentSelect,
                    });
                    // }
                })
                .catch((err) => {
                    // alert(err,"Invalid Request");
                    console.log('err', err);
                });
        } catch (error) {}
    };

    getfilterNegativeCall = async (
        momentID,
        groupID,
        callerNames,
        achievedStatus,
        pageNo,
        sizePerPage,
        dateRange,
        durationRange,
        callType
    ) => {
        try {
            this.setState({
                getTotalCalls: true,
            });
            if (pageNo == 1) {
                this.setState({ tableLoader: true });
            }

            await servicePost(
                'api/v1/analyse/get/callAgentFilterNegative',
                {
                    dateRange: this.props.dateRange,
                    date: this.getDate(),
                    applyFilter: {
                        momentId: momentID,
                        groupId: groupID,
                        callerName: callerNames,
                        page: pageNo,
                        pagination: sizePerPage,
                        dateRange: dateRange,
                        achievedStatus: achievedStatus,
                        callDuration: durationRange,
                        callType: callType,
                    },
                },
                this.state.headers
            )
                .then((negativeRespons) => {
                    console.log('===>callRecordNegative', negativeRespons);
                    // CREATE ONE COLUMN FOR SHOW TO/FROM IN ONE COLUMN
                    for (var i = 0; i < negativeRespons.data.agentCallData.length; i++) {
                        negativeRespons.data.agentCallData[i].toFrom =
                            negativeRespons.data.agentCallData[i].to +
                            '\\r\\n' +
                            negativeRespons.data.agentCallData[i].from;
                        negativeRespons.data.agentCallData[i].date = dateFormat(
                            negativeRespons.data.agentCallData[i].date,
                            1
                        );
                    }
                    this.setState({
                        negRecords: negativeRespons.data.agentCallData,
                        negTotal: negativeRespons.data.totalAgentCall,
                        pageNeg: pageNo,
                        sizePerPageNeg: sizePerPage,
                        isTableLoadingNeg: false,
                        tableLoader: false,
                    });
                })
                .catch((error) => {
                    alert('error', error);
                });
        } catch (error) {
            alert(error, 'Invalid Request');
        }
    };

    momentList = async (groupId) => {
        let moment = [];
        let moments = await servicePost(
            'moments',
            { userId: this.props.user.id, groupID: groupId },
            this.state.headers
        );
        let momentOpt = [];

        for (var l = 0; l < moments.data.length; l++) {
            if (moment.indexOf(moments.data[l].moment.momentName) !== -1) {
            } else {
                momentOpt.push({ label: moments.data[l].moment.momentName, value: moments.data[l].moment._id });
            }
        }
        this.setState({
            momentsOptions: momentOpt,
        });
        // return momentOpt;
    };

    async componentDidMount() {
        let agents = [];
        let groups = [];
        let callData = await servicePost('api/v1/analyse/get/calls', {}, this.state.headers);
        this.setState({
            records: callData.data.call
        });
        console.log("------>>>>", callData);

        agents = await servicePost('agent/getCallAgent', {}, this.state.headers);

        // console.log('agents',agents);
        // return false;

        let agentOpt = [];
        if (agents.data.length > 0) {
            for (var j = 0; j < agents.data.length; j++) {
                agentOpt.push({ value: agents.data[j]._id, label: agents.data[j].name });
            }
        }

        let groupOpt = [];
        let momentGroups = await servicePost('moments/group/user', { id: this.props.user.id }, this.state.headers);
        console.log(momentGroups);
        for (var k = 0; k < momentGroups.data.length; k++) {
            if (groups.indexOf(momentGroups.data[k].groupName) !== -1) {
            } else {
                groupOpt.push({ label: momentGroups.data[k].groupName, value: momentGroups.data[k]._id });
            }
        }

        let teamOpt = [];
        let rawTeams = await servicePost('team/all', {}, this.state.headers);

        rawTeams = rawTeams.data;
        for (var k = 0; k < rawTeams.length; k++) {
            teamOpt.push({ label: rawTeams[k].teamName, value: rawTeams[k]._id });
        }

        console.log('Team OPT', teamOpt);

        this.setState({
            teamOptions: teamOpt,
            agentsOptions: agentOpt,
            groupsOptions: groupOpt,
            // momentsOptions: await this.momentList([this.props.match.params.groupId]),
        });
        
        
    }

    requestWithParams = (selectedDate) => {
        const parsed = queryString.parse(this.props.location.search);

        // console.log('==[this.props.match.params', Object.keys(parsed).length);

        // let callerArr = atob()
        if (Object.keys(parsed).length === 0) {
            this.getfilterCall(
                [],
                [],
                [],
                true,
                this.state.page,
                this.state.sizePerPage,
                selectedDate,
                this.state.callDuration,
                this.state.callType
            );

            this.getfilterNegativeCall(
                [],
                [],
                [],
                false,
                this.state.page,
                this.state.sizePerPage,
                selectedDate,
                this.state.callDuration,
                this.state.callType
            );
        } else {
            this.getfilterCall(
                [parsed.momentId],
                [parsed.groupId],
                [parsed.agent],
                true,
                this.state.page,
                this.state.sizePerPage,
                selectedDate,
                this.state.callDuration,
                this.state.callType
            );
            this.getfilterNegativeCall(
                [parsed.momentId],
                [parsed.groupId],
                [parsed.agent],
                false,
                this.state.page,
                this.state.sizePerPage,
                selectedDate,
                this.state.callDuration,
                this.state.callType
            );
        }
    };

    onTableChange = (type, newState) => {
        this.setState({
            isTableLoading: true,
        });
        //alert();
        this.getfilterCall(
            this.momentDataReq(this.state.selectMoment, 1),
            this.groupDataReq(this.state.selectedGroup, 1),
            this.agentDataReq(this.state.selectAgent),
            true,
            newState.page,
            newState.sizePerPage,
            this.state.dateRange,
            this.state.callDuration,
            this.state.callType
        );
    };

    onTableChangeNeg = (type, newState) => {
        this.setState({
            isTableLoadingNeg: true,
        });
        //alert();
        this.getfilterNegativeCall(
            this.momentDataReq(this.state.selectMoment, 1),
            this.groupDataReq(this.state.selectedGroup, 1),
            this.agentDataReq(this.state.selectAgent),
            false,
            newState.page,
            newState.sizePerPage,
            this.state.dateRange,
            this.state.callDuration,
            this.state.callType
        );
    };

    handleDateChange = () => {
        console.log('this.props.dateRange', this.props.dateRange);
        this.setState({
            dateRange: this.props.dateRange,
            page: 1,
            isTableLoading: true,
        });

        if (
            (this.state.selectMoment.length != 0,
            this.state.selectedGroup.length != 0,
            this.state.selectAgent.length != 0)
        ) {
            this.getfilterCall(
                this.momentDataReq(this.state.selectMoment, 1),
                this.groupDataReq(this.state.selectedGroup, 1),
                this.agentDataReq(this.state.selectAgent),
                true,
                1,
                25,
                this.state.dateRange,
                this.state.callDuration,
                this.state.callType
            );

            this.getfilterNegativeCall(
                this.momentDataReq(this.state.selectMoment, 1),
                this.groupDataReq(this.state.selectedGroup, 1),
                this.agentDataReq(this.state.selectAgent),
                false,
                1,
                25,
                this.state.dateRange,
                this.state.callDuration,
                this.state.callType
            );
        } else {
            this.requestWithParams(this.props.dateRange);
        }
        // this.getfilterCall([parsed.momentId],[parsed.groupId],[parsed.agent], this.state.page, this.state.sizePerPage,this.state.dateRange)
    };

    toggleSlider = (callId, formId) => {
        this.setState({
            isFeedbackHidden: !this.state.isFeedbackHidden,
            formId: formId,
            formCallId: callId,
        });
    };

    changedSwitch = (val, e) => {
        this.setState({
            option: e.target.checked == true ? 2 : 1,
        });
    };

    render() {
        if (this.props.location.search) {
            
            var arr = [];
            for (var i = 0; i < this.state.callerName.length; i++) {
                this.state.agentsOptions.forEach((agent) => {
                    if (agent.value === this.state.callerName[i]) {
                        arr.push(agent);
                    }
                });
            }
            this.state.selectAgent = arr;
        }
        const tabContents = [
            {
                id: '1',
                title: 'Achieved Moment',
            },
        ];

        let groupState = this.state.groupData;
        let momentState = this.state.momentData;
        let agentState = this.state.selectAgent;

        if (this.state.loading) {
            return (
                <React.Fragment>
                    <Row className="page-title mt-4">
                        <Col>
                            <Loader />
                        </Col>
                    </Row>
                </React.Fragment>
            );
        }
        console.log(this.state);

        return (
            <React.Fragment>
                <Row className="page-title">
                    <Col md={12}>
                        <PageTitle
                            breadCrumbItems={[
                                { label: 'Summary', path: '/summary', active: false },
                                { label: 'Analysis', path: '/analyse/calls', active: true },
                            ]}
                            title={'Call Analysis'}
                        />
                    </Col>
                </Row>
                <Row>
                    {/* tab pills */}
                    <Col lg={12}>
                        <Card>
                            <CardBody>
                                <Row className="pb-3">
                                    <Col lg={'3 pl-0 '}>
                                        {this.state.momentData.length !== 0 && (
                                            <React.Fragment>
                                                <div style={{ textAlign: 'left' }} className="col">
                                                    {/* <h5>
                                                        Moment: &nbsp;
                                                        <span className="" style={{ fontSize: '14px' }}>
                                                            {momentState.map((value, index) => {
                                                                if (index > 0) {
                                                                    return <span>,&nbsp;{value.momentName}</span>;
                                                                } else {
                                                                    return <span>{value.momentName}</span>;
                                                                }
                                                            })}
                                                        </span>
                                                    </h5> */}
                                                </div>
                                            </React.Fragment>
                                        )}
                                        {this.state.momentData.length === 0 && (
                                            <React.Fragment>
                                                {/* <div style={{ textAlign: 'left' }} className="col-6 pr-0 col">
                                                    <h5>
                                                        Moment: &nbsp;
                                                        <span className="" style={{ fontSize: '14px' }}>
                                                            {' '}
                                                            All
                                                        </span>
                                                    </h5>
                                                </div> */}
                                            </React.Fragment>
                                        )}

                                        {/* GROUP  */}
                                    
                                    </Col>
                                    <Col className="col-6" style={{ 'text-align': 'center' }}>
                                        <div>
                                            <h5 style={{ color: 'rgb(83, 105, 248)', fontWeight: '400' }}>
                                                Showing&nbsp;
                                                <span
                                                    className=""
                                                    // style={{ fontSize: '16px', fontWeight: 'bold'}}
                                                >
                                                    {this.state.total !== 0 && this.state.option == 1 && (
                                                        <React.Fragment>{this.state.total}</React.Fragment>
                                                    )}
                                                    {this.state.total !== 0 && this.state.option == 2 && (
                                                        <React.Fragment>{this.state.negTotal}</React.Fragment>
                                                    )}
                                                    &nbsp;of&nbsp;
                                                    {this.state.total + this.state.negTotal
                                                        ? this.state.total + this.state.negTotal
                                                        : 0}
                                                </span>
                                                &nbsp; calls of&nbsp;
                                                <span
                                                    className=""
                                                    // style={{ fontSize: '16px', fontWeight: 'bold'}}
                                                >
                                                    {/* Showing calls of <span className="soft-success" style={{ fontSize: '16px', fontWeight: 'bold'}}> */}
                                                    {this.state.callerName && (
                                                        <React.Fragment>
                                                            {agentState.map((value, index) => {
                                                                if (index > 0) {
                                                                    return <span>,&nbsp;{value.label}</span>;
                                                                } else {
                                                                    return <span>{value.label}</span>;
                                                                }
                                                            })}
                                                        </React.Fragment>
                                                    )}
                                                    {this.state.callerName.length == 0 && (
                                                        <React.Fragment>all Agents</React.Fragment>
                                                    )}
                                                </span>
                                            </h5>
                                            {/* TOGGLE SWITCH */}
                                            
                                        </div>
                                    </Col>
                                    <Col lg={3}>
                                        <div className="bg-light p-1">
                                            {/* <UniversalDatePicker
                                                isWidthTimmed={false}
                                                isFloatDisabled={true}
                                                className="mb-0"
                                                handleDateChange={this.handleDateChange}
                                            /> */}
                                            <BetterDatePicker
                                                isWidthTimmed={false}
                                                isFloatDisabled={true}
                                                className="mb-0"
                                                handleDateChange={this.handleDateChange}
                                            />

                                            {/* <BetterDatePicker /> */}
                                        </div>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col md={12} className="px-0 pt-2">

                                        <TabContent activeTab={this.state.activeTab}>
                                            {tabContents.map((tab, index) => {
                                                return (
                                                    <TabPane tabId={tab.id} key={index}>
                                                        <Row>
                                                            <Col sm="12">
                                                                {this.state.tableLoader && (
                                                                    <React.Fragment>
                                                                        <Row className="page-title mt-4">
                                                                            <Col>
                                                                                <Loader />
                                                                            </Col>
                                                                        </Row>
                                                                    </React.Fragment>
                                                                )}
                                                                {!this.state.tableLoader && this.state.option == 1 && (
                                                                    <React.Fragment>
                                                                        <TableWithSearch
                                                                            toggleSlider={this.toggleSlider}
                                                                            onTableChange={this.onTableChange}
                                                                            records={this.state.records}
                                                                            sizePerPage={this.state.sizePerPage}
                                                                            totalSize={this.state.total}
                                                                            isTableLoading={this.state.isTableLoading}
                                                                        />
                                                                    </React.Fragment>
                                                                )}
                                                            </Col>
                                                        </Row>
                                                    </TabPane>
                                                );
                                            })}
                                        </TabContent>
                                    </Col>
                                </Row>

                                {/* <Nav className="nav nav-pills navtab-bg nav-justified">
                                    {tabContents.map((tab, index) => {
                                        return (
                                            <NavItem key={index}>
                                                <NavLink
                                                    href="#"
                                                    className={classnames({ active: this.state.activeTab === tab.id })}
                                                    onClick={() => {
                                                        this.toggle(tab.id);
                                                    }}>
                                                    <i
                                                        className={classnames(
                                                            tab.icon,
                                                            'd-sm-none',
                                                            'd-block',
                                                            'mr-1'
                                                        )}></i>
                                                    <span className="d-none d-sm-block">{tab.title}</span>
                                                </NavLink>
                                            </NavItem>
                                        );
                                    })}
                                </Nav>

                                <TabContent activeTab={this.state.activeTab}>
                                    {tabContents.map((tab, index) => {
                                        return (
                                            <TabPane tabId={tab.id} key={index}>
                                                <TableWithSearch records={this.state.records}/>
                                            </TabPane>
                                        );
                                    })}
                                </TabContent> */}
                            </CardBody>
                        </Card>
                    </Col>
                </Row>
            </React.Fragment>
        );
    }
}
const mapStateToProps = (state) => {
    // const { user, loading, error } = state.Auth;
    const { user, loading, error } = state.Auth;
    const { dateRange } = state.Options;
    return { user, loading, error, dateRange };
};
export default connect(mapStateToProps)(CallDetail);
