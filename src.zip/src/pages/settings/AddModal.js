import React, { Component } from 'react';
import { Row, Col, Card, CardBody, Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

/** IMPORT FORM */
import AddAgent from '../forms/settings/AddAgent';
import AddTeam from '../forms/settings/AddTeam';
import AddMoment from '../forms/settings/AddMoment';
import AddFeedback from '../forms/settings/AddFeedback';
import AddLibrary from '../forms/AddLibrary';

class AddModal extends Component {
    constructor(props) {
        super(props);
        console.log(props);
        const modalTitle = this.props.modalTitle;

        this.state = {
            modal: false,
            buttonName: this.props.buttonName,
            modalType: this.props.modalType,            
            modalTitle: modalTitle,
            isFooter: this.props.isFooter,
            // tableRowData: 
        };

        console.log('modal props=>>>',this.props)

        this.handleShow = this.handleShow.bind(this);
        this.handleClose = this.handleClose.bind(this);

        this.toggle = this.toggle.bind(this);
        this.openModalWithSize = this.openModalWithSize.bind(this);
        this.openModalWithClass = this.openModalWithClass.bind(this);
    }
    
    handleShow() {
        // console.log(this.state)
        this.setState({ modal: true })
    }
    handleClose(){
        this.setState({ modal: false })
    }

    /**
     * Show/hide the modal
     */
    toggle = () => {
        this.setState(prevState => ({
            modal: !prevState.modal,
        }));
    };

    /**
     * Opens large modal
     */
    openModalWithSize = size => {
        this.setState({ size: size, className: null });
        this.toggle();
    };

    /**
     * Opens modal with custom class
     */
    openModalWithClass = className => {
        this.setState({ className: className, size: null });
        this.toggle();
    };

    changeView = () => {
        // alert('im here')
        this.props.modalView()
    }

    render() {
        return (
            <React.Fragment>
                { this.state.modalType == 'library' && <React.Fragment>
                    <button style={{ float: this.props.btnStyle }} className="btn btn-primary" onClick={() => this.openModalWithClass('modal-dialog-scrollable')}>
                        {this.props.buttonName}
                    </button>
                </React.Fragment>}
                { this.state.modalType != 'library' && <React.Fragment>
                <Button style={{ float: this.props.btnStyle }} className="btn btn-info create-btn mb-2" onClick={() => this.openModalWithClass('modal-dialog-scrollable')}>
                    {this.props.buttonName}
                </Button>
                </React.Fragment>}

                <Modal
                    isOpen={this.state.modal}
                    toggle={this.toggle}
                    className={this.state.className}
                    size={this.state.size}>
                    <ModalHeader toggle={this.toggle}>{ this.state.modalTitle }</ModalHeader>
                    <ModalBody>
                        {this.state.className && this.state.className === 'modal-dialog-scrollable' && <React.Fragment>

                        </React.Fragment>}
                        { this.state.modalType == 'library' && <React.Fragment>
                            <AddLibrary 
                                toggle={this.toggle}
                                tableRow={this.props.recordData}
                                view={this.changeView.bind(this)}
                                data={'0'}
                                bName={this.props.buttonName}
                                callId = {this.props.callID}
                            />
                        </React.Fragment>}
                        { this.state.modalType == 'team' && <React.Fragment>
                            <AddTeam 
                                toggle={this.toggle}
                                tableRow={this.props.recordData}
                                view={this.changeView.bind(this)}
                                data={'0'}
                            />
                        </React.Fragment>}
                        { this.state.modalType == 'agent' && <React.Fragment>
                            <AddAgent typeForm='edit' data={{team: ''}} toggle={this.toggle} tableRow={this.props.recordData} view={this.changeView.bind(this)}/>
                        </React.Fragment>}
                        { this.state.modalType == 'moment' && <React.Fragment>
                            <AddMoment themeId={this.props.themeId} toggle={this.toggle} tableRow={this.props.recordData} view={this.changeView.bind(this)} />
                        </React.Fragment>}
                        { this.state.modalType == 'feedback' && <React.Fragment>
                            <AddFeedback toggle={this.toggle} tableRow={this.props.recordData} view={this.changeView.bind(this)} />
                        </React.Fragment>}
                    </ModalBody>                    
                </Modal>
            </React.Fragment>
        );
    }
}

export default AddModal;