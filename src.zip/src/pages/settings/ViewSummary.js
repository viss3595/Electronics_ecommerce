import React, { Component } from 'react';
import { Row, Col, Card, CardBody, Button, Modal, ModalHeader, ModalBody, ModalFooter,Table,Progress,UncontrolledTooltip } from 'reactstrap';
import BootstrapTable from 'react-bootstrap-table-next';
import ToolkitProvider, { Search, CSVExport } from 'react-bootstrap-table2-toolkit';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import 'react-bootstrap-table2-filter/dist/react-bootstrap-table2-filter.min.css';
import { connect } from 'react-redux';
import { servicePost } from './../../helpers/api';
import Loader from '../../components/Loader';
import { Link } from 'react-router-dom';
class ViewSummary extends Component {
    constructor(props) {
        super(props);
        const modalTitle = this.props.modalTitle;

        const columns = [
            {
                dataField: 'agent.name',
                text: 'Agents',
                sort: true,
                headerFormatter:(column, colIndex)=> {
                    return (
                        <div>
                             <div class="text-left">{ column.text }</div>
                             <div class="text-left" style={{'color':'white'}}>()</div>
                        </div>
                    );
                  },
                  style: { float: 'left' },
                  headerStyle: { width: '20%' },
            },
            {
                dataField: 'agentAchievedCallPer',
                text: 'Moment Achieved',
                sort: true,
                headerFormatter:(column, colIndex)=> {
                    return (
                        <div>
                             <div class="text-right">{ column.text }</div>
                             <div class="text-right">(%)</div>
                        </div>
                    );
                  },
                  style: { width: '20%' },
            },
            {
                dataField: 'agentAchievedCallPerSort',
                text: 'sortpercentage',
                sort: true,
                style: { display: 'none' },
                headerStyle: { display: 'none' },
            },
            {
                dataField: 'agentAchievedCall',
                text: 'Moment Achieved',
                sort: true,
                headerFormatter:(column, colIndex)=> {
                    return (
                        <div>
                             <div class="text-right">{ column.text }</div>
                             <div class="text-right">(# of calls)</div>
                        </div>
                     
                    );
                  },
                  style: { width: '20%' },  
                  
            },
            {
                dataField: 'agentCallCount',
                text: 'Total Calls',
                sort: true,   
                headerFormatter:(column, colIndex)=> {
                    return (
                        <div>
                            <div class="text-right">{ column.text }</div>
                            <div class="text-right" style={{'color':'white'}}>()</div>
                        </div>
                    
                    );
                },                  
                headerStyle: { width: '15%' },
                style: { float: 'right' }
            },
            {
                dataField: 'action',
                text: 'Action',
                sort: false,
                headerFormatter:(column, colIndex)=> {
                    return (
                        <div>
                            <div class="text-center">{ column.text }</div>
                            <div class="text-center" style={{'color':'white'}}>()</div>
                        </div>
                    
                    );
                },
                headerStyle: { width: '15%' },
            },
        ];
    
        const defaultSorted = [
            {
                dataField: 'agentAchievedCallPer',
                order: 'desc',
            },
        ];
        this.state = {
            showData: true,
            modal: false,
            loader: true,
            buttonName: this.props.buttonName,
            modalType: this.props.modalType,            
            modalTitle: modalTitle,
            isFooter: this.props.isFooter,
            records: '',
            columns : columns,
            defaultSorted:defaultSorted,
            // callCount state is used as hack for now
            callCount : null,
            // tableRowData: 

        };
        
        this.handleShow = this.handleShow.bind(this);
        this.handleClose = this.handleClose.bind(this);

        this.toggle = this.toggle.bind(this);
        this.openModalWithSize = this.openModalWithSize.bind(this);
        this.openModalWithClass = this.openModalWithClass.bind(this);
    }
    
    handleShow() {
        // console.log(this.state)
        this.setState({ modal: true })
    }
    handleClose(){
        this.setState({ modal: false })
    }

    /**
     * Show/hide the modal
     */
    toggle = () => {
        this.setState(prevState => ({
            modal: !prevState.modal,
        }));
    };

    /**
     * Opens large modal
     */
    openModalWithSize = size => {
        this.setState({ size: size, className: null });
        this.toggle();
    };

    /**
     * Opens modal with custom class
     */
    openModalWithClass = className => {
        this.setState({ className: className, size: null });
        this.toggle();
    };

    changeView = () => {
        // alert('im here')
        this.props.modalView()
    }

    getAgentData = () => {
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'JWT ' + this.props.user.token,
        };

        servicePost('api/v1/analyse/get/call/filter', 
        { 
            userId: this.props.user.id, 
            applyFilter: { 
                momentId: this.props.momentId, 
                groupId: this.props.groupID 
            },
            dateRange : this.props.dateRange,
            teamId : this.props.teamId
             
        }, headers)
            .then((res) => {
                //  if( res.data.summary.length > 0 ){
                // let records = res.data;
                // for (let i = 0; i < records.length; i++) {
                //     const element = records[i];
                //     element.action = <div style={{ textAlign: 'center' }}><Link to={`/analyse/call/${this.props.momentId}/${this.props.groupID}/${btoa(element.agent)}`} className={'btn btn-primary btn-sm'}>Analysis</Link></div>
                // }
                //SORT RECORDS BY PERCENTAGE COLUMN
                if(res.data.length > 0){
                    const data = res.data;
                    const sorted = data.sort((a, b) => b['agentAchievedCallPerSort'] - a['agentAchievedCallPerSort']);
                    var totalCalls = 0;
                    for (let index = 0; index < sorted.length; index++) {
  
                        var tooltip =  <UncontrolledTooltip placement="top" id={'tooltip-' + index } target={'tbtn-' +index}><div>{sorted[index].agentAchievedCallPerSort+'%'}</div></UncontrolledTooltip>
                        totalCalls += sorted[index].agentCallCount;


                        sorted[index].agentAchievedCallPer = <React.Fragment>
                            <Progress  id={'tbtn-'+ index} value={sorted[index].agentAchievedCallPerSort} className="mb-2 progress-xxl">{sorted[index].agentAchievedCallPerSort+'%'}</Progress>{tooltip}
                            </React.Fragment>
                        sorted[index].action = <div style={{ textAlign: 'center' }}><Link target="_blank" to={`/analyse/call/?momentId=${this.props.momentId}&groupId=${this.props.groupID}&agent=${sorted[index].agent._id}`} className={'btn btn-primary btn-sm'} style={{ fontSize: '14px', backgroundColor: '#fff', color: '#5369f8', borderColor: '#5369f8' }}>Review calls</Link></div>
                
                    }

                    console.log(sorted);

                    this.setState({
                        records : sorted,
                        loader: false,
                        callCount : totalCalls
                    })
                }
                else{
                    this.setState({
                        records : [],
                        loader: false,
                        callCount : res.data.length
                    })   
                }
                
                //  if( res.data.summary.length > 0 ){
                    // this.setState({
                    //     records : sorted,
                    //     loader: false
                    // })
                // }
            })
            .catch((err) => {
                console.log( err);
            });
            this.setState({
                showData: false,
                
            })
        };
        componentDidUpdate(){
            if(this.state.modal == true && this.state.showData == true){
                this.getAgentData()
                this.setState({
                    
                })
            }
        }   


    render() {
        return (
            <React.Fragment>
                <span style={{ color:'#5369f8',cursor: 'pointer' }} onClick={() => this.openModalWithClass('modal-dialog-scrollable modal-lg')}>
                    {this.props.buttonName}
                </span>

                <Modal
                    isOpen={this.state.modal}
                    toggle={this.toggle}
                    className={this.state.className}
                    size={this.state.size}>
                    <ModalHeader toggle={this.toggle}>{ this.state.modalTitle }</ModalHeader>
                    <ModalBody className="pt-0">
                    <Row> 
                        <Col className="col-4 pr-0" style={{ 'text-align': 'left' }}>
                            <h5>Moment: &nbsp;<span class="my-2" style={{ fontSize: '14px' }}> {this.props.momentName}</span></h5>
                        
                            
                        </Col>

                        <Col className="col-4" style={{ 'text-align': 'left' }}>
                            <h5>Group: &nbsp;<span class="my-2"><span class="badge badge-pill" style={{fontSize: '14px','background-color':this.props.groupColor,'color':'white' }}>{this.props.groupName}</span></span></h5>
                        
                            
                        </Col>
                    </Row>
                    
                        {this.state.callCount != null &&
                            <Row>
                            <Col className="col-12" style={{ 'text-align': 'left' }}>
                            <p>Moment achieved in <span class="badge badge-pill badge-soft-success" style={{ 'font-size': '100%' }}>{ this.props.achievedCalls }</span> out of <span class="badge badge-pill badge-soft-success" style={{ 'font-size': '100%' }}>{ this.props.totalCalls }</span> calls</p>
                        </Col>
                        <Col className="col-12" style={{ 'text-align': 'left' }}>
                            <p>Achieved Average: <span class="badge badge-pill aliceblue" style={{ 'font-size': '100%' }}>{ this.props.avgAchievedCalls }</span></p>
                        </Col>
                        </Row>
                        }
                        

                     {this.state.loader && <React.Fragment>
                        <Row className="page-title mt-4">
                            <Col xl={12} md={12}>
                                <Loader />
                            </Col>
                        </Row>
                    </React.Fragment>}
         
                
         
        
                        <ToolkitProvider
                            bootstrap4
                            keyField="id"
                            data={this.state.records}
                            columns={this.state.columns}
                            search={ { searchFormatted: true } }
                            exportCSV={{ onlyExportFiltered: true, exportAll: false }} >
                            {props => (
                                <React.Fragment>

                                    {this.state.records.length > 0 && <React.Fragment>
                                    <BootstrapTable
                                        {...props.baseProps}
                                        bordered={false}
                                        id="summaryTbl"
                                        defaultSorted={this.state.defaultSorted}
                                        wrapperClasses="table-responsive"
                                    />
                                    </React.Fragment>}
                                </React.Fragment>
                            )}
                        </ToolkitProvider>
                        </ModalBody>
                        {!this.state.isFooter  && <React.Fragment>
                            <ModalFooter >
                                <Button color="primary" onClick={this.toggle}>Do Something</Button>
                                <Button color="secondary" className="ml-1" onClick={this.toggle}>Cancel</Button>
                        </ModalFooter>
                        </React.Fragment>}
                        
                    </Modal>
                </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    const { user, loading, error } = state.Auth;
    const { dateRange } =  state.Options;
    return { user, loading, error, dateRange };
};
export default connect(mapStateToProps)(ViewSummary);