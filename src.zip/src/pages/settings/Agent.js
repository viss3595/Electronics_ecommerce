import AvField from 'availity-reactstrap-validation/lib/AvField';
import AvForm from 'availity-reactstrap-validation/lib/AvForm';
import AvGroup from 'availity-reactstrap-validation/lib/AvGroup';

import React, { Component } from 'react';
import Loader from '../../components/Loader';
import ReactPaginate from 'react-paginate';
import { Link } from 'react-router-dom';
import Select from 'react-select';
import InputMask from 'react-input-mask';
import { Modal, ModalFooter, Col, ModalBody, ModalHeader, Row, Input, Button, Table, CustomInput } from 'reactstrap';
import Label from 'reactstrap/lib/Label';
import { getLoggedInUser } from '../../helpers/authUtils';
import { dateFormat } from '../../helpers/common';
import { serviceGet, servicePost, servicePut } from './../../helpers/api';

import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import moment from 'moment';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import { toast } from 'react-toastify';
import { SERVICE_URL, DEFAULT_SERVICE_VERSION } from '../../constants/utility';
const Swal = require('sweetalert2')
const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })
class Agent extends Component {
    constructor(props) {
        super(props);

        this.state = {
            user: getLoggedInUser(),
            modal: false,
            loading: true,
            pageLoading: false,
            agentList: [],
            name: '',
            email: null,
            password: null,
            agentId: null,
            position: '',
            phoneNumber: 0,
            countryCode: '',
            inviteBy: '',
            page: 1,
            size: 10,
            pageCount: 1,
            inviters: [],
            positions: ['Agent', 'Trainer'],
            searchName: '',
            startDate: null,
            endDate: null,
            currentPage: 0,
            sortBy:'agentId',
            orderBy: 'desc',
            selectAgents : [
                
            ]
        };
        this.toggle = this.toggle.bind(this);
        this.getAgentList = this.getAgentList.bind(this);
        this.createAgent = this.createAgent.bind(this);
        this.getInviters = this.getInviters.bind(this);
        this.onChangePosition = this.onChangePosition.bind(this);
        this.onChangeInviter = this.onChangeInviter.bind(this);
        this.changePage = this.changePage.bind(this);
        this.getExportData = this.getExportData.bind(this);
        this.padLeft = this.padLeft.bind(this);
        this.sortList = this.sortList.bind(this);
    }

    componentDidMount() {
        this.getAgentList();
    }

    getAgentList = (agentName = null, pageno = null) => {
        this.setState({
            agentList: [],
            loading: true
        })
        if (pageno == null) {
            pageno = this.state.currentPage;
        }
        agentName = this.state.searchName;
        if (agentName == null) { agentName = "" }
        let url = `api/v1/agent/list?name=${agentName}&page=${this.state.page}&size=${this.state.size}&sortBy=${this.state.sortBy}&orderBy=${this.state.orderBy}`;
        if (this.state.startDate && this.state.endDate) {
            url += `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
        } else if (this.state.startDate && (!this.state.endDate)) {
            url += `&startDate=${this.state.startDate}`;
        } else if (this.state.endDate && (!this.state.startDate)) {
            url += `&endDate=${this.state.endDate}`;
        }
        console.log(url);
        serviceGet(url, {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
            .then((res) => {
                if (res.data) {
                    this.setState({
                        page: (pageno == null ? 0 : pageno) + 1,
                        currentPage: pageno == null ? 0 : pageno,
                        agentList: res.data.responseObject,
                        pageCount: Math.ceil(res.data.totalElements / 10),
                        loading: false
                    })
                }
            }).catch((error) => {
                console.log(error);
                this.setState({
                    loading: false
                })
            });
    }

    createAgent = () => {
        if (
            this.state.position === null || this.state.position === undefined || this.state.position === "") {
            toast('Please fill all the fields.', { bodyClassName: 'error-toast' });
            return;
        }
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        let agent = {
            'name': this.state.name,
            'email': this.state.email,
            'password': this.state.password,
            "phoneNumber": this.state.phoneNumber,
            "countryCode": this.state.countryCode,
            "invitedBy": this.state.inviteBy.value,
            "position": this.state.position,
            "refferalCode" : this.state.Refferalcode
        }
        if (this.state.password === null) {
            delete agent.password;
        }
        if (this.state.agentId) {
            servicePut(`api/v1/agent/${this.state.agentId}`,
                JSON.stringify(agent),
                headers)
                .then((res) => {
                    if (res.data) {
                        this.getAgentList();
                        this.toggle();
                        toast('Agent updated successfully', { bodyClassName: 'success-toast' });
                    } else {
                        toast(res.error, { bodyClassName: 'error-toast' });
                    }
                })
                .catch((err) => {
                    console.log(err)
                    toast('Some error occurred', { bodyClassName: 'error-toast' });
                })
        } else {
            servicePost('api/v1/agent', JSON.stringify(agent), headers)
                .then((res) => {
                    if (res.data) {
                        this.getAgentList();
                        this.toggle();
                        toast('Agent created successfully', { bodyClassName: 'success-toast' });
                    } else {
                        toast(res.error, { bodyClassName: 'error-toast' });
                    }
                })
                .catch((err) => {
                    console.log(err)
                    toast('Some error occurred', { bodyClassName: 'error-toast' });
                })
        }
    }

    toggle = (modal, agent) => {
        if (agent != null) {
            let inviter = {
                'label': agent.invitedBy?.name,
                'value': agent.invitedBy?._id
            }
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                agentId: agent._id,
                name: agent.name,
                phoneNumber: agent.phoneNumber,
                position: agent.position,
                inviteBy: inviter,
                email: agent.email,
                countryCode: agent.countryCode ? agent.countryCode : ''
            }))
        } else {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                agentId: null,
                name: '',
                phoneNumber: null,
                position: '',
                inviteBy: '',
                email: '',
                password: null,
                countryCode: '',
                Refferalcode : this.generateRefferalId(8)
            }))
        }
    };

    getInviters = (inviter) => {
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        if (inviter.length > 0) {
            serviceGet(`api/v1/agent/list?name=${inviter}&page=${1}&size=${10}`, headers)
                .then((res) => {
                    let inviterObj = [];
                    for (var i = 0; i < res.data.responseObject.length; i++) {
                        inviterObj.push({
                            'value': res.data.responseObject[i]._id,
                            'label': res.data.responseObject[i].name
                        });
                    }
                    //   if(res.data){
                    this.setState({
                        inviters: inviterObj
                    });
                    //  }
                });
        }
    }

    getPositions = () => {
        serviceGet(`api/v1/agent/position`)
            .then((res) => {
                if (res.data) {
                    this.setState({
                        positions: res.data
                    })
                }
            });
    }

    onChangePosition = async (selectedValue) => {
        this.setState({
            position: selectedValue.value
        });
    }

    onChangeInviter = async (selectedValue) => {
        this.setState({
            inviteBy: selectedValue
        });
    }

    handleChange = (event) => {



        if (event.target.name === 'startDate' || event.target.name === 'endDate') {
            let date = new Date(event.target.value);
            date.setHours(0, 0, 0, 0);
            this.setState({
                [event.target.name]: date.toISOString()
            }, () => {
                this.setState({ page: 1 }, () => {
                    if (this.state.startDate != null && this.state.endDate != null) {
                        this.getAgentList();
                    }
                });
            });
        } else {

            this.setState({
                [event.target.name]: event.target.value
            });
        }
    }

    searchByName = (name) => {
        if (!name) {
            this.setState({
                searchName: ''
            }, () => this.getAgentList())
        } else {
            let headers = {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.state.user.token
            };
            if (name.length > 2) {
                this.setState({
                    agentList: [],
                    searchName: name,
                    loading: true
                })
                
                let url = `api/v1/agent/list?name=${name}&page=${1} &size=${10}&sortBy=${this.state.sortBy}&orderBy=${this.state.orderBy}`;
                if (this.state.startDate && this.state.endDate) {
                    url += `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
                } else if (this.state.startDate && (!this.state.endDate)) {
                    url += `&startDate=${this.state.startDate}`;
                } else if (this.state.endDate && (!this.state.startDate)) {
                    url += `&endDate=${this.state.endDate}`;
                }
                serviceGet(url, headers)
                    .then((res) => {
                        if (res.data) {
                            this.setState({
                                page: 1,
                            }, () => {
                                alert(1);
                                this.setState({
                                    loading: false,
                                    agentList: res.data.responseObject,
                                    pageCount: res.data.totalElements / 10
                                });
                            });
                        }
                    }).catch((error) => {
                        console.log(error);
                        this.setState({
                            loading: false
                        })
                    });
            }
        }
    }



    changePage = ({ selected }) => {

        this.setState({
            currentPage: selected,
            page: selected + 1,
            agentList: []
        }, () => { this.getAgentList() });
    }
    padLeft(nr, n, str) {
        return Array(n - String(nr).length + 1).join(str || '0') + nr;
    }

    getExportData = (agentName = null, callback) => {
        this.setState({
            searchName: agentName
        })
        if (agentName == null) { agentName = "" }
        let url = `api/v1/agent/report/export?name=${agentName}&page=${this.state.page}&size=${this.state.size}`;
        if (this.state.startDate && this.state.endDate) {
            url += `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
        } else if (this.state.startDate && (!this.state.endDate)) {
            url += `&startDate=${this.state.startDate}`;
        } else if (this.state.endDate && (!this.state.startDate)) {
            url += `&endDate=${this.state.endDate}`;
        }
        serviceGet(url, {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
            .then((res) => {
                if (res.data) {
                    res.data.responseObject.map(r => {
                        r.agentId = "P" + this.padLeft(r.agentId, 5); // "00001" 
                        return r
                    })
                    console.log("DATA EX", res.data.responseObject);
                    callback(res.data.responseObject)
                    console.log(res.data.responseObject);
                }
            }).catch((error) => {
                console.log(error);
                this.setState({
                    loading: false
                })
            });
    }
    handleKeyPress(e) {
        if (e.key === " ") {
            e.preventDefault();
        }
    }
    sortList = (sortBy,orderBy)=>{
        this.setState({
            sortBy : sortBy,
            orderBy : orderBy
        },()=>{
            this.getAgentList();
        });
    }
  
    deleteSelectedAgents = ()=>{
        Swal.fire({
            title: 'Are you sure?',
            // text: "You want to delete ",
            icon: 'warning',
            html: 'You want to delete selected agents',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
          }).then((result) => {
            if (result.isConfirmed) {
                
                let headers = {
                    'Content-Type': 'application/json',
                    Authorization: 'Bearer ' + this.state.user.token
                };
                let agentIds = {
                    ids : this.state.selectAgents
                }
                this.setState({
                    pageLoading: true
                })
                servicePost('api/v1/agent/delete',agentIds,headers)
                .then((res) => {
                    if(res.data) {
                            this.setState({
                                pageLoading: false,
                                selectAgents : []
                            }, () =>{
                                Toast.fire({
                                    icon: 'success',
                                    title: 'Delete agents successfully'
                                    
                                  });
                                  this.getAgentList();
                            });
                    } else {
                        this.setState({
                            pageLoading: false
                        })
                    }
                })
                .catch((err) => {
                    console.log(err)
                    this.setState({
                        pageLoading: false
                    })
                    Toast.fire({
                        icon: 'error',
                        title: 'Some error occurred'
                      });
                })
 
            
            }
          })
         
    }


  
    generateRefferalId(length) {
        var result           = '';
        var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for ( var i = 0; i < length; i++ ) {
          result += characters.charAt(Math.floor(Math.random() *  charactersLength));
        }
        return result;
    }
 
    render() {
      
        const MyExportCSV = (props) => {
            const handleClick = () => {
                this.getExportData(this.state.searchName, (responseObject) => {
                   
                    props.onExport(responseObject);
                });
            };
            return (
                <div>
                    
                    <button className="btn btn-sm btn-outline-success" onClick={handleClick}>
                        <i className="uil uil-file-download-alt mr-2"></i>
                        Export to CSV
                    </button>
                </div>
            );
        };
        var baseUrl = SERVICE_URL;
        const agentColumn = [
            // {
            //     dataField: '_id',
            //     text: <CustomInput type="checkbox" className="rowCheckbox" id="SelectAllAgent" defaultChecked={this.state.selectAgents == this.state.agentList.map(a=>{return a._id;})} onChange={this.selectAllAgent} />,
            //     formatter: (cell, row, index) => {
            //         return (<React.Fragment>
                        
            //                 {row._id}
            //                {this.state.selectAgents.includes(row._id) ? 'true' : 'false'}
            //             <CustomInput className="rowCheckbox" type="checkbox" defaultChecked={this.state.selectAgents.includes(row._id)} id={row._id} /></React.Fragment>)
            //     },
            //     csvExport: false,
            //     onSort: (field, order) => {
            //         console.log("field",field);
            //         console.log("order",order);
            //     },
                
            // }
            // ,
            {
                dataField: 'agentId',
                text: 'Agent Id',
                // style: { width: '10%' },
                sort: true,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'profile_pic',
                text: 'Image',
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <img src={SERVICE_URL +"/"+ cell} className="rounded-circle"  onError={(e)=>{e.target.onerror = null; e.target.src=""+SERVICE_URL +"/default.png"}} alt="Agent_profile" width="50" height="50"/>

                    </React.Fragment>)
                }
            },
            {
                dataField: 'name',
                text: 'Name',
                sort: true,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'createdAt',
                text: 'Register Time/Date',
                sort: true,
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>
                        <div>{moment(cell).format('MM-DD-YYYY')}</div>
                    </React.Fragment>)
                },
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'invitedBy.name',
                text: 'Invited By',
                sort: true,
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>
                        {row.invitedBy ? row.invitedBy.name : '-'}
                    </React.Fragment>)
                },
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'position',
                text: 'Position',
                sort: true,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'earnings',
                text: 'Earnings',
                sort: true,
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>
                        <div className="text-info">{'$ ' + cell}</div>
                    </React.Fragment>)
                },
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'earned',
                text: 'Earned',
                sort: true,
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>
                        <div>{'$ ' + cell}</div>
                    </React.Fragment>)
                },
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'position',
                text: 'Action',
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>

                        <div className="text-success pl-1"><i className="uil uil-edit" onClick={(e) => { this.toggle('editAgent', row); }}></i></div>
                    </React.Fragment>)
                },
                csvExport: false,
            },
        ]
       
          const selectRow = {
            mode: 'checkbox',
            clickToSelect: true,
            selectionHeaderRenderer: ({ indeterminate, ...rest }) => (
              <CustomInput
                type="checkbox" className="rowCheckbox"
                
                ref={ (input) => {
                  if (input) input.indeterminate = indeterminate;
                } }
                { ...rest }
              />
            ),
            selectionRenderer: ({ mode, ...rest }) => (
              <CustomInput className="rowCheckbox" type={ mode } { ...rest } />
            ),
            selected : this.state.selectAgents,
            onSelect: (row, isSelect, rowIndex, e) => {
                    var selectedAgentsList = this.state.selectAgents;
                    if(isSelect){
                        selectedAgentsList.push(row._id);
                        
                    }else{
                        selectedAgentsList = selectedAgentsList.filter(x=> x != row._id);
                    }
                    this.setState({
                        selectAgents : selectedAgentsList
                    })
              },
              onSelectAll: (isSelect, rows, e) => {
                     var selectedAgentsList = this.state.selectAgents;
                    if(isSelect){
                        var selectAllperPage = this.state.agentList.map((x)=>{return x._id;});
                        selectedAgentsList = selectedAgentsList.concat(selectAllperPage);
                    }else{
                        var dd = this.state.agentList.map((a)=>{return a._id;});
                        var tt = selectedAgentsList.filter(x=> dd.indexOf(x) < 0 );
                        
                        selectedAgentsList = tt;
                    }
                    this.setState({
                        selectAgents : selectedAgentsList
                    })
              }
          };
      
        return (
            <React.Fragment>
                
                {this.state.pageLoading ? <Loader /> :
                    <div className="container-fluid">
                        <div className="card shadow mt-4">
                            <div className="card-header page-heading pt-4 pb-3">
                                <div className="row">
                                    <div className="col-md-12">
                                        <h3 className="text-dark">List of Agents </h3>
                                    </div>
                                    <div className="col-md-3 pt-3">
                                        <div className="text-md-left dataTables_filter search-box-div" id="dataTable_filter">
                                            <i className="uil uil-search search-icon"></i>
                                            <input type="search" id="searchByName" value={this.state.searchName} className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search" onChange={(event) => {
                                                this.setState({
                                                    searchName: event.target.value
                                                }, () => {
                                                    this.getAgentList(this.state.searchName, 0)
                                                })
                                            }} />
                                        </div>
                                    </div>
                                    <div className="col-md-3 pt-3">
                                        <div className="input-group">
                                            <label className="mt-2 mr-1">Start Date</label>
                                            <input type="date" id="startDate" name="startDate" className="form-control date-box" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={this.handleChange} />
                                        </div>
                                    </div>
                                    <div className="col-md-3 pt-3">
                                        <div className="input-group">
                                            <label className="mt-2 mr-1">End Date</label>
                                            <input type="date" id="endDate" name="endDate" className="form-control date-box" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={this.handleChange} />
                                        </div>
                                    </div>
                                    <div className="col-md-2 text-md-right pt-3">
                                        {this.state.user.roles.indexOf('addAgent') > -1 ?
                                            <button type="button" className="btn btn-sm btn-primary px-3 py-2" onClick={(e) => { this.toggle(); }}>Add Agent</button> : null
                                        }
                                    </div>
                                    <div className="col-md-1 mt-2 font-size-20 pt-3">
                                        <i className="uil uil-sync" onClick={(e) => {
                                            this.setState({
                                                searchName: '',
                                                startDate: null,
                                                endDate: null,
                                                currentPage: 0,
                                                page: 1,
                                                selectAgents : []
                                            }, () => {
                                                document.getElementById("startDate").value = "";
                                                document.getElementById("endDate").value = "";
                                                this.getAgentList();
                                            })
                                        }}></i>
                                    </div>
                                </div>
                            </div>
                            <div className="card-body p-0">

                                
                                <ToolkitProvider
                                    bootstrap4
                                    keyField="_id"
                                    data={this.state.agentList}
                                    columns={agentColumn}
                                    exportCSV={{
                                        fileName: 'AgentList_Report_' + Date.now() + '.csv',
                                    }}
                                // search
                                // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                                >
                                    {props => (
                                        <React.Fragment>
                                            <div className="grid-action-row border-top p-2 pl-4">
                                               
                                                <div class="btn-group">
                                                    {
                                                        this.state.selectAgents != null && this.state.selectAgents.length > 0 ? 
                                                            <button onClick={(e)=>{this.deleteSelectedAgents()}} className="btn btn-sm btn-danger mr-2" >
                                                            <i className="uil uil-trash mr-2"></i>
                                                            Delete all selected agets ({this.state.selectAgents.length})
                                                        </button> : <></>
                                                    }
                                                   
                                                    <MyExportCSV {...props.csvProps} />
                                                </div>
                                                
                                            </div>
                                            
                                            <BootstrapTable
                                                
                                                selectRow={ selectRow }
                                                {...props.baseProps}
                                                bordered={false}
                                                wrapperClasses="table-responsive pl-3 pr-3"
                                                noDataIndication={this.state.loading ? <Loader /> : 'No Data Found'}
                                            />
                                        </React.Fragment>
                                    )}
                                </ToolkitProvider>
                            </div>
                        </div>
                        <div className="row">
                            <div className="text-nowrap mt-4">
                                {/* <div id="dataTable_length" className="dataTables_length" aria-controls="dataTable"><label>Show&nbsp;<select className="form-control form-control-sm custom-select custom-select-sm"><option value="10" selected="">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select>&nbsp;</label></div> */}
                                <ReactPaginate previousLabel={"Previous"}
                                    pageCount={this.state.pageCount}
                                    nextLabel={"Next"}
                                    onPageChange={(event) => { this.changePage(event) }}
                                    forcePage={this.state.currentPage}
                                    containerClassName={"paginationBttns"}
                                    previousLinkClassName={"previousBttn"} nextLinkClassName={"nextBttn"}
                                    activeLinkClassName={"paginationActive"} disabledClassName={"paginationDisabled"}>
                                </ReactPaginate>
                            </div>
                        </div>
                        <Modal
                            isOpen={this.state.modal}
                            toggle={this.toggle}
                            className={this.state.className}
                            size='lg'>
                            <div><ModalHeader toggle={this.toggle}>{this.state.modalType === 'editAgent' ? 'Update Agent Information' : 'Create Agent Information'}</ModalHeader>
                                <AvForm onValidSubmit={this.createAgent}>
                                    <ModalBody>
                                        <Row>
                                            <Col md={6}>
                                                <label>Agent Name</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                                <AvField name="name" type="text" required placeholder="Enter Agent Name" autoComplete="false" value={this.state.name} onChange={this.handleChange}
                                                    validate={{ required: { value: true } }} />
                                            </Col>
                                            <Col md={6}>
                                                <label>Email</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                                <AvField name="email" type="email" required placeholder="Email" autoComplete="false" value={this.state.email} onChange={this.handleChange}
                                                    disabled={this.state.modalType === 'editAgent'}
                                                    validate={{ required: { value: true } }} />
                                            </Col>
                                            <Col md={6}>
                                                <label>Password</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                                <span className="password-position">
                                                    <AvField name="password" type="password" required={this.state.modalType !== 'editAgent'} placeholder="Enter Password" autoComplete="new-password" value={this.state.password} onKeyPress={this.handleKeyPress} onChange={this.handleChange}
                                                        validate={{
                                                            pattern: { value: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/, errorMessage: 'Password must contain a lowercase letter, a uppercase letter, a number, a special character and minimum 8 characters' },
                                                            required: { value: true, errorMessage: 'Please enter password' },
                                                        }}
                                                    />
                                                </span>
                                                {this.state.modalType === 'editAgent' ? <div className="mb-2 text-primary"><i className="uil uil-info-circle info-icon"></i><small>If filled,then existing password will be updated else leave blank</small></div> : ''}
                                            </Col>
                                            <Col md={6}>
                                                <AvGroup row>
                                                    <Col sm={12}>
                                                        <Label for="example" className="text-muted">Position</Label><span className="text-danger pt-2"><sup>*</sup></span>
                                                        <Select
                                                            onChange={this.onChangePosition}
                                                            value={[{
                                                                value: this.state.position,
                                                                label: this.state.position
                                                            }]}
                                                            // isMulti={true}
                                                            options={[
                                                                { value: 'Agent', label: 'Agent' },
                                                                { value: 'Trainer', label: 'Trainer' }
                                                            ]}
                                                            className="react-select"
                                                            classNamePrefix="react-select"
                                                            placeholder={'Select a position'}
                                                        />
                                                    </Col>
                                                </AvGroup>
                                            </Col>
                                            <Col md={6}>
                                                <label>Phone Number </label> <span className="text-danger pt-2"><sup>*</sup></span>
                                                <AvField name="phoneNumber" type="number" required placeholder="Enter Phone Number" autoComplete="false" value={this.state.phoneNumber+''} onChange={this.handleChange}
                                                     onKeyPress={function(e){
                                                        if (e.target.value.length >= 10 ) {
                                                            e.preventDefault();
                                                        }
                                                     }}
                                                    validate={{
                                                        minLength: { value: 8, errorMessage: 'Please enter valid1 phone number' },
                                                        maxLength: { value: 10, errorMessage: 'Please enter valid2 phone number' },
                                                        required: { value: true, errorMessage: 'Please enter valid3 phone number' }
                                                    }}
                                                />
                                            </Col>
                                            <Col md={6}>
                                                <AvGroup row>
                                                    <Col sm={12}>
                                                        <Label for="example" className="text-muted">Invite By</Label>
                                                        <Select
                                                        isDisabled={this.state.modalType === 'editAgent'}
                                                        
                                                            onInputChange={(value) => this.getInviters(value)}
                                                            onChange={this.onChangeInviter}
                                                            value={[{ 'value': this.state.inviteBy?.value, 'label': this.state.inviteBy?.label }]}
                                                            // isMulti={true}
                                                            options={this.state.inviters}
                                                            className="react-select"
                                                            classNamePrefix="react-select"
                                                            placeholder={'Search inviter'}
                                                        />
                                                    </Col>
                                                </AvGroup>
                                            </Col>
                                            <Col md={6}>
                                                <label>Country Code</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                                <AvField name="countryCode" type="number" required placeholder="Enter Country Code" autoComplete="false" value={this.state.countryCode} onChange={this.handleChange}
                                                    validate={{
                                                        maxLength: { value: 4, errorMessage: 'Please eneter country code' },
                                                        minLength: { value: 1, errorMessage: 'Please eneter country code' },
                                                        required: { value: true, errorMessage: 'Please enter country code' },
                                                    }}
                                                />
                                            </Col>
                                            <Col md={6}>
                                                <label>Refferal code</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                                <AvField name="RefferalCode" type="text" required placeholder="Enter Refferal code" autoComplete="false" value={this.state.Refferalcode} onChange={this.handleChange}
                                                    validate={{ required: { value: true } }} />
                                            </Col>
                                        </Row>
                                    </ModalBody>
                                    <ModalFooter>
                                        <button className="btn btn-outline-primary btn-lg">{this.state.modalType === 'editAgent' ? 'Update' : 'Create'}</button>
                                        <button className="btn btn-outline-danger btn-lg" onClick={this.toggle}>Cancel</button>
                                    </ModalFooter>
                                </AvForm>
                            </div>
                        </Modal>
                    </div>
                }
            </React.Fragment>
        )
    }
}
export default Agent;