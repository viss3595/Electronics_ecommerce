import React,{Component} from 'react';
import Loader from '../../components/Loader';
import ReactPaginate from 'react-paginate';
import Select from 'react-select';
import {CustomInput, Row, Col } from 'reactstrap';
import AvField from 'availity-reactstrap-validation/lib/AvField';
import AvForm from 'availity-reactstrap-validation/lib/AvForm';
import { getLoggedInUser } from '../../helpers/authUtils';
import { serviceGet} from './../../helpers/api';

import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import { ExternalLink } from 'react-feather';

class AddNotification extends Component
{
        constructor(props) {
        super(props);

        this.state = {
            user: getLoggedInUser(),
            modal: false,
            loading: true,
            pageLoading: false,
            notificationAgentList: [],
            currentPage:1,
            size:10,
            pageCount:1,
            searchName: '',
            status:'',
            notificationTitle: null,
            description: null
        };
        this.createNotification = this.createNotification.bind(this);
        this.getNotificationAgents= this.getNotificationAgents.bind(this);
        this.changePage = this.changePage.bind(this);
    }
    
    componentDidMount(){     
        this.getNotificationAgents();
    }

    getNotificationAgents = () =>{
        this.setState({
            notificationAgentList: [],
            loading: true
        })
        console.log(this.state.searchName);
        let url = `api/v1/agent/list?name=${this.state.searchName}&page=${this.state.currentPage}&size=${this.state.size}&status=${this.state.status}`;
        if(this.state.startDate && this.state.endDate){
          url+= `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
        }else if(this.state.startDate && (!this.state.endDate)){
          url+= `&startDate=${this.state.startDate}`;
        }else if(this.state.endDate && (!this.state.startDate)){
          url+= `&endDate=${this.state.endDate}`;
        }
        serviceGet(url,{
             'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
        .then((res)=>{
              if(res.data){
                this.setState({
                    notificationAgentList: res.data.responseObject,
                    pageCount: res.data.totalElements <10 ? 1 : Math.ceil(res.data.totalElements / 10),
                    loading: false
                })
             }
        }).catch((error) => {
            console.log(error);
            this.setState({
                 loading: false
            })
        });
    }

    createNotification = () => {

    }

    handleChange = (event) => {
        if(event.target.name === 'startDate' || event.target.name === 'endDate'){
          let date = new Date(event.target.value);
          this.setState({
            [event.target.name]: date.toISOString()
          });
        }else{
        this.setState({
            [event.target.name]: event.target.value
        });
       }
    }

    searchByName = (name) =>{
        if(!name) {
            this.setState({
                searchName: ''
            }, () => this.getNotificationAgents())
        } else {
            let headers = {
                    'Content-Type': 'application/json',
                    Authorization: 'Bearer ' + this.state.user.token
                };
            if(name.length > 2) {
                this.setState({
                    notificationAgentList: [],
                    searchName: name,
                    loading: true
                })
                serviceGet(`api/v1/agent/list?name=${name}&page=${1}&size=${10}`,headers)
                .then((res) => {
                    if(res.data){
                        this.setState({
                            loading: false,
                            notificationAgentList: res.data.responseObject,
                            pageCount: res.data.totalElements <10 ? 1 : Math.ceil(res.data.totalElements / 10)
                        });
                    }
                }).catch((error) => {
                    console.log(error);
                    this.setState({
                         loading: false
                    })
                });
            }
        }
    }

    changePage = ({selected})=>{
        this.setState({
            currentPage: selected + 1,
            notificationAgentList: []
        },()=>{this.getNotificationAgents()});
     }

    onChangeStatus = async (selectedValue) => {
        this.setState({
            status: selectedValue.value
        });
    }
    
    render() {
        return (
             <React.Fragment>
                  { this.state.pageLoading ? <Loader/> : 
            <div className="container-fluid">
                <div className="card shadow mt-4">
                    <div className="card-header page-heading pt-4 pb-3">
                        <div className="row">
                            <div className="col-md-12">
                                    <h3 className="text-dark">ADD NOTIFICATION</h3>
                            </div>
                        </div>
                    </div>
                    <div className="card-body pl-4">    
                        <AvForm onValidSubmit={this.createNotification}>
                            <Row>
                                <Col md={12} className="">
                                    <label>Notification Title</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                    <AvField name="notificationTitle" type="text" required placeholder="Enter Title" autoComplete="false" value={this.state.notificationTitle} onChange={this.handleChange}
                                        validate = {{required: {value: true}}}/>
                                </Col>
                                <Col md={12} className="mt-3">
                                    <label>Description</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                    <AvField name="description" type="text" required placeholder="Enter Description" autoComplete="false" value={this.state.description} onChange={this.handleChange}
                                        validate = {{required: {value: true}}}/>
                                </Col>
                            </Row>
                        </AvForm>
                    </div>
                </div>
            </div>
            }
            </React.Fragment>
        )
    }
}
export default AddNotification;