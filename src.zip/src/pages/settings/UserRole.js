import { AvForm, AvGroup, AvField } from 'availity-reactstrap-validation';
import React,{ Component } from 'react';
import ReactPaginate from 'react-paginate';
import { Modal, ModalFooter, Col, ModalBody, ModalHeader, Row, Button, CustomInput, Table } from 'reactstrap';
import { getLoggedInUser } from '../../helpers/authUtils';
import { dateFormat } from '../../helpers/common';
import { serviceGet, servicePost, servicePut, serviceDelete } from './../../helpers/api';
import UserRoleDropDown from './UserRoleDropDown';
import Loader from '../../components/Loader';
import Roles from '../../constants/roles.json';
import moment from 'moment';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import { toast } from 'react-toastify';
const Swal = require('sweetalert2')
const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })

class UserRole extends Component
{
        constructor(props) {
        super(props);

        this.state = {
            user: getLoggedInUser(),
            modal: false,
            loading: true,
            pageLoading: false,
            rolesList: [],
            roleName: '',
            roles: [],
            roleId: null,
            size: 'lg',
            modalType: null,
            openCollapse: [],
            currentPage: 1,
            size: 10,
            pageCount: 1,
        };
        this.toggle = this.toggle.bind(this);
        this.getRolesList= this.getRolesList.bind(this);
        this.createRole= this.createRole.bind(this);
        this.changePage = this.changePage.bind(this);
        this.updateTab = this.updateTab.bind(this);
        this.deleteRole = this.deleteRole.bind(this);
    }
    
    componentDidMount(){     
        this.getRolesList();
    }

    getRolesList = () => {
        this.setState({
            rolesList: [],
            loading: true
        })
        serviceGet(`api/v1/roles/search?page=${this.state.currentPage}&size=${this.state.size}`, {
             'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
        .then((res)=>{
              if(res.data){
                this.setState({
                    rolesList: res.data,
                    pageCount: res.totalElements < 10 ? 1 : Math.ceil(res.data.totalElements / 10),
                    loading: false
                })
             }
        }).catch((error) => {
            console.log(error);
                this.setState({
                     loading: false
                })
        });
    }

    createRole = () => {
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        let role = {
          'roleName': this.state.roleName,
          "roles": this.state.roles,
        }
        if(this.state.roleId){
            let roleId = this.state.roleId;
            servicePut(`api/v1/roles/${roleId}`, JSON.stringify(role), headers)
            .then((res)=>{
                if(res.data){
                    toast('User role updated successfully',{bodyClassName:'success-toast'});
                    this.getRolesList();
                    this.toggle();
                }else{
                    toast(res.error,{bodyClassName:'error-toast'});
                }
            })
            .catch((err) => {
            console.log(err)
            toast('Some error occurred',{bodyClassName:'error-toast'});
         })
        }else{
            servicePost('api/v1/roles/',JSON.stringify(role), headers)
            .then((res)=>{
                if(res.data){
                    toast('User role created successfully',{bodyClassName:'success-toast'});
                    this.getRolesList();
                    this.toggle();
                }else{
                    toast(res.error,{bodyClassName:'error-toast'});
                }
            })
            .catch((err) => {
                console.log(err)
                toast('Some error occurred',{bodyClassName:'error-toast'});
            })
      }
    }

    toggle = (modal, role) => {
        if(role != null) {
            console.log(role);
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                roleId: role._id,
                roleName: role.roleName,
                roles: role.rolesAssociated
            }))
        } else {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                roleId: null,
                roleName: '',
                roles: []
            }))
        }
    };

    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });
    }

    searchByName = (name) => {
        if(!name) {
            this.getRolesList();
        } else {
            let headers = {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.state.user.token
            };
            if(name.length > 2){
                this.setState({
                    loading: true
                })
                serviceGet(`api/v1/roles/search?name=${name}&page=${1}&size=${10}`,headers)
                .then((res) => {
                    if(res.data) {
                        this.setState({
                            loading: false,
                            rolesList: res.data,
                            pageCount: res.totalElements < 10 ? 1 : Math.ceil(res.data.totalElements / 10),
                        });
                    }
                }).catch((error) => {
                    console.log(error);
                    this.setState({
                         loading: false
                    })
                });
            }
        }
    }

    deleteRole = (roleId) => {
        



        if (roleId) {

            Swal.fire({
                title: 'Are you sure?',
                // text: "You want to delete ",
                icon: 'warning',
                html: 'You want to delete role',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
              }).then((result) => {
                if (result.isConfirmed) {
                    
                    this.setState({
                        pageLoading: true
                    })
                    let headers = {
                        'Content-Type': 'application/json',
                        Authorization: 'Bearer ' + this.state.user.token
                    };
                    serviceDelete(`api/v1/roles/${roleId}/delete`, headers)
                    .then((res) => {
                        if (res.data) {
                            this.setState({
                                pageLoading: false
                            })
                            this.getRolesList();
                            Toast.fire({
                                icon: 'success',
                                title: 'Delete agents successfully'
                                
                              });
                        }
                         else {
                            this.setState({
                                pageLoading: false
                            })
                        }
                    })
                    .catch((err) => {
                        console.log(err)
                        this.setState({
                            pageLoading: false
                        })
                        Toast.fire({
                            icon: 'error',
                            title: 'Some error occurred'
                          });
                    })
     
                
                }
              })


            
        }
    }

    changePage = ({selected}) => {
        this.setState({
            currentPage: selected + 1,
            rolesList: []
        },() => {this.getRolesList()});
     }
 
    updateTab = (e, label) => {
        console.log(e.target.value, label);
        let updatedRoles = Object.assign([], this.state.roles);
        if (this.state.roles.indexOf(label) == -1) {
            updatedRoles.push(label);
            this.setState({
                roles: updatedRoles
            }, () => {console.log(this.state.roles);})
        } else {
            updatedRoles = updatedRoles.filter((role) => {
                return role !== label;
            })
            this.setState({
                roles: updatedRoles
            }, () => {console.log(this.state.roles);})
        } 
    }
    
    render() {

        const userRoleColumn = [
            {
                dataField: '_id',
                text: <i className = "uil uil-square"></i>,
                formatter : (cell,row,index)=>{
                  return (<React.Fragment><CustomInput className="rowCheckbox" type="checkbox" id={row._id}/></React.Fragment>)
                }
            },
            {
                dataField: 'roleId',
                text: 'Role Id',
                // style: { width: '10%' },
                sort: true,
            },
            {   
                dataField: 'roleName',
                text: 'Name',
                sort : true
            },
            {
                dataField: 'createdAt',
                text: 'Create Time/Date',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <div>{moment(cell).format('MM-DD-YYYY')}</div>
                        </React.Fragment>)
                }
            },
            {   
                dataField: 'edit',
                text: 'Action',
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <span className="text-success pl-1"><i className="uil uil-edit" onClick={(e) => {this.toggle('editUser', row);}}></i></span>
                            <span className="text-danger pl-1"><i className="uil uil-glass-tea" onClick={() => this.deleteRole(row._id)}></i></span>
                        </React.Fragment>)
                }
            }
        ]

        const selectRow = {
            mode: 'checkbox',
            clickToSelect: true
        };


        return (
            <React.Fragment>
                { this.state.pageLoading ? <Loader/> : 
                <div className="container-fluid">
                    <div className="card shadow mt-4">
                        <div className="card-header page-heading pt-4 pb-3">
                            <div className="row">
                                <div className="col-md-3">
                                        <h3 className="text-dark">User Role</h3>
                                    </div>
                                <div className="col-md-3 pt-3">
                                    <div className="text-md-left dataTables_filter search-box-div" id="dataTable_filter">
                                            <i className="uil uil-search search-icon"></i>
                                            <input type="search" className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search by name" onChange={(event)=>{this.searchByName(event.target.value)}}/>
                                    </div>
                                </div>
                                <div className="col-md-6 text-md-right">
                                    <button type="button" className="btn btn-sm btn-primary mt-2 float-right" onClick={(e) => {this.toggle();}}>Add Role</button>
                                </div>
                            </div>
                        </div>
                        <div className="card-body p-0">     
                            <ToolkitProvider
                                bootstrap4
                                keyField="id"
                                data={this.state.rolesList}
                                columns={userRoleColumn}
                                // search
                                // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                            >
                                {props => (
                                    <React.Fragment>
                                        <BootstrapTable
                                            {...props.baseProps}
                                            bordered={false}
                                            wrapperClasses="table-responsive pl-3 pr-3"
                                            // selectRow={ selectRow }
                                            noDataIndication={ this.state.loading ? <Loader/> : 'No Data Found'}
                                        />
                                    </React.Fragment>
                                )}
                            </ToolkitProvider>
                        </div>
                    </div>
                    <div className="row">
                        <div className="text-nowrap mt-4">
                            <ReactPaginate previousLabel={"Previous"} 
                                pageCount={this.state.pageCount}
                                nextLabel={"Next"} 
                                onPageChange={this.changePage} 
                                containerClassName={"paginationBttns"}
                                previousLinkClassName={"previousBttn"} nextLinkClassName={"nextBttn"}
                                activeLinkClassName={"paginationActive"} disabledClassName={"paginationDisabled"}>
                            </ReactPaginate>
                        </div>
                    </div>
                    <Modal
                        isOpen={this.state.modal}
                        toggle={this.toggle}
                        className={this.state.className}
                        size="lg">
                            <div><ModalHeader toggle={this.toggle}>{this.state.modalType === 'editUser'? 'Edit Role' : 'Add Role'}</ModalHeader>
                            <AvForm onValidSubmit={this.createRole} className="table-head">
                                <ModalBody className="mx-3 px-5">
                                    <Row>
                                        <Col md={12}>
                                            <label className="m-0">Role Name</label> <span className="text-danger"><sup>*</sup></span>
                                            <AvField name="roleName" type="text" required autoComplete="false" className="input-bottom-border" value={this.state.roleName} onChange={this.handleChange}
                                                validate = {{required: {value: true}}}/>
                                        </Col>

                                        { Roles.length > 0 ? Roles.map((role, index) => {
                                            return <UserRoleDropDown
                                                        roles={this.state.roles}
                                                        tabs={role.tabs}
                                                        title={role.title}
                                                        updateTab={this.updateTab}
                                                    />
                                        }) :  <span className="pl-4 permission-status">No Roles Present</span>}

                                        <Col md={12} className="my-4 heading-div">
                                            <button className="btn btn-outline-danger btn-lg mr-4 popup-button" onClick={this.toggle}>Cancel</button>
                                            <button className="btn btn-outline-primary btn-lg popup-button">Save</button>
                                        </Col>
                                    </Row>
                                </ModalBody>
                            </AvForm> 
                        </div>
                    </Modal>
                </div>
                }
            </React.Fragment>
        )
    }
}
export default UserRole;