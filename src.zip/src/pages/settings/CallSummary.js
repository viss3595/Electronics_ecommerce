import React, { Component } from 'react';
import { Row, Col, Input, Card, CardBody, CardText } from 'reactstrap';
import ToolkitProvider, { Search, CSVExport } from 'react-bootstrap-table2-toolkit';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import { setDateRange, setPastDateRange } from '../../redux/actions';
import PageTitle from '../../components/PageTitle';
import { connect } from 'react-redux';
import { servicePost } from './../../helpers/api';
import Loader from '../../components/Loader';
import UniversalDatePicker from './../miscellaneous/UniversalDatePicker';
import { toast } from 'react-toastify';
import { PhoneCall } from 'react-feather';
import { Tooltip } from 'react-tippy';
import BetterDatePicker from '../miscellaneous/BetterDatePicker';
import Select from 'react-select';

const sizePerPageRenderer = ({ options, currSizePerPage, onSizePerPageChange }) => (
    <React.Fragment>
        <label className="d-inline mr-1">Show</label>
        <Input
            type="select"
            name="select"
            id="no-entries"
            className="custom-select custom-select-sm d-inline col-2"
            defaultValue={currSizePerPage}
            onChange={(e) => onSizePerPageChange(e.target.value)}>
            {options.map((option, idx) => {
                return <option key={idx}>{option.text}</option>;
            })}
        </Input>
        <label className="d-inline ml-1">entries</label>
    </React.Fragment>
);

const SelectSearch = (data) => {
    // alert(JSON.stringify(data))
    const { SearchBar } = Search;
    // const records = props.data;

    return (
        <React.Fragment>
            {/* <Row>
                <Col md={2}>
                <Input type="select" name="selectMulti" id="SelectMulti" onChange={handleChange.bind(this)}>
                                    <option value="LAST_7_DAYS">Last 7 days</option>
                                    <option value="TODAY">Today</option>
                                    <option value="YESTERDAY">Yesterday</option>
                                    <option value="LAST_15_DAYS">Last 15 days</option>
                </Input>
                </Col>
            </Row> */}
           
        </React.Fragment>
    );
};

class CallSummary extends Component {
    constructor(props) {
        super(props);

        this.state = {
            records: [],
            resData: [],
            loader: true,
            callsCount: 0,
            callsCountPrev: 0,
            totalSeconds: 0,
            totalSecondsPrev: 0,
            agentsCount: 0,
            teamOptions : [],
            selectedTeam : '',
        };

        console.log('--->>>>', this.props);
        // this.FontAwesomeCloseButton = this.FontAwesomeCloseButton.bind(this)
    }

    onChangeTeam = async (selectedTeam) => {

        this.getMomentAnalysis(selectedTeam, true)
        
    };

    getRateOfChange = (previousValue, newValue) => {
        // alert(previousValue, newValue);
        try {
            let p = Number(newValue) / Number(previousValue);
            if (Number(previousValue) == 0) {
                throw 'Divide by Zero';
            }
            let rateOfChange = Number((p - 1) * 100).toFixed(0);
            if (isNaN(rateOfChange) || rateOfChange === Infinity) {
                throw rateOfChange;
            }
            return {
                rateOfChange: rateOfChange,
            };
        } catch (error) {
            return {
                rateOfChange: 0.0,
            };
        }
    };

    getRocTextHtml = (rateOfChange, prevValue, message) => {
        if (rateOfChange == 0) {
            return (
                <React.Fragment>
                    <div class="dashboard-since-timestamp">
                        vs. previous 7<br /> days period
                    </div>
                    <div
                        style={{ color: 'darkgray', textAlign: 'center' }}
                        class="font-weight-bold dashboard-summary-flash-card-text">
                        {' '}
                        <Tooltip
                            // options
                            title={`${message} : ${prevValue}`}
                            position="top-end"
                            arrow={true}
                            trigger="mouseenter">
                            <span className="font-size-14 font-weight-bold">{rateOfChange}%</span>
                        </Tooltip>
                    </div>
                </React.Fragment>
            );
        } else if (rateOfChange > 0) {
            return (
                <React.Fragment>
                    <div class="dashboard-since-timestamp">
                        vs. previous 7<br /> days period
                    </div>
                    <div
                        style={{ textAlign: 'center' }}
                        class="text-success font-weight-bold dashboard-summary-flash-card-text">
                        <i class="uil uil-arrow-up"></i>
                        <Tooltip
                            // options
                            title={`${message} : ${prevValue}`}
                            position="top-end"
                            arrow={true}
                            trigger="mouseenter">
                            <span className="font-size-14 font-weight-bold" style={{ color: 'darkgray' }}>
                                {Math.abs(rateOfChange)}%
                            </span>
                        </Tooltip>
                    </div>
                </React.Fragment>
            );
        } else {
            return (
                <React.Fragment>
                    <div class="dashboard-since-timestamp">
                        vs. previous 7<br /> days period
                    </div>
                    <div
                        style={{ textAlign: 'center' }}
                        class="text-danger font-weight-bold dashboard-summary-flash-card-text">
                        <i class="uil uil-arrow-down"></i>
                        <Tooltip
                            // options
                            title={`${message} : ${prevValue}`}
                            position="top-end"
                            arrow={true}
                            trigger="mouseenter">
                            <span className="font-size-14 font-weight-bold" style={{ color: 'darkgray' }}>
                                {Math.abs(rateOfChange)}%
                            </span>
                        </Tooltip>
                    </div>
                </React.Fragment>
            );
        }
    };

    getMomentAnalysis = (selectedTeam = null, doloading = false) => {
        
        // if(doloading){
        //     this.setState({
        //         loading : true
        //     })
        // }


        this.setState({
            records: [],
            callsCount: 0,
            callsCountPrev: 0,
            totalSeconds: 0,
            totalSecondsPrev: 0,
            agentsCount: 0
        });

        if (doloading) {
            this.setState({
                loader: true,
            });
        }

        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'JWT ' + this.props.user.token,
        };

        servicePost(
            'api/v1/analyse/get/summary',
            {
                userId: this.props.user.id,
                dateRange: this.props.dateRange,
                pastDateRange: this.props.pastDateRange,
                teamId: selectedTeam.value,
            },
            headers
        )
            .then((res) => {
                //  if( res.data.summary.length > 0 ){
                this.setState({
                    records: res.data.summary,
                    callsCount: res.data.callsCount,
                    callsCountPrev: res.data.callsCountPrev,
                    totalSeconds: res.data.totalSeconds,
                    totalSecondsPrev: res.data.totalSecondsPrev,
                    agentsCount: res.data.agentsCount,
                    selectedTeam : selectedTeam,
                    loader: false,
                });
                // }
            })
            .catch((err) => {
                this.setState({
                    selectedTeam : selectedTeam,
                    loader: false,
                });
                console.log(err);
            });
    };

    getDate = (days) => {
        let today;
        //FIND DATE FOR LAST N DAYS
        if (days) {
            var date = new Date();
            today = new Date(date.getTime() - days * 24 * 60 * 60 * 1000);
        } else {
            //FIND TODAY DATE
            today = new Date();
        }
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();
        today = yyyy + '-' + mm + '-' + dd;
        return today;
    };

    handleChange = (event) => {
        // var value = event.target.value;
        // let date;
        // if (value == 'TODAY') {
        //     date = this.getDate();
        // } else if (value == 'LAST_7_DAYS') {
        //     date = this.getDate(7);
        // } else if (value == 'LAST_15_DAYS') {
        //     date = this.getDate(15);
        // } else if (value == 'YESTERDAY') {
        //     date = this.getDate(1);
        // } else {
        //     date = this.getDate(7);
        // }
        // try {
        //     let headers = {
        //         'Content-Type': 'application/json',
        //         Authorization: 'JWT ' + this.props.user.token,
        //     };
        //     servicePost('api/v1/analyse/get/call/all', { filter: value, date: date }, headers)
        //         .then((res) => {
        //             console.log(res.data);
        //         })
        //         .catch((err) => {
        //             console.log('========>error', err);
        //         });
        // } catch (err) {
        //     console.log('========>error', err);
        // }
    };

    handleDateChange = () => {
        this.getMomentAnalysis(this.state.selectedTeam, true);
        // this.getMomentAnalysisPast()
    };

    removeSession = (toast) => {
        sessionStorage.setItem('toastnotification', 1);
    };

    CloseButton = ({ closeToast }) => (
        <i className="uil uil-times" onClick={this.removeSession.bind(this, closeToast)}></i>
    );

    // CHECK FOR THE ERROR
    errorNotification = async () => {
        if (sessionStorage.getItem('toastnotification') != 1) {
            toast('Requested call of agent saxena0104jatin@gmail.com1 is not exits in agents table', {
                bodyClassName: 'error-toast',
                autoClose: false,
                progress: undefined,
                closeButton: this.CloseButton,
            });
            toast(
                'Transcription hours consumed for "jatin saxena1". The plan will reset on "date" or you can request for extra hours by sending us an email to abc@peter.com',
                { bodyClassName: 'error-toast', autoClose: false, progress: undefined, closeButton: this.CloseButton }
            );
        }

        // let headers = {
        //     'Content-Type': 'application/json',
        //     Authorization: 'JWT ' + this.props.user.token,
        // };

        // servicePost('api/v1/analyse/get/summary', { userId: this.props.user.id, dateRange : this.props.dateRange, pastDateRange: this.props.pastDateRange }, headers)
        // .then((res) => {
        //     //  if( res.data.summary.length > 0 ){
        //         toast( 'Updating Agent' ,{bodyClassName:'success-toast'});
        //     // }
        // })
        // .catch((err) => {
        //     console.log( err);
        // });
    };

    componentDidMount = async () => {
        this._isMounted = true;
        // this.errorNotification()
        try {
            
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'JWT ' + this.props.user.token,
        };

            let rawTeams = await servicePost('team/all', {}, headers);

            let teamOptions = rawTeams.data.map((team) => {
                return { label: team.teamName, value: team._id }
            })

            if(teamOptions.length > 0){
                this.setState({
                    teamOptions : teamOptions
                })  
            }
            
            if(teamOptions.length > 0){
                this.getMomentAnalysis(teamOptions[0], false);
            }
            else{
                this.setState({
                    loader : false
                })
            }
            
            // this.getMomentAnalysisPast()
        } catch (err) {
            console.log(err);
        }
    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    render() {
        if (this.state.loader) {
            return (
                <Row className="page-title mt-4">
                    <Col xl={12} md={12}>
                        <Loader />
                    </Col>
                </Row>
            );
        }
        let rocOfCall = this.getRateOfChange(this.state.callsCountPrev, this.state.callsCount);
        let rocOfCallMinutes = this.getRateOfChange(this.state.totalSecondsPrev, this.state.totalSeconds);

        return (
            <React.Fragment>
                <Row className="page-title">
                    <Col className="call-summary" md={12}>
                        <PageTitle
                            breadCrumbItems={[{ label: 'Dashboard', path: '/dashboard', active: true }]}
                            title={'Call Summary'}
                        />
                        {/* <UniversalDatePicker isWidthTimmed={true} handleDateChange={this.handleDateChange} /> */}
                    </Col>
                    <Col md={2}>
                    <Card>
                            <CardBody className="p-0">
                            <Select
                            options={this.state.teamOptions}
                            onChange={this.onChangeTeam}
                            value={this.state.selectedTeam}
                            placeholder={'Select Your Team'}
                            className="react-select"
                            classNamePrefix="react-select"></Select>
                            </CardBody>
                        </Card>

                    </Col>
                    <Col md={7}>
                        
                        
                    </Col>
                    <Col md={3}>
                        <BetterDatePicker handleDateChange={this.handleDateChange} />
                    </Col>
                </Row>
                <Row>
                    <Col md={4}>
                        <Card>
                            <CardBody>
                                <CardText>
                                    <Row>
                                        <Col className="center-col" md={8}>
                                            <i className="uil uil-phone icon-dashboard-circular"> </i>
                                            <span className="ml-2">
                                                Total calls transcribed: <strong>{this.state.callsCount}</strong>
                                            </span>
                                        </Col>
                                        <Col md={4}>
                                            {this.getRocTextHtml(
                                                rocOfCall.rateOfChange,
                                                this.state.callsCountPrev,
                                                'Calls transcribed previously'
                                            )}
                                        </Col>
                                    </Row>
                                </CardText>
                            </CardBody>
                        </Card>
                    </Col>
                    <Col md={4}>
                        <Card>
                            <CardBody>
                                <CardText>
                                    <Row>
                                        <Col className="center-col" md={8}>
                                            <i className="uil uil-clock-three icon-dashboard-circular"> </i>
                                            <span className="ml-2">
                                                Minutes transcribed:{' '}
                                                <strong>{Math.round(this.state.totalSeconds / 60)}</strong>
                                            </span>
                                        </Col>
                                        <Col md={4}>
                                            {this.getRocTextHtml(
                                                rocOfCallMinutes.rateOfChange,
                                                Math.round(this.state.totalSecondsPrev / 60),
                                                'Minutes transcribed previously'
                                            )}
                                        </Col>
                                    </Row>
                                </CardText>
                            </CardBody>
                        </Card>
                    </Col>
                    <Col md={4}>
                        <Card style={{ height: '82%' }}>
                            <CardBody>
                                <CardText className="h-100">
                                    <Row className="h-100" style={{ marginTop: 'auto', marginBottom: 'auto' }}>
                                        <Col className="center-col" md={8}>
                                            <i className="uil uil-users-alt icon-dashboard-circular"> </i>
                                            <span className="ml-2">
                                                Total Agents: <strong>{this.state.agentsCount}</strong>
                                            </span>
                                        </Col>
                                        <Col md={4} className="center-col">
                                            <i
                                                onClick={(e) => {
                                                    window.open('/manage/agents', '_self');
                                                }}
                                                style={{ float: 'right', cursor: 'pointer' }}
                                                className="uil-plus call-summary-add-agents"></i>
                                        </Col>
                                    </Row>
                                </CardText>
                            </CardBody>
                        </Card>
                    </Col>
                </Row>

                {this.state.records.length > 0 && (
                    <React.Fragment>
                        {/* <Row>
                            <Col md={2}>
                                <Input type="select" name="selectMulti" id="SelectMulti" onChange={this.handleChange}>
                                    <option value="LAST_7_DAYS">Last 7 days</option>
                                    <option value="TODAY">Today</option>
                                    <option value="YESTERDAY">Yesterday</option>
                                    <option value="LAST_15_DAYS">Last 15 days</option>
                                </Input>
                            </Col>
                        </Row> */}
                        <Row>
                            <Col className="col-12">
                                <SelectSearch
                                    teamId={this.state.selectedTeam.value}
                                    callsCount={this.state.callsCount}
                                    data={this.state.records}
                                    token={this.props.user.token}
                                />
                            </Col>
                        </Row>
                    </React.Fragment>
                )}
                {this.state.records.length == 0 && (
                    <React.Fragment>
                        <Row>
                            <Col className="col-12 text-center pt-5 mt-5">
                                <h5>No Files found.</h5>
                            </Col>
                        </Row>
                    </React.Fragment>
                )}
            </React.Fragment>
        );
    }
}
const mapStateToProps = (state) => {
    const { user, loading, error } = state.Auth;
    const { dateRange, pastDateRange } = state.Options;
    return { user, loading, error, dateRange, pastDateRange };
};
export default connect(mapStateToProps, { setDateRange, setPastDateRange })(CallSummary);
