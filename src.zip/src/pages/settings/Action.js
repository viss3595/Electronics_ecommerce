import React, {Component   } from 'react';
import { Row, Col, Button,  UncontrolledPopover, Popover, PopoverBody,UncontrolledTooltip } from 'reactstrap';

// const Action = ({ rowID, rowEdit }) => {
class Action extends Component{
    constructor(props){
        super(props);
        this.state = {      
            name: "React",      
            popoverOpen: false,   
        };
        this.togglePopover = this.togglePopover.bind(this);
        const keys =  typeof this.props.keywords === String ? this.props.keywords[0].split("\n")  : "";

    }
    togglePopover() {    
        this.setState({ popoverOpen: !this.state.popoverOpen })  
    }

    render(){
        var rowID ='';
        if( this.props.rowID ){
            rowID = this.props.rowID
        }
        const { popoverOpen } = this.state;
        const placements = [
            {
                placement: 'top',
                text: 'Top',
            },
        ];

        return(
            <table class="actionTbl">
                <tr>
                { this.props.mName == 'Feedback' && <React.Fragment>
                    <td><span id={this.props.rowIndex}><i className="uil uil-eye"></i></span></td>
                 </React.Fragment>}
               
                    <td>
                        <span onClick={ () => this.props.rowEdit(this.props.rowID) } >
                            {/* <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg> */}
                            <i className="uil uil-edit"></i>
                        </span>
                    </td>
                    { this.props.mName != 'Feedback' && <React.Fragment>
                    <td> <span id={this.props.rowIndex} > <i className="uil uil-trash-alt"></i></span> 
                        <Popover toggle={this.togglePopover} isOpen={popoverOpen}  placement='top' id={this.props.rowIndex} target={this.props.rowIndex}  >
                            <PopoverBody >
                                <Row>
                                    <Col md={12}>
                                        {/* <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                            <circle cx="12" cy="12" r="10"></circle>
                                            <line x1="12" y1="16" x2="12" y2="12"></line>
                                            <line x1="12" y1="8" x2="12.01" y2="8"></line>
                                        </svg>&nbsp; */}
                                         <span style={{ fontWeight: 'bold',fontSize:'16px' }}>
                                        { this.props.mName == 'Moment' && <React.Fragment>
                                        Are you sure to delete this moment?
                                        </React.Fragment>}
                                        { this.props.mName != 'Moment' && <React.Fragment>
                                        Are you sure to delete this agent?
                                        </React.Fragment>}
                                            
                                            </span>
                                    </Col>
                                </Row>
                                <Row style={{ float: 'right' }}>
                                    <div>
                                        <Button onClick={this.togglePopover}  className='btn btn-info btn-sm'>No</Button>&nbsp;&nbsp;
                                        <Button onClick={()=> this.props.deleteRow(this.props.rowID)} className='btn btn-danger btn-sm'>Yes</Button>
                                    </div>
                                </Row>
                            </PopoverBody>
                        </Popover>
                    </td>
                    </React.Fragment>}
                </tr>
            </table>
        );
    }
}

export default Action;