import AvField from 'availity-reactstrap-validation/lib/AvField';
import AvForm from 'availity-reactstrap-validation/lib/AvForm';
import AvGroup from 'availity-reactstrap-validation/lib/AvGroup';
import React,{Component} from 'react';
import Loader from '../../components/Loader';
import ReactPaginate from 'react-paginate';
import Select from 'react-select';
import { Modal, ModalFooter, Col, ModalBody, ModalHeader, Row, Button, Table,CustomInput } from 'reactstrap';
import Label from 'reactstrap/lib/Label';
import { getLoggedInUser } from '../../helpers/authUtils';
import { dateFormat } from '../../helpers/common';
import { serviceGet, servicePost,servicePut } from './../../helpers/api';

import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import moment from 'moment';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import { toast } from 'react-toastify';
import { ExternalLink } from 'react-feather';
import { SERVICE_URL, DEFAULT_SERVICE_VERSION } from '../../constants/utility';
class SettlementAgent extends Component
{
        constructor(props) {
        super(props);

        this.state = {
            user: getLoggedInUser(),
            modal: false,
            loading: true,
            pageLoading: false,
            settlementAgentList: [],
            currentPage:0,
            size:10,
            pageCount:1,
            searchName: '',
            status:''
        };
        this.getSettlementAgentList= this.getSettlementAgentList.bind(this);
        this.exportSettlementAgentList = this.exportSettlementAgentList.bind(this);
        this.changePage = this.changePage.bind(this);
    }
    
    componentDidMount(){     
        this.getSettlementAgentList();
    }

    exportSettlementAgentList = () => {
        serviceGet('api/v1/agent/report/export?type=settlementAgent',{
            'Content-Type': 'application/json',
           Authorization: 'Bearer ' + this.state.user.token
       })
       .then((res)=>{
             if(res){
                const link = document.createElement("a");
                link.target = "_blank";
                link.download = 'settlement_agent_report' + Date.now();
                link.href = URL.createObjectURL(
                    new Blob([res], { type: "text/csv" })
                  );
                  link.click();
            }
       }).catch((error) => {
           console.log(error);
           this.setState({
                loading: false
           })
       });
    }

    getSettlementAgentList = () =>{
        this.setState({
            settlementAgentList: [],
            loading: true
        })
        console.log(this.state.searchName);
        let url = `api/v1/agent/list?keyword=${this.state.searchName}&page=${this.state.page}&size=${this.state.size}&status=${this.state.status}
        &sortBy=${this.state.sortBy}
        &orderBy=${this.state.orderBy}`;
        if(this.state.startDate && this.state.endDate){
          url+= `&lastSettlementstartDate=${this.state.startDate}&lastSettlementendDate=${this.state.endDate}`;
        }else if(this.state.startDate && (!this.state.endDate)){
          url+= `&lastSettlementstartDate=${this.state.startDate}`;
        }else if(this.state.endDate && (!this.state.startDate)){
          url+= `&lastSettlementendDate=${this.state.endDate}`;
        }
        serviceGet(url,{
             'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
        .then((res)=>{
              if(res.data){
                this.setState({
                    settlementAgentList: res.data.responseObject,
                    pageCount: res.data.totalElements <10 ? 1 : Math.ceil(res.data.totalElements / 10),
                    loading: false
                })
             }
        }).catch((error) => {
            console.log(error);
            this.setState({
                 loading: false
            })
        });
    }

    handleChange = (event) => {
        if(event.target.name === 'startDate' || event.target.name === 'endDate'){
          let date = new Date(event.target.value);
          date.setHours(0,0,0,0);
          this.setState({
            [event.target.name]: date.toISOString()
          },()=>{
            this.setState({page :1},()=>{
                if(this.state.startDate != null && this.state.endDate != null){
                    this.getSettlementAgentList();
                }
            });
          });

        }else{
        this.setState({
            [event.target.name]: event.target.value
        });
       }
    }

    searchByName = (name) =>{
        if(!name) {
            this.setState({
                searchName: ''
            }, () => this.getSettlementAgentList())
        } else {
            let headers = {
                    'Content-Type': 'application/json',
                    Authorization: 'Bearer ' + this.state.user.token
                };
            if(name.length >= 1) {
                this.setState({
                    settlementAgentList: [],
                    searchName: name,
                    loading: true
                })
                let url = `api/v1/agent/list?name=${name}&page=${1}&size=${this.state.size}&status=${this.state.status}
                &sortBy=${this.state.sortBy}
                &orderBy=${this.state.orderBy}`;
                if(this.state.startDate && this.state.endDate){
                url+= `&lastSettlementstartDate=${this.state.startDate}&lastSettlementendDate=${this.state.endDate}`;
                }else if(this.state.startDate && (!this.state.endDate)){
                url+= `&lastSettlementstartDate=${this.state.startDate}`;
                }else if(this.state.endDate && (!this.state.startDate)){
                url+= `&lastSettlementendDate=${this.state.endDate}`;
                }
                serviceGet(url,headers)
                .then((res) => {
                    if(res.data){
                        this.setState({
                            page : 1, 
                            currentPage : 0,
                            loading: false,
                            settlementAgentList: res.data.responseObject,
                            pageCount: res.data.totalElements <10 ? 1 : Math.ceil(res.data.totalElements / 10)
                        });
                    }
                }).catch((error) => {
                    console.log(error);
                    this.setState({
                         loading: false
                    })
                });
            }
        }
    }

    changePage = ({selected})=>{
        this.setState({
            page : selected + 1,
            currentPage: selected,
            settlementAgentList: []
        },() => {this.getSettlementAgentList()});
     }

    onChangeStatus = async (selectedValue) => {
        this.setState({
            status: selectedValue.value
        }, () => {this.getSettlementAgentList()});
    }
    sortList = (sortBy,orderBy)=>{
        this.setState({
            sortBy : sortBy,
            orderBy : orderBy
        },()=>{
            this.getSettlementAgentList();
        });
    }
    getExportData = (cutomerName = null, callback) => {
        this.setState({
            searchName: cutomerName
        })
        if (cutomerName == null) { cutomerName = "" }
        let url = `api/v1/agent/report/export?name=${cutomerName}&page=${this.state.page}&size=${this.state.size}`;
        if (this.state.startDate && this.state.endDate) {
            url += `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
        } else if (this.state.startDate && (!this.state.endDate)) {
            url += `&startDate=${this.state.startDate}`;
        } else if (this.state.endDate && (!this.state.startDate)) {
            url += `&endDate=${this.state.endDate}`;
        }
        serviceGet(url, {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
            .then((res) => {
                if (res.data) {
                    console.log("DATA EX", res.data.responseObject);
                    callback(res.data.responseObject)
                    console.log(res.data.responseObject);
                }
            }).catch((error) => {
                console.log(error);
                this.setState({
                    loading: false
                })
            });
    }
    render() {
        const MyExportCSV = (props) => {
            const handleClick = () => {
                this.getExportData(this.state.searchName, (responseObject) => {
                    props.onExport(responseObject);
                });
            };
            return (
                <div>
                    <button className="btn btn-sm btn-outline-success" onClick={handleClick}>
                        <i className="uil uil-file-download-alt mr-2"></i>
                        Export to CSV
                    </button>
                </div>
            );
        };
        var baseUrl = SERVICE_URL;
        const agentColumn = [
            {
                dataField: '_id',
                text: <CustomInput type="checkbox"/>,
                formatter : (cell,row,index)=>{
                  return (<React.Fragment><CustomInput className="rowCheckbox" type="checkbox" id={row._id}/></React.Fragment>)
                },
                csvExport: false,
            },
            {
                dataField: 'agentId',
                text: 'Agent Id',
                // style: { width: '10%' },
                sort: true,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'profile_pic',
                text: 'Image',
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <img src={SERVICE_URL +"/"+ cell} className="rounded-circle"  onError={(e)=>{e.target.onerror = null; e.target.src=""+SERVICE_URL +"/default.png"}} alt="Agent_profile" width="50" height="50"/>

                    </React.Fragment>)
                }
            },
            {   
                dataField: 'name',
                text: 'Name',
                sort : true,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'invitedBy.name',
                text: 'Invited By',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            {row.invitedBy? row.invitedBy.name : '-'}
                        </React.Fragment>)
                },
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'position',
                text: 'Position',
                sort : true,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                 dataField: 'earnings',
                text: 'Earnings',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <div className="text-info">{'$ ' + cell}</div>
                        </React.Fragment>)
                },
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {  
                dataField: 'earned',
                text: 'Earned',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <div>{'$ ' + cell}</div>
                        </React.Fragment>)
                },
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {  
                dataField: 'isSettled',
                text: 'Status',
                sort : false,
                formatter : (cell, row, rowIndex) => {

                    let val = false
                    
                    if (+row.earnings - +row.earned<=0) {
                        val = true
                    } else {
                        val = false

                    }

                    return(
                        (<React.Fragment>
                          <div>{val == true ? <span className="text-success">{"settled"}</span> : <span className="text-warning">{"unsetlled"}</span>}</div>
                      </React.Fragment>)
                  )

                     
                }
            },
            {
                dataField: 'lastSettlementDate',
                text: 'Settlement Time/Date',
                sort : true,
                formatter : (cell, row, rowIndex) => {



                    
                    return (<React.Fragment>
                            <div>{row.lastSettlementDate ? moment(row.lastSettlementDate).format('MM-DD-YYYY'): '-'}</div>
                        </React.Fragment>)
                },
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            }
        ]
        return (
             <React.Fragment>
                  { this.state.pageLoading ? <Loader/> : 
            <div className="container-fluid">
                <div className="card shadow mt-4">
                    <div className="card-header page-heading pt-4 pb-3">
                        <div className="row">
                            <div className="col-md-12">
                                    <h3 className="text-dark">Settlement Agent</h3>
                            </div>
                            <div className="col-md-3 pt-3">
                                <div className="text-md-left dataTables_filter search-box-div" id="dataTable_filter">
                                    <i className="uil uil-search search-icon"></i>
                                    {/* <input type="search" id="searchByName" className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search by name" onChange={(event)=>{this.searchByName(event.target.value)}}/> */}
                                    <input type="search"  id="searchByName" value={this.state.searchName} className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search" onChange={(event)=>{
                                                this.setState({
                                                    searchName : event.target.value
                                                },()=>{
                                                    this.searchByName(this.state.searchName)
                                                })
                                            }}/>
                                </div>
                            </div>
                            <div className="col-md-2 pt-3">
                                <div className="text-md-left dataTables_filter search-box-div" id="dataTable_filter">
                                    <div class="select-status">
                                        <Select
                                            onChange={this.onChangeStatus}
                                            value={[{
                                                value:this.state.status,
                                                label:this.state.status
                                            }]}
                                            options={[
                                                { value: 'Earning', label: 'Earning' },
                                                { value: 'Settled', label: 'Settled' }
                                            ]}
                                            className="react-select"
                                            classNamePrefix="react-select"
                                            placeholder={'Select status'}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-3 pt-3">
                                        <div className="input-group">
                                            <label className="mt-2 mr-1">Start Date</label>
                                            <input type="date" id="startDate" name="startDate" className="form-control date-box" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={this.handleChange} />
                                        </div>
                                    </div>
                                    <div className="col-md-3 pt-3">
                                        <div className="input-group">
                                            <label className="mt-2 mr-1">End Date</label>
                                            <input type="date" id="endDate" name="endDate" className="form-control date-box" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={this.handleChange} />
                                        </div>
                                    </div>
                            <div className="col-md-0 mt-2 ml-4 font-size-22 pt-2">
                                <i className="uil uil-sync" onClick={(e)=>{
                                        this.setState({
                                            searchName: '',
                                            startDate: null,
                                            endDate: null,
                                            currentPage : 0,
                                            page:1
                                        }, () => {
                                            document.getElementById("startDate").value = "";
                                            document.getElementById("endDate").value = "";
                                            this.getSettlementAgentList()
                                        })
                                    }}></i>
                            </div>
                            <div className="col-md-0 mt-1 font-size-22 pt-2">
                                <i className="ml-2 mt-0 cursor-pointer" onClick={(e)=>{this.exportSettlementAgentList()}}><ExternalLink/></i>
                            </div>
                        </div>
                    </div>
                    <div className="card-body p-0">    
                    <ToolkitProvider
                        bootstrap4
                        keyField="id"
                        data={this.state.settlementAgentList}
                        columns={agentColumn}
                        exportCSV={{
                            fileName: 'SettlementAgentList_Report_' + Date.now() + '.csv',
                        }}
                        // search
                        // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                        >
                        {props => (
                            <React.Fragment>
                                <div className="grid-action-row border-top p-2 pl-4">
                                                <MyExportCSV {...props.csvProps} />
                                            </div>
                                <BootstrapTable
                                    {...props.baseProps}
                                    bordered={false}
                                    wrapperClasses="table-responsive pl-3 pr-3"
                                    noDataIndication={ this.state.loading ? <Loader/> : 'No Data Found'}
                                />
                            </React.Fragment>
                        )}
                    </ToolkitProvider>   
                    </div>
                </div>
                <div className="row">
                    <div className="text-nowrap mt-4">
                        <ReactPaginate previousLabel={"Previous"} 
                            pageCount={this.state.pageCount}
                            nextLabel={"Next"} 
                            forcePage={this.state.currentPage}
                            onPageChange={this.changePage} 
                            containerClassName={"paginationBttns"}
                            previousLinkClassName={"previousBttn"} nextLinkClassName={"nextBttn"}
                            activeLinkClassName={"paginationActive"} disabledClassName={"paginationDisabled"}>
                        </ReactPaginate>
                    </div>
                </div>
            </div>
            }
            </React.Fragment>
        )
    }
}
export default SettlementAgent;