import React,{ Component } from 'react';
import { ChevronDown } from 'react-feather';
import { Modal, ModalFooter, Col, ModalBody, ModalHeader, Row, Button, CustomInput, Collapse } from 'reactstrap';
import Label from 'reactstrap/lib/Label';
import { getLoggedInUser } from '../../helpers/authUtils';
class UserRoleDropDown extends Component {
        constructor(props) {
        super(props);

        this.state = {
            user: getLoggedInUser(),
            isCollapse: true
        };

        this.toggleCollapse = this.toggleCollapse.bind(this);
    }

    toggleCollapse = () => {
        this.setState((prevState) => ({
            isCollapse: !prevState.isCollapse
        }))
    }
    
    render() {
        return (
            <React.Fragment>   
                {/* { console.log(this.props.roles) } */}
                <Col md={12} className="mb-2 pb-1">
                    <div className="access-name-border py-2">
                        <span className="col-md-10 pl-4 access-name">{ this.props.title }</span>
                        <span className="mr-3 mt-1 float-right text-primary" onClick={this.toggleCollapse}><ChevronDown/> </span>
                    </div>
                    <Collapse isOpen={this.state.isCollapse}>
                        <div className="py-2 table-bottom">
                            <span className="pl-4 permission-status">Permission</span>
                            <span className="pl-4 float-right permission-status">Status</span>
                        </div>
                        { this.props.tabs.length > 0 ? this.props.tabs.map((tab, index) => {
                            return (
                                <div className="py-2 table-bottom">
                                    <span className="pl-4 permission-name">{ tab.name }</span>
                                    <span className="pl-4 float-right">
                                        <CustomInput 
                                            type="switch"
                                            defaultChecked={this.props.roles.indexOf(tab.value) > -1 ? true : false} 
                                            id={`${tab.value}-${tab.index}`}
                                            name={tab.value}
                                            onChange={e => {this.props.updateTab(e, tab.value)}}
                                            label=""/>
                                    </span>
                                </div>
                            )    
                            
                        }) : <span className="pl-4 permission-status">No Access Available</span> }
                    </Collapse>
                </Col>
            </React.Fragment>
        )
    }
}
export default UserRoleDropDown;