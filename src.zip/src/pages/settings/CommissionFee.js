import AvField from 'availity-reactstrap-validation/lib/AvField';
import AvForm from 'availity-reactstrap-validation/lib/AvForm';
import AvGroup from 'availity-reactstrap-validation/lib/AvGroup';
import React,{Component} from 'react';
import Loader from '../../components/Loader';
import ReactPaginate from 'react-paginate';
import Select from 'react-select';
import { Modal, ModalFooter, Col, ModalBody, ModalHeader, Row, Button, Table,CustomInput } from 'reactstrap';
import Label from 'reactstrap/lib/Label';
import { getLoggedInUser } from '../../helpers/authUtils';
import { serviceGet, servicePost,servicePut } from '../../helpers/api';

import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import moment from 'moment';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import { toast } from 'react-toastify';
import { ExternalLink } from 'react-feather'

class CommissionFee extends Component {

        constructor(props) {
        super(props);

        this.state = {
            user: getLoggedInUser(),
            // modal: false,
            loading: true,
            pageLoading: false,
            agentList: [],
            name:'',
            email: null,
            password: null,
            agentId:null,
            position:'',
            phoneNumber:0,
            countryCode: '',
            inviteBy:'',
            currentPage:0,
            size:10,
            pageCount:1,
            inviters:[],
            positions:['Agent','Trainer'],
            searchName: '',
            totalEarned:0,
            totalEarning:0,
            startDate : null,
            endDate : null
        };
        this.getAgentList= this.getAgentList.bind(this);
        this.exportCommissionFeeList = this.exportCommissionFeeList.bind(this);
        this.changePage = this.changePage.bind(this);
    }
    
    componentDidMount(){     
        this.getAgentList();
    }

    getAgentList = () =>{
        this.setState({
            agentList: [],
            loading: true
        })
        console.log(this.state.searchName);
        let url = `api/v1/agent/list?name=${this.state.searchName}&page=${this.state.page}&size=${this.state.size}
        &sortBy=${this.state.sortBy}
        &orderBy=${this.state.orderBy}`;
        if(this.state.startDate && this.state.endDate){
          url+= `&lastSettlementstartDate=${this.state.startDate}&lastSettlementendDate=${this.state.endDate}`;
        }else if(this.state.startDate && (!this.state.endDate)){
          url+= `&lastSettlementstartDate=${this.state.startDate}`;
        }else if(this.state.endDate && (!this.state.startDate)){
          url+= `&lastSettlementendDate=${this.state.endDate}`;
        }
        serviceGet(url,{
             'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
        .then((res)=>{
              if(res.data){
                this.setTotals(res.data.responseObject)                   
                this.setState({
                    agentList: res.data.responseObject,
                    pageCount: res.data.totalElements <10 ? 1 : Math.ceil(res.data.totalElements / 10),
                    loading: false
                })
             }
        }).catch((error) => {
            console.log(error);
            this.setState({
                 loading: false
            })
        });
    }
    setTotals(arr){
        let totalEarnings = 0
        let totalEarned = 0

        if(arr && arr.length>0){
            for(let i=0;i<arr.length;i++){
                let item = arr[i];
                if(item && item.earned){
                    totalEarned = totalEarned+ +item.earned
                }
                if(item && item.earnings){
                    totalEarnings = totalEarnings+ +item.earnings
                }

            }

        }
        this.setState({
            totalEarned:totalEarned,
            totalEarnings:totalEarnings
        })


    }

    exportCommissionFeeList = () => {
        serviceGet('api/v1/agent/report/export?type=commissionFee',{
            'Content-Type': 'application/json',
           Authorization: 'Bearer ' + this.state.user.token
       })
       .then((res)=>{
             if(res){
                const link = document.createElement("a");
                link.target = "_blank";
                link.download = 'commission_fee_report' + Date.now();
                link.href = URL.createObjectURL(
                    new Blob([res], { type: "text/csv" })
                  );
                  link.click();
            }
       }).catch((error) => {
           console.log(error);
           this.setState({
                loading: false
           })
       });
    }

    handleChange = (event) => {
        if(event.target.name === 'startDate' || event.target.name === 'endDate'){
          let date = new Date(event.target.value);
          date.setHours(0,0,0,0);
          this.setState({
            [event.target.name]: date.toISOString()
          },()=>{
            this.setState({page :1},()=>{
                if(this.state.startDate != null && this.state.endDate != null){
                    this.getAgentList();
                }
            });
          });
        }else{
        this.setState({
            [event.target.name]: event.target.value
        });
       }
    }

    searchByName = (name) =>{
        if(!name) {
            this.setState({
                searchName: ''
            }, () => this.getAgentList())
        } else {
            let headers = {
                    'Content-Type': 'application/json',
                    Authorization: 'Bearer ' + this.state.user.token
                };
            if(name.length > 0) {
                this.setState({
                    agentList: [],
                    searchName: name,
                    loading: true
                })
                let url = `api/v1/agent/list?name=${name}&page=${1}&size=${this.state.size}
                &sortBy=${this.state.sortBy}
                &orderBy=${this.state.orderBy}`;
                if(this.state.startDate && this.state.endDate){
                url+= `&lastSettlementstartDate=${this.state.startDate}&lastSettlementendDate=${this.state.endDate}`;
                }else if(this.state.startDate && (!this.state.endDate)){
                url+= `&lastSettlementstartDate=${this.state.startDate}`;
                }else if(this.state.endDate && (!this.state.startDate)){
                url+= `&lastSettlementendDate=${this.state.endDate}`;
                }
                serviceGet(url,headers)
                .then((res) => {
                    if(res.data){
                        this.setState({
                            page : 1, 
                            currentPage : 0,
                            loading: false,
                            agentList: res.data.responseObject,
                            pageCount: res.data.totalElements <10 ? 1 : Math.ceil(res.data.totalElements / 10)
                        });
                    }
                }).catch((error) => {
                    console.log(error);
                    this.setState({
                         loading: false
                    })
                });
            }
        }
    }

    changePage = ({selected})=>{
        this.setState({
            page : selected + 1,
            currentPage: selected,
            agentList: []
        },()=>{this.getAgentList()});
     }
     sortList = (sortBy,orderBy)=>{
        this.setState({
            sortBy : sortBy,
            orderBy : orderBy
        },()=>{
            this.getAgentList();
        });
    }
    getExportData = (cutomerName = null, callback) => {
        this.setState({
            searchName: cutomerName
        })
        if (cutomerName == null) { cutomerName = "" }
        let url = `api/v1/agent/report/export?name=${cutomerName}&page=${this.state.page}&size=${this.state.size}`;
        if (this.state.startDate && this.state.endDate) {
            url += `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
        } else if (this.state.startDate && (!this.state.endDate)) {
            url += `&startDate=${this.state.startDate}`;
        } else if (this.state.endDate && (!this.state.startDate)) {
            url += `&endDate=${this.state.endDate}`;
        }
        serviceGet(url, {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
            .then((res) => {
                if (res.data) {
                    console.log("DATA EX", res.data.responseObject);
                    callback(res.data.responseObject)
                    console.log(res.data.responseObject);
                }
            }).catch((error) => {
                console.log(error);
                this.setState({
                    loading: false
                })
            });
    }
    render() {
        const MyExportCSV = (props) => {
            const handleClick = () => {
                this.getExportData(this.state.searchName, (responseObject) => {
                    props.onExport(responseObject);
                });
            };
            return (
                <div>
                    <button className="btn btn-sm btn-outline-success" onClick={handleClick}>
                        <i className="uil uil-file-download-alt mr-2"></i>
                        Export to CSV
                    </button>
                </div>
            );
        };
        const agentColumn = [
            {
                dataField: '_id',
                text: <CustomInput type="checkbox"/>,
                formatter : (cell,row,index)=>{
                  return (<React.Fragment><CustomInput className="rowCheckbox" type="checkbox" id={row._id}/></React.Fragment>)
                }
                ,footer:'',
                csvExport: false,
            },
            {
                dataField: 'agentId',
                text: 'Agent Id',
                // style: { width: '10%' },
                sort: true,
                footer:'',
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {   
                dataField: 'name',
                text: 'Name',
                sort : true
                ,footer:'',
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'phoneNumber',
                text: 'Number',
                sort : true,
                footer:'',
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },

            {
                dataField: 'invitedBy.name',
                text: 'Invite By',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            {row.invitedBy? row.invitedBy.name : '-'}
                        </React.Fragment>)
                },
                footer:'',
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'position',
                text: 'Position',
                sort : true
                ,
                footer:"Total",
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                 dataField: 'earnings',
                text: 'Earnings',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    console.log("cell ========= >"+JSON.stringify(cell))
                    return (<React.Fragment>
                            <div className="text-info">{'$ ' + cell}</div>
                        </React.Fragment>)
                },
                footer:"$"+this.state.totalEarnings,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {  
                dataField: 'earned',
                text: 'Earned',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <div>{'$ ' + cell}</div>
                        </React.Fragment>)
                }
                ,footer:"$"+this.state.totalEarned,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }

            },
            {
                dataField: 'lastSettlementDate',
                text: 'Last Settlement Date',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                        {cell == null ? <p className="m-0">-</p>: <div>{moment(cell).format('MM-DD-YYYY')}</div>}
                           
                        </React.Fragment>)
                },
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
        ]
        return (
             <React.Fragment>
                  { this.state.pageLoading ? <Loader/> : 
            <div className="container-fluid">
                <div className="card shadow mt-4">
                    <div className="card-header page-heading pt-4 pb-3">
                        <div className="row">
                            <div className="col-md-12">
                                    <h3 className="text-dark">Commission Fee</h3>
                            </div>
                            <div className="col-md-3 pt-3">
                                <div className="text-md-left dataTables_filter search-box-div" id="dataTable_filter">
                                    <i className="uil uil-search search-icon"></i>
                                    {/* <input type="search" id="searchByName" className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search" onChange={(event)=>{this.searchByName(event.target.value)}}/> */}
                                    <input type="search"  id="searchByName" value={this.state.searchName} className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search" onChange={(event)=>{
                                                this.setState({
                                                    searchName : event.target.value
                                                },()=>{
                                                    this.searchByName(this.state.searchName)
                                                })
                                            }}/>
                                </div>
                            </div>
                            <div className="col-md-3 pt-3">
                                        <div className="input-group">
                                            <label className="mt-2 mr-1">Start Date</label>
                                            <input type="date" id="startDate" name="startDate" className="form-control date-box" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={this.handleChange} />
                                        </div>
                                    </div>
                                    <div className="col-md-3 pt-3">
                                        <div className="input-group">
                                            <label className="mt-2 mr-1">End Date</label>
                                            <input type="date" id="endDate" name="endDate" className="form-control date-box" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={this.handleChange} />
                                        </div>
                                    </div>
                            <div className="col-md-0 mt-2 ml-4 font-size-22 pt-2">
                                <i className="uil uil-sync" onClick={(e)=>{
                                    this.setState({
                                        searchName : '',
                                        startDate : null,
                                        endDate : null,
                                        currentPage : 0,
                                        page:1
                                    },()=>{
                                        document.getElementById("startDate").value = "";
                                        document.getElementById("endDate").value = "";
                                        this.getAgentList()
                                    })
                                    
                                    }}></i>
                            </div>
                            <div className="col-md-0 mt-1 font-size-22 pt-2">
                                <i className="ml-3 mt-0 cursor-pointer" onClick={(e)=>{
                                   
                                        this.exportCommissionFeeList()
                                  
                                    }}><ExternalLink/></i>
                            </div>
                        </div>
                    </div>
                    <div className="card-body p-0">    
                    <ToolkitProvider
                        bootstrap4
                        keyField="id"
                        data={this.state.agentList}
                        columns={agentColumn}
                        exportCSV={{
                            fileName: 'CommissionFee_Report_' + Date.now() + '.csv',
                        }}
                        // search
                        // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                        >
                        {props => (
                            <React.Fragment>
                                <div className="grid-action-row border-top p-2 pl-4">
                                                <MyExportCSV {...props.csvProps} />
                                            </div>
                                <BootstrapTable
                                    {...props.baseProps}
                                    bordered={false}
                                    wrapperClasses="table-responsive pl-3 pr-3"
                                    noDataIndication={ this.state.loading ? <Loader/> : 'No Data Found'}
                                />
                            </React.Fragment>
                        )}
                    </ToolkitProvider>   
                    </div>
                </div>
                <div className="row">
                    <div className="text-nowrap mt-4">
                    {/* <div id="dataTable_length" className="dataTables_length" aria-controls="dataTable"><label>Show&nbsp;<select className="form-control form-control-sm custom-select custom-select-sm"><option value="10" selected="">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select>&nbsp;</label></div> */}
                        <ReactPaginate previousLabel={"Previous"} 
                            pageCount={this.state.pageCount}
                            nextLabel={"Next"} 
                            forcePage={this.state.currentPage}
                            onPageChange={this.changePage} 
                            containerClassName={"paginationBttns"}
                            previousLinkClassName={"previousBttn"} nextLinkClassName={"nextBttn"}
                            activeLinkClassName={"paginationActive"} disabledClassName={"paginationDisabled"}>
                        </ReactPaginate>
                    </div>
                </div>
                {/* <Modal
                    isOpen={this.state.modal}
                    toggle={this.toggle}
                    className={this.state.className}
                    size='lg'>
                        <div><ModalHeader toggle={this.toggle}>{this.state.modalType === 'editAgent'? 'Update Agent Information' : 'Create Agent Information'}</ModalHeader>
                         <AvForm onValidSubmit={this.createAgent}>
                            <ModalBody>
                                <Row>
                                    <Col md={6}>
                                        <label>Agent Name</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="name" type="text" required placeholder="Enter Agent Name" autoComplete="false" value={this.state.name} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6}>
                                        <label>Email</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="email" type="email" required placeholder="Email" autoComplete="false" value={this.state.email} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                        <Col md={6}>
                                    <label>Password</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                       <span className="password-position">
                                          <AvField name="password" type="password" required={this.state.modalType !== 'editAgent'} placeholder="Enter Password" autoComplete="false" value={this.state.password} onChange={this.handleChange}
                                             validate = {{required: {value: true}}} disabled = {this.state.modalType === 'editAgent'}/>
                                        </span>
                                        {this.state.modalType === 'editAgent'?<div className="mb-2 text-primary"><i className="uil uil-info-circle info-icon"></i><small>If filled,then existing password will be updated else leave blank</small></div>:''}
                                    </Col>
                                    <Col md={6}>
                                        <AvGroup row>
                                            <Col sm={12}>
                                                <Label for="example">Position</Label><span className="text-danger pt-2"><sup>*</sup></span>
                                                <Select
                                                   onChange={this.onChangePosition}
                                                    value={[{
                                                         value:this.state.position,
                                                         label:this.state.position
                                                    }]}
                                                   // isMulti={true}
                                                   options={[
                                                     { value: 'Agent', label: 'Agent' },
                                                     { value: 'Trainer', label: 'Trainer' }
                                                   ]}
                                                   className="react-select"
                                                   classNamePrefix="react-select"
                                                   placeholder={'Select a position'}
                                                 />
                                          </Col>
                                         </AvGroup>
                                    </Col>
                                    <Col md={6}>
                                        <label>Phone Number</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="phoneNumber" type="text" required placeholder="Enter Phone Number" autoComplete="false" value={this.state.phoneNumber} onChange={this.handleChange}
                                                                validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6}>
                                        <AvGroup row>
                                            <Col sm={12}>
                                                <Label for="example">Invite By</Label><span className="text-danger pt-2"><sup>*</sup></span>
                                                <Select
                                                  onInputChange={(value) => this.getInviters(value)}
                                                  onChange={this.onChangeInviter}
                                                  value={[{'value':this.state.inviteBy?.value,'label':this.state.inviteBy?.label}]}
                                                   // isMulti={true}
                                                   options={this.state.inviters}
                                                   className="react-select"
                                                   classNamePrefix="react-select"
                                                   placeholder={'Search inviter'}
                                                 />
                                          </Col>
                                         </AvGroup>
                                    </Col>
                                    <Col md={6}>
                                        <label>Country Code</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="countryCode" type="text" required placeholder="Enter Country Code" autoComplete="false" value={this.state.countryCode} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                </Row>
                            </ModalBody>
                            <ModalFooter>
                                <button className="btn btn-outline-primary btn-lg">{this.state.modalType === 'editAgent'? 'Update' : 'Create'}</button>
                                <button className="btn btn-outline-danger btn-lg" onClick={this.toggle}>Cancel</button>
                            </ModalFooter>
                          </AvForm> 
                       </div>
                </Modal> */}
            </div>
            }
            </React.Fragment>
        )
    }
}
export default CommissionFee;