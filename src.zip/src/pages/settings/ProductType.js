import AvField from 'availity-reactstrap-validation/lib/AvField';
import AvForm from 'availity-reactstrap-validation/lib/AvForm';
import React,{Component} from 'react';
import Loader from '../../components/Loader';
import ReactPaginate from 'react-paginate';
import { Modal, ModalFooter, Col, ModalBody, ModalHeader, Row, Button, Table,CustomInput } from 'reactstrap';
import { getLoggedInUser } from '../../helpers/authUtils';
import { serviceGet, servicePost,servicePut } from './../../helpers/api';

import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import { toast } from 'react-toastify';
class ProductType extends Component
{
        constructor(props) {
        super(props);

        this.state = {
            user: getLoggedInUser(),
            modal: false,
            loading: true,
            pageLoading: false,
            productList: [],
            name:'',
            productId: null,
            currentPage: 1,
            size: 3,
            pageCount:1,
            typeName: null,
            price: null,
            commissionBase: null,
            description: null
        };
        this.toggle = this.toggle.bind(this);
        this.getProductList= this.getProductList.bind(this);
        this.createProduct= this.createProduct.bind(this);
        this.changePage = this.changePage.bind(this);
        this.switchProduct = this.switchProduct.bind(this);
    }
    
    componentDidMount() {     
        this.getProductList();
    }

    getProductList = () => {
        this.setState({
            productList: [],
            loading: true
        })
        console.log(this.state.searchName);
        let url = `api/v1/product/search?page=${this.state.currentPage}&size=${this.state.size}`;
        serviceGet(url,{
             'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
        .then((res) => {
              if(res.data) {
                this.setState({
                    productList: res.data.responseObject,
                    pageCount: res.data.totalElements < 3 ? 1 : Math.ceil(res.data.totalElements / 3),
                    loading: false
                })
             }
        }).catch((error) => {
            console.log(error);
            this.setState({
                 loading: false
            })
        });
    }

    switchProduct = (product) => {
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };

        this.setState({
            loading: true
        })

        if(product._id) {
            servicePut(
                    `api/v1/product/${product._id}/switch?isEnabled=${!product.isEnabled}`, '', headers)
            .then((res) => {
                if(res.data) {
                    this.setState({
                        loading: false,
                    }, () => this.getProductList());
                    toast('Product updated successfully', {bodyClassName: 'success-toast'});
                } else {
                    toast(res.error, {bodyClassName: 'error-toast'});
                }
            })
            .catch((err) => {
                console.log(err)
                this.setState({
                    loading: false
                })
                toast('Some error occurred', {bodyClassName: 'error-toast'});
            })
        }
    }


    createProduct = () => {
        if(this.state.typeName === null || this.state.commissionBase === undefined ||
             this.state.description === "" || this.state.price === null) {
            toast('Please fill all the fields.', {bodyClassName: 'error-toast'});
            return;
        }

        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        let product = {
            'typeName': this.state.typeName,
            'price': this.state.price,
            'commissionBase': this.state.commissionBase, 
            "description": this.state.description,
        }
        this.setState({
            pageLoading: true
        })

        if(this.state.productId) {
            servicePut(
                    `api/v1/product/${this.state.productId}`,
                    JSON.stringify(product), headers)
            .then((res) => {
                if(res.data) {
                    this.setState({
                        typeName: null,
                        price: null,
                        commissionBase: null,
                        description: null,
                        pageLoading: false,
                        productId: null
                    }, () => this.getProductList());
                    toast('Product updated successfully', {bodyClassName: 'success-toast'});
                } else {
                    toast(res.error, {bodyClassName: 'error-toast'});
                }
            })
            .catch((err) => {
                console.log(err)
                this.setState({
                    pageLoading: false
                })
                toast('Some error occurred', {bodyClassName: 'error-toast'});
            })
        } else {
            servicePost('api/v1/product',JSON.stringify(product),headers)
            .then((res) => {
                if(res.data) {
                        this.setState({
                            typeName: null,
                            price: null,
                            commissionBase: null,
                            description: null,
                            pageLoading: false
                        }, () => this.getProductList());
                    toast('Product created successfully',{bodyClassName:'success-toast'});
                } else {
                    toast(res.error, {bodyClassName: 'error-toast'});
                }
            })
            .catch((err) => {
                console.log(err)
                this.setState({
                    pageLoading: false
                })
                toast('Some error occurred', {bodyClassName: 'error-toast'});
            })
        }
    }

    toggle = (modal, product) => {
        if(product != null) {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                productId: product._id,
                typeName: product.typeName,
                price: product.price,
                commissionBase: product.commissionBase,
                description: product.description,
            }))
        } else {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                productId: null,
                typeName: null,
                price: null,
                commissionBase: null,
                description: null,
            }))
        }
    };


    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });
    }

    changePage = ({selected})=>{
        this.setState({
            currentPage: selected + 1,
            productList: []
        }, () => { this.getProductList() });
     }
    
    render() {
        const productColumn = [
            // {
            //     dataField: '_id',
            //     text: <CustomInput type="checkbox"/>,
            //     formatter : (cell,row,index)=>{
            //       return (<React.Fragment><CustomInput className="rowCheckbox" type="checkbox" id={row._id}/></React.Fragment>)
            //     }
            // },
            {
                dataField: 'productId',
                text: 'No',
                // sort: true,
            },
            {   
                dataField: 'typeName',
                text: 'Type Name',
                // sort : true
            },
            {   
                dataField: 'price',
                text: 'Price',
                // sort : true
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <div>{'$ ' + cell}</div>
                        </React.Fragment>)
                }
            },
            {   
                dataField: 'commissionBase',
                text: 'Commission Base',  
                // sort : true
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <div>{cell + '%'}</div>
                        </React.Fragment>)
                }
            },
            {   
                dataField: 'description',
                text: 'Description',
                // sort : true
            },
            {   
                dataField: 'isEnabled',
                text: 'Action',
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <Row>
                                <Col md={3} className="p-0 m-0">
                                    <span className="transparent-toggle-button">
                                        <CustomInput 
                                            type="switch"
                                            defaultChecked={cell} 
                                            id={rowIndex}
                                            // name={tab.value}
                                            onChange={e => {this.switchProduct(row)}}
                                            label=""/>
                                    </span>
                                </Col>
                                <Col md={3} className="p-0 m-0">
                                    <span className="text-success pl-1"><i className="uil uil-edit" onClick={(e) => {this.toggle('editProduct',row);}}></i></span>
                                </Col>
                            </Row>
                        </React.Fragment>)
                }
            },
        ]
        return (
             <React.Fragment>{ this.state.pageLoading ? <Loader/> : <>
                <div className="container-fluid">
                    <div className="card mt-4">
                        <div className="card-header page-heading pt-4 pb-3">
                            <AvForm onValidSubmit={this.createProduct}>
                                <Row>
                                    <Col md={12}>
                                            <h3 className="text-dark">ProductType</h3>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Type Name</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="typeName" type="text" required placeholder="Enter Type Name" autoComplete="false" value={this.state.typeName} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Price</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="price" type="text" required placeholder="Enter Price" autoComplete="false" value={this.state.price} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Commission Base</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="commissionBase" type="number" required placeholder="Enter Commission Base" autoComplete="false" value={this.state.commissionBase} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Description</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="description" type="text" required placeholder="Enter Description" autoComplete="false" value={this.state.description} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={12} className="align-center my-3">
                                        <button className="btn btn-outline-primary btn-lg px-5">{this.state.productId != null ? 'UPDATE' : 'ADD'}</button>
                                    </Col>
                                </Row>
                            </AvForm>
                        </div>
                    </div>
                </div>
            <div className="container-fluid">
                <div className="card shadow mt-4">
                    <div className="card-header page-heading pt-4 pb-3">
                        <div className="row">
                            <div className="col-md-12">
                                    <h3 className="text-dark">List of ProductType</h3>
                            </div>
                        </div>
                    </div>
                    <div className="card-body p-0">    
                    <ToolkitProvider
                        bootstrap4
                        keyField="id"
                        data={this.state.productList}
                        columns={productColumn}
                        // search
                        // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                        >
                        {props => (
                            <React.Fragment>
                                <BootstrapTable
                                    {...props.baseProps}
                                    bordered={false}
                                    wrapperClasses="table-responsive pl-3 pr-3"
                                    noDataIndication={ this.state.loading ? <Loader/> : 'No Data Found'}
                                />
                            </React.Fragment>
                        )}
                    </ToolkitProvider>   
                    </div>
                </div>
                <div className="row">
                    <div className="text-nowrap mt-4">
                        <ReactPaginate previousLabel={"Previous"} 
                            pageCount={this.state.pageCount}
                            nextLabel={"Next"} 
                            onPageChange={this.changePage} 
                            containerClassName={"paginationBttns"}
                            previousLinkClassName={"previousBttn"} nextLinkClassName={"nextBttn"}
                            activeLinkClassName={"paginationActive"} disabledClassName={"paginationDisabled"}>
                        </ReactPaginate>
                    </div>
                </div>
                {/* <Modal
                    isOpen={this.state.modal}
                    toggle={this.toggle}
                    className={this.state.className}
                    size='lg'>
                        <div><ModalHeader toggle={this.toggle}>Update Affiliate Information</ModalHeader>
                         <AvForm onValidSubmit={this.createProduct}>
                            <ModalBody>
                                <Row>
                                    <Col md={6} className="mt-3">
                                        <label>Commission Fee (Personnage %)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="typeName" type="text" required placeholder="Enter Commission Fee" autoComplete="false" value={this.state.typeName} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Trainer commission fee (Personnage %)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="price" type="text" required placeholder="Enter Trainer Commission Fee" autoComplete="false" value={this.state.price} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Up line fee (Personage %)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="commissionBase" type="text" required placeholder="Enter UpLine Fee" autoComplete="false" value={this.state.commissionBase} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Expansion level (N-1)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="description" type="text" required placeholder="Enter Level" autoComplete="false" value={this.state.description} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                </Row>
                            </ModalBody>
                            <ModalFooter>
                                <button className="btn btn-outline-primary btn-lg">Update</button>
                                <button className="btn btn-outline-danger btn-lg" onClick={this.toggle}>Cancel</button>
                            </ModalFooter>
                          </AvForm> 
                       </div>
                </Modal> */}
            </div> </>
            }
            </React.Fragment>
        )
    }
}
export default ProductType;