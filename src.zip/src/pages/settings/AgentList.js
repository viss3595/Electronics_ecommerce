import React, { Component } from 'react';
import {
    Row,
    Col,
    Card,
    CardBody,
    Input,
    Button,
    Modal,
    ModalHeader,
    UncontrolledTooltip,
    ModalBody,
    ModalFooter,
    Progress,
} from 'reactstrap';
import BootstrapTable from 'react-bootstrap-table-next';
import ToolkitProvider, { Search } from 'react-bootstrap-table2-toolkit';
import paginationFactory from 'react-bootstrap-table2-paginator';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import { servicePost } from './../../helpers/api';

import { connect } from 'react-redux';

import PageTitle from '../../components/PageTitle';
import AddModal from './AddModal';
import { dateFormat, capitalize, secondToMinutes } from './../../helpers/common';
import TableAction from './tableAction';

/** IMPORT FORM */
import AddAgent from '../forms/settings/AddAgent';
import AddTeam from '../forms/settings/AddTeam';
// import { Loader } from 'react-feather';
import Loader from '../../components/Loader';

const sizePerPageRenderer = ({ options, currSizePerPage, onSizePerPageChange }) => (
    <React.Fragment>
        <label className="d-inline mr-1">Show</label>
        <Input
            type="select"
            name="select"
            id="no-entries"
            className="custom-select custom-select-sm d-inline col-2"
            defaultValue={currSizePerPage}
            onChange={(e) => onSizePerPageChange(e.target.value)}>
            {options.map((option, idx) => {
                return <option key={idx}>{option.text}</option>;
            })}
        </Input>
        <label className="d-inline ml-1">entries</label>
    </React.Fragment>
);

const TableWithSearch = (props) => {
    const { user } = props;
    console.log(user);
    const { SearchBar } = Search;
    const records = props.data;
    var _editAgent = false;
    if (props.agentData) {
        _editAgent = true;
    }

    const columns = [
        {
            dataField: '_id',
            text: 'S No.',
            sort: false,
            formatter: (cell, row, index) => <React.Fragment>{index + 1}</React.Fragment>,
        },
        {
            dataField: 'name',
            text: 'Name',
            sort: true,
        },
        {
            dataField: 'displayRole',
            text: 'Role',
            sort: true,
        },
        {
            dataField: 'email',
            text: 'Email',
            sort: true,
        },
        {
            dataField: 'team',
            text: 'Assigned Team',
            sort: true,
            // formatter: (cell, row,index) => (
            //     <React.Fragment>
            //         {
            //             row[index].teamName
            //         }
            //     </React.Fragment>
            // ),
        },
        {
            dataField: 'createdAt',
            text: 'Added on',
            sort: true,
        },
        {
            dataField: 'remainingMinutes',
            text: 'Call mins used',
            sort: true,
            formatter: (cell, row, index) => (
                <React.Fragment>
                    {cell.barValue >= 0 && (
                        <React.Fragment>
                            <div id={`tag-${index}`}>
                                <Progress color="info" value={cell.barValue} className="mb-2" />
                                <UncontrolledTooltip placement="top" target={`tag-${index}`}>
                                    {cell.leftMin}
                                </UncontrolledTooltip>
                            </div>
                        </React.Fragment>
                    )}
                </React.Fragment>
            ),
            headerFormatter: (column, colIndex) => {
                return (
                    <div>
                        <div class="text-center">{column.text}</div>
                    </div>
                );
            },
        },

        {
            dataField: 'createdAt',
            text: 'Team',
            sort: false,
            style: { display: 'none' },
            headerStyle: { display: 'none' },
        },

        {
            dataField: 'updatedAt',
            text: 'sort',
            sort: false,
            style: { display: 'none' },
            headerStyle: { display: 'none' },
        },
        {
            dataField: 'actions',
            text: 'Actions',
            sort: false,
        },
    ];

    const isModal = () => {
        props.newdata();
    };
    if (props.isData == false) {
        return (
            <Card>
                <CardBody>
                    <Row>
                        <Col md={12} style={{ textAlign: 'center' }}>
                            <div>
                                <AddModal
                                    btnStyle={'center'}
                                    editData={props.agentData}
                                    isEdit={_editAgent}
                                    modalView={isModal.bind(this)}
                                    buttonName={'Create Agent'}
                                    modalType={'agent'}
                                    modalTitle={'Create a new Agent'}
                                    isFooter={'false'}
                                />
                            </div>
                        </Col>
                    </Row>
                </CardBody>
            </Card>
        );
    }
    if (props.isData) {
        var noOfAgents = props.data.length;
        return (
            <Card>
                <div className="rem-agents">
                    {user && user.userAgentsLimit && user.userAgentsLimit == noOfAgents
                        ? `Maximum agents are already added (${noOfAgents})`
                        : `You can add maximum number of ${
                              user && user.userAgentsLimit && user.userAgentsLimit
                          } agents`}
                </div>
                <CardBody>
                    <ToolkitProvider
                        bootstrap4
                        keyField="id"
                        data={records}
                        columns={columns}
                        search
                        exportCSV={{ onlyExportFiltered: true, exportAll: false }}>
                        {(props) => (
                            <React.Fragment>
                                <Row>
                                    <Col>
                                        <SearchBar {...props.searchProps} />
                                    </Col>
                                    <Col style={{ float: 'right' }}>
                                        <AddModal
                                            btnStyle={'right'}
                                            editData={props.agentData}
                                            isEdit={_editAgent}
                                            modalView={isModal.bind(this)}
                                            buttonName={'Create Agent'}
                                            modalType={'agent'}
                                            modalTitle={'Create a new Agent'}
                                            isFooter={'false'}
                                            typeForm="edit"
                                        />
                                    </Col>
                                </Row>
                                <BootstrapTable
                                    {...props.baseProps}
                                    bordered={false}
                                    pagination={paginationFactory({
                                        sizePerPage: 10,
                                        sizePerPageRenderer: sizePerPageRenderer,
                                        sizePerPageList: [
                                            { text: '5', value: 5 },
                                            { text: '10', value: 10 },
                                            { text: '25', value: 25 },
                                        ],
                                    })}
                                    wrapperClasses="table-responsive"
                                />
                            </React.Fragment>
                        )}
                    </ToolkitProvider>
                </CardBody>
            </Card>
        );
    }
};

class Tables extends Component {
    constructor(props) {
        super(props);
        this.state = {
            modal: false,
            records: [],
            agentIDdata: '',
            modal: false,
            modalType: '',
            modalTitle: '',
            isFooter: false,
            isDataAvailable: false,
            loading: true,
            formType: 'edit',
        };
        this.editDataRow.bind(this);
        this.toggle = this.toggle.bind(this);
        this.openModalWithSize = this.openModalWithSize.bind(this);
        this.openModalWithClass = this.openModalWithClass.bind(this);
        this.headers = {
            'Content-Type': 'application/json',
            Authorization: 'JWT ' + this.props.user.token,
        };
    }

    newView = () => {
        this.getAllAgents();
    };

    toggle = () => {
        this.setState((prevState) => ({
            modal: !prevState.modal,
        }));
    };

    /**
     * Opens large modal
     */
    openModalWithSize = (size) => {
        this.setState({ size: size, className: null });
        this.toggle();
    };

    /**
     * Opens modal with custom class
     */
    openModalWithClass = (className) => {
        this.setState({ className: className, size: null });
        this.toggle();
    };

    getAllAgents = () => {
        servicePost('agent/getAgents', { addBy: this.props.user._id }, this.headers)
            .then((res) => {
                // if(res.status ==1){
                for (let index = 0; index < res.data.length; index++) {
                    var element = res.data[index];

                    res.data[index].addedOn = element.createdAt;
                    res.data[index].createdAt = dateFormat(element.createdAt);
                    res.data[index].name = capitalize(element.name);
                    res.data[index].role = capitalize(element.role);
                    // res.data[index].team = (element.team.length != 0)? element.team[0].teamName : 'hello';
                    res.data[index].team =
                        element.team.length != 0 ? (
                            capitalize(element.team[0].teamName)
                        ) : (
                            <React.Fragment>
                                <a
                                    href="javascript:void(0)"
                                    onClick={this.editDataRow.bind(this, { agentId: element._id, type: 'teamUpdate' })}>
                                    {' '}
                                    <i className="uil uil-plus-circle"></i>{' '}
                                </a>
                            </React.Fragment>
                        );

                    // ACTION KEY
                    // element.actions = <AgentAction
                    //     mName={'Agent'}
                    //     rowIndex={'btn-'+index}
                    //     deleteRow={this.deleteTableRow.bind(this)}
                    //     rowID={element._id}
                    //     rowEdit={this.editDataRow.bind(this,{ agentId: element._id, type: 'editUpdate'})}
                    //     />
                    element.remainingMinutes = {
                        barValue:
                            element.remainingSeconds == element.totalSeconds
                                ? 0
                                : !isNaN(
                                      Number(
                                          (secondToMinutes(element.totalSeconds) -
                                              secondToMinutes(element.remainingSeconds)) /
                                              secondToMinutes(element.totalSeconds)
                                      ) * 100
                                  )
                                ? (
                                      Number(
                                          (secondToMinutes(element.totalSeconds) -
                                              secondToMinutes(element.remainingSeconds)) /
                                              secondToMinutes(element.totalSeconds)
                                      ) * 100
                                  ).toFixed(0)
                                : 0,
                        leftMin: `${
                            secondToMinutes(element.totalSeconds) - secondToMinutes(element.remainingSeconds)
                        } of ${secondToMinutes(element.totalSeconds)} minutes used`,
                        remainingSeconds: element.remainingSeconds,
                    };
                    console.log('element.remainingMinutes', element.remainingMinutes);
                    element.actions = (
                        <TableAction
                            rowIndex={'btn-' + index}
                            actionType={'agent'}
                            rowID={element._id}
                            reload={this.newView}
                            rowEdit={this.editDataRow.bind(this)}
                            countLength={element.assignedAgent}
                            // deleteMesg={`This team is assigned to ${(ele.assignedAgent !=null )?ele.assignedAgent.length:['']} agents. You would need to assign them a new team from “Manage Agents” section.`}
                            // deleteRow={this.deleteTableRow.bind(this)}
                        />
                    );
                }
                if (res.data.length > 0) {
                    this.setState({
                        records: res.data,
                        isDataAvailable: true,
                        loading: false,
                    });
                }
                if (res.data.length == 0) {
                    this.setState({
                        records: [],
                        isDataAvailable: false,
                        loading: false,
                    });
                }
                // }
            })
            .catch((err) => {
                console.log(err);
            });
    };

    editDataRow = (rowID) => {
        try {
            servicePost('agent/getAgentByID', { id: rowID.agentId }, this.headers)
                .then((res) => {
                    this.toggle();
                    console.log('rowID==>', res.data);
                    this.setState({
                        agentIDdata: res.data,
                        modal: true,
                        modalType: 'agent',
                        modalTitle: 'Edit information for ' + res.data.name,
                        isFooter: false,
                        buttonName: 'Update Agent',
                        formType: rowID.type == 'teamUpdate' ? 'team' : 'edit',
                    });
                })
                .catch((err) => {
                    console.log(err);
                });
        } catch (err) {
            console.log(err);
        }
    };

    componentDidMount() {
        this._isMounted = true;
        try {
            this.getAllAgents();
        } catch (err) {
            console.log(err);
        }
    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    reloadData = () => {
        // alert('im here')
        this.getAllAgents();
    };

    render() {
        if (this.state.loading) {
            return (
                <React.Fragment>
                    <Row>
                        <Col md={12} className="page-title mt-2">
                            <Loader />
                        </Col>
                    </Row>
                </React.Fragment>
            );
        }
        return (
            <React.Fragment>
                <Row className="page-title">
                    <Col md={12}>
                        <PageTitle
                            breadCrumbItems={[
                                { label: 'Settings', path: '/setting/agents' },
                                { label: 'Agents', path: '/setting/agents', active: true },
                            ]}
                            title={'Agent Manager'}
                        />
                        <div className="subtitle-heading">
                            Add, remove and manage calling agents from this screen. <br />
                            Call for agents that appear in this table gets transcribed and analyzed..
                        </div>
                    </Col>
                </Row>

                <Row>
                    <Col className="col-12">
                        <TableWithSearch
                            user={this.props.user}
                            isData={this.state.isDataAvailable}
                            agentData={this.state.agentIDdata}
                            newdata={this.newView.bind(this)}
                            data={this.state.records}
                        />
                    </Col>
                </Row>
                <Modal
                    isOpen={this.state.modal}
                    toggle={this.toggle}
                    className={this.state.className}
                    size={this.state.size}>
                    <ModalHeader toggle={this.toggle}>{this.state.modalTitle}</ModalHeader>
                    <ModalBody>
                        {this.state.className && this.state.className === 'modal-dialog-scrollable' && (
                            <React.Fragment></React.Fragment>
                        )}
                        {this.state.modalType == 'team' && (
                            <React.Fragment>
                                <AddTeam />
                            </React.Fragment>
                        )}
                        {this.state.modalType == 'agent' && (
                            <React.Fragment>
                                <AddAgent
                                    typeForm={this.state.formType}
                                    toggle={this.toggle}
                                    view={this.reloadData.bind(this)}
                                    toggle={this.toggle}
                                    data={this.state.agentIDdata}
                                    bName={this.state.buttonName}
                                />
                            </React.Fragment>
                        )}
                    </ModalBody>
                </Modal>
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    // const { user, loading, error } = state.Auth;
    return state.Auth;
};
export default connect(mapStateToProps)(Tables);
