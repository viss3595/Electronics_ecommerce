import { SERVICE_URL, DEFAULT_SERVICE_VERSION } from '../../constants/utility';
import React, { Component, useCallback } from 'react';
import { AvForm, AvField, AvGroup, AvInput, Label, AvFeedback, AvRadioGroup, AvRadio, AvCheckboxGroup, AvCheckbox } from 'availity-reactstrap-validation';
import Loader from '../../components/Loader';
import ReactPaginate from 'react-paginate';
import Select from 'react-select';
import FileUpload from '../forms/FileUpload';

import {
    Row,
    Col,
    Card,
    CardBody,
    Input,
    Button,
    Modal,
    ModalHeader,
    UncontrolledTooltip,
    ModalBody,
    ModalFooter,
    Progress,
    CustomInput
} from 'reactstrap';
import { getLoggedInUser } from '../../helpers/authUtils';
import { serviceGet, servicePost, servicePut } from './../../helpers/api';

import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import moment from 'moment';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import { ExternalLink, Send } from 'react-feather';
import { Link } from 'react-router-dom';
import AddNotification from './AddNotification';
import Dropzone from 'react-dropzone';
import { toast } from 'react-toastify';
import ReactPlayer from 'react-player';
const Swal = require('sweetalert2')
const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })
class Notification extends Component {
    constructor(props) {
        super(props);

        this.state = {
            user: getLoggedInUser(),
            modal: false,
            loading: true,
            pageLoading: false,
            notificationList: [],
            currentPage: 0,
            size: 10,
            pageCount: 1,
            searchName: '',
            status: '',
            setFileNames: [],
            fileNames: [],
            ImagePreview: null,
            notificationType: 'text'
        };

        this.toggle = this.toggle.bind(this);
        this.createNotification = this.createNotification.bind(this);
        this.getNotificationList = this.getNotificationList.bind(this);
        this.changePage = this.changePage.bind(this);
        this.sortList = this.sortList.bind(this);
    }
    createNotification = () => {
        debugger;
        if (this.state.title === null || this.state.description === undefined) {
            toast('Please fill all the fields.', { bodyClassName: 'error-toast' });
            return;
        }
        let headers = {
            'Content-Type': 'multipart/form-data',
            Authorization: 'Bearer ' + this.state.user.token
        };

        const data = new FormData()
        if (this.state.setFileNames.length > 0) {
            data.append('file', this.state.setFileNames[0]);
        }
        data.set("title", this.state.title);
        data.set("description", this.state.description);
        data.set("notificationType", this.state.notificationType);
        data.set("status", true);

        if (this.state.modalType === 'editNotification') {
            servicePut(`api/v1/notification/` + this.state.notificationId,
                data,
                headers)
                .then((res) => {
                    if (res.data) {
                        this.toggle();
                        this.getNotificationList()
                        toast('notification updated successfully', { bodyClassName: 'success-toast' });
                    } else {
                        toast(res.error, { bodyClassName: 'error-toast' });
                    }
                })
                .catch((err) => {
                    console.log(err)
                    toast('Some error occurred', { bodyClassName: 'error-toast' });
                })
        } else {
            servicePost(`api/v1/notification/`,
                data,
                headers)
                .then((res) => {
                    if (res.data) {
                        this.toggle();
                        this.getNotificationList()
                        toast('notification updated successfully', { bodyClassName: 'success-toast' });
                    } else {
                        toast(res.error, { bodyClassName: 'error-toast' });
                    }
                })
                .catch((err) => {
                    console.log(err)
                    toast('Some error occurred', { bodyClassName: 'error-toast' });
                })
        }



    }

    toggle = (modal, notification) => {

        if (notification != null) {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                notificationId: notification._id,
                title: notification.title,
                description: notification.description,
                notificationType: notification.notificationType,
                media: notification.media,
                mediaThumb: notification.mediaThumb,
                status: notification.status,
                setFileNames: [],
                fileNames: [],
                ImagePreview: null
            }))
        } else {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                notificationId: '',
                title: '',
                description: '',
                notificationType: '',
                media: '',
                status: true,
                setFileNames: [],
                fileNames: [],
                ImagePreview: null
            }))
        }
    };
    playerToggle = (modal,row)=>{
        if (modal === "video") {
            this.setState((prevState) => ({
                isOpenPlayerModal: !prevState.isOpenPlayerModal,
                isOpenPlayerModalType: modal,
                selectedMediaRow : row
            }))
        }else{
            this.setState((prevState) => ({
                isOpenPlayerModal: !prevState.isOpenPlayerModal,
                isOpenPlayerModalType: null,
                selectedMediaRow : null
            }))
        }
    }
    componentDidMount() {
        this.getNotificationList();
    }

    getNotificationList = () => {
        this.setState({
            notificationList: [],
            loading: true
        })
        console.log(this.state.searchName);
        let url = `api/v1/notification/list?keyword=${this.state.searchName}&page=${this.state.page}&size=${this.state.size}&status=${this.state.status}
        &sortBy=${this.state.sortBy}
        &orderBy=${this.state.orderBy}`;
        if (this.state.startDate && this.state.endDate) {
            url += `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
        } else if (this.state.startDate && (!this.state.endDate)) {
            url += `&startDate=${this.state.startDate}`;
        } else if (this.state.endDate && (!this.state.startDate)) {
            url += `&endDate=${this.state.endDate}`;
        }
        serviceGet(url, {
            Authorization: 'Bearer ' + this.state.user.token
        })
            .then((res) => {
                if (res.data) {
                    this.setState({
                        notificationList: res.data.responseObject,
                        pageCount: res.data.totalElements < 10 ? 1 : Math.ceil(res.data.totalElements / 10),
                        loading: false
                    })
                }
            }).catch((error) => {
                console.log(error);
                this.setState({
                    loading: false
                })
            });
    }

    handleChange = (event) => {

        if (event.target && event.target.name) {
            if (event.target.name === 'startDate' || event.target.name === 'endDate') {
                let date = new Date(event.target.value);
                date.setHours(0, 0, 0, 0);
                if (event.target.name === 'endDate') {
                    date.setDate(date.getDate() + 1);
                }
                this.setState({
                    [event.target.name]: date.toISOString()
                }, () => {
                    if (this.state.startDate != null && this.state.endDate != null) {
                        this.searchByName(this.state.searchName);
                    }
                });
            } else {
                if (event.target != null && event.target.name != null) {
                    this.setState({
                        [event.target.name]: event.target.value
                    });
                }
            }

        }
    }

    searchByName = (name) => {
        if (!name) {
            this.setState({
                searchName: ''
            }, () => this.getNotificationList())
        } else {
            let headers = {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.state.user.token
            };
            if (name.length >= 0) {
                this.setState({
                    notificationList: [],
                    searchName: name,
                    loading: true
                })
                let url = `api/v1/notification/list?keyword=${name}&page=${1}&size=${this.state.size}&status=${this.state.status}
                &sortBy=${this.state.sortBy}
                &orderBy=${this.state.orderBy}`;
                if (this.state.startDate && this.state.endDate) {
                    url += `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
                } else if (this.state.startDate && (!this.state.endDate)) {
                    url += `&startDate=${this.state.startDate}`;
                } else if (this.state.endDate && (!this.state.startDate)) {
                    url += `&endDate=${this.state.endDate}`;
                }
                serviceGet(url, headers)
                    .then((res) => {
                        if (res.data) {
                            this.setState({
                                page : 1, 
                                currentPage : 0,
                                loading: false,
                                notificationList: res.data.responseObject,
                                pageCount: res.data.totalElements < 10 ? 1 : Math.ceil(res.data.totalElements / 10)
                            });
                        }
                    }).catch((error) => {
                        console.log(error);
                        this.setState({
                            loading: false
                        })
                    });
            }
        }
    }

    changePage = ({ selected }) => {
        this.setState({
            page : selected + 1,
            currentPage: selected,
            notificationList: []
        }, () => { this.getNotificationList() });
    }

    onChangeStatus = async (selectedValue) => {
        this.setState({
            status: selectedValue.value
        });
    }

    sortList = (sortBy,orderBy)=>{
        this.setState({
            sortBy : sortBy,
            orderBy : orderBy
        },()=>{
            this.getNotificationList();
        });
    }
    render() {


        const handleDrop = acceptedFiles => {
            this.setState({
                setFileNames: acceptedFiles,
                fileNames: acceptedFiles.map(file => file.name)
            })
            var that = this;
            this.state.setFileNames.forEach(file => {
                const reader = new FileReader()
                var totalBytes = file.size;
                if(totalBytes > 1000000){
                   
                    var _size = (totalBytes/1000000); 
                    if(_size > 10){
                        var mediaType = "Media";
                        if(file.type.startsWith("video")){
                            mediaType = "Video";
                        }else if(file.type.startsWith("image")){
                            mediaType = "Image";
                        }
                        that.setState({
                            setFileNames: [],
                            fileNames: null
                        })
                        Swal.fire({
                            title: 'Upload Failed',
                            icon: 'error',
                            html: 'Failed to upload an '+mediaType+'. The '+mediaType+' size should be maximum 10MB.',
                            confirmButtonText: 'Ok'
                        });
                        return;

                    }
                    
                }
                reader.onabort = () => console.log('file reading was aborted')
                reader.onerror = () => console.log('file reading has failed')
                reader.onload = () => {
                    // Do whatever you want with the file contents
                    const binaryStr = reader.result
                    console.log("binaryStr", binaryStr)
                    const blob = new Blob([binaryStr]);
                    const srcBlob = URL.createObjectURL(blob);
                    console.log("srcBlob", srcBlob);
                    
                    var that = this;
                    var _URL = window.URL || window.webkitURL;
                    
                    var img = new Image();
                    var objectUrl = _URL.createObjectURL(blob);
                    img.onload = function () {
                        _URL.revokeObjectURL(objectUrl);

                        if(this.width != 380 && this.height != 250){
                            that.setState({
                                setFileNames: [],
                                fileNames: null
                            })
                            Swal.fire({
                                title: 'Upload Failed',
                                icon: 'error',
                                html: 'Failed to upload an image. The image size should be 380x250 px.',
                                confirmButtonText: 'Ok'
                              });
                        }else{
                            that.setState({
                                ImagePreview: srcBlob,
                            })
                        }
                    };
                    img.src = objectUrl;


                }
                reader.readAsArrayBuffer(file)
            });
            if(acceptedFiles[0].type.startsWith("video/")){
                this.setState({
                    notificationType : 'video'
                })
            }
            else if(acceptedFiles[0].type.startsWith("image/")){
                this.setState({
                    notificationType : 'image'
                })
            }
            console.log("acceptedFiles",acceptedFiles);
            console.log("acceptedFiles", this.state.setFileNames);
            console.log("fileNames", this.state.fileNames);
        };
        var baseUrl = SERVICE_URL + "/notificationMedia/";
        const notificationColumn = [
            {
                dataField: '_id',
                text: <CustomInput type="checkbox" />,
                formatter: (cell, row, index) => {
                    return (<React.Fragment><CustomInput className="rowCheckbox" type="checkbox" id={row._id} /></React.Fragment>)
                }
            },
            {
                dataField: 'notificationId',
                text: 'Id',
                // style: { width: '10%' },
                sort: true,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'title',
                text: 'Notification Title',
                sort: true,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'description',
                text: 'Description',
                sort: true,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'mediaThumb',
                text: 'Media',
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>
                        <div className="notification-cell-media-wrapper" onClick={(e) => { this.playerToggle('video', row); }}>
                            {row.notificationType == "image"? 
                                <img className="rounded notification-cell-image" src={baseUrl + cell} onError={(e)=>{e.target.onerror = null; e.target.src=""+baseUrl +"/notification_image_notfound.png"}} /> : 
                                row.notificationType == "video"?<i class="uil uil-play-circle" ></i>:
                                row.notificationType == "text"?<i class="uil uil-text-size"></i>:
                                <></>
                            }
                        </div>
                    </React.Fragment>)
                }
            },
            {
                dataField: 'notificationType',
                text: 'Type',
                sort: true,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'createdAt',
                text: 'Create Date',
                sort: true,
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>
                        <div>{moment(cell).format('MM-DD-YYYY')}</div>
                    </React.Fragment>)
                },
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'status',
                text: 'Status',
                sort: true,
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>
                        <div>{cell === true ? <span className="text-success">Active</span> : <span className="text-warning">Disable</span>}</div>
                    </React.Fragment>)
                },
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'status',
                text: 'Action',
                formatter: (cell, row, rowIndex) => {
                    return (<React.Fragment>
                        <div>

                            <Link className="text-primary pr-3" to={{ pathname: "/notification/send", state: { notiData: row } }}><Send size={16}></Send></Link>

                            {/* <Link className="text-primary pr-3" to="/notification/send"><Send size={16}></Send></Link> */}
                            <i className="text-success uil uil-edit" onClick={(e) => { this.toggle('editNotification', row); }}></i>
                        </div>
                    </React.Fragment>)
                }
            }
        ]
        return (
            <React.Fragment>
                {this.state.pageLoading ? <Loader /> :
                    <div className="container-fluid">
                        <div className="card shadow mt-4">
                            <div className="card-header page-heading pt-4 pb-3">
                                <div className="row">
                                    <div className="col-md-12">
                                        <h3 className="text-dark">List of Notification</h3>
                                    </div>
                                    <div className="col-md-3 pt-3">
                                        <div className="text-md-left dataTables_filter search-box-div" id="dataTable_filter">
                                            <i className="uil uil-search search-icon"></i>
                                            {/* <input type="search" id="searchByName" className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search" onChange={(event) => { this.searchByName(event.target.value) }} /> */}
                                            <input type="search"  id="searchByName" value={this.state.searchName} className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search" onChange={(event)=>{
                                                this.setState({
                                                    searchName : event.target.value
                                                },()=>{
                                                    this.searchByName(this.state.searchName)
                                                })
                                            }}/>
                                        </div>
                                    </div>
                                    <div className="col-md-3 pt-3">
                                        <div className="input-group">
                                            <label className="mt-2 mr-1">Start Date</label>
                                            <input type="date" id="startDate" name="startDate" className="form-control date-box" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={this.handleChange} />
                                        </div>
                                    </div>
                                    <div className="col-md-3 pt-3">
                                        <div className="input-group">
                                            <label className="mt-2 mr-1">End Date</label>
                                            <input type="date" id="endDate" name="endDate" className="form-control date-box" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={this.handleChange} />
                                        </div>
                                    </div>
                                    <div className="col-md-2 text-md-right pt-3">
                                        {this.state.user.roles.indexOf('listNotification') > -1 ?  // notification permission con ditions
                                            <button type="button" className="btn btn-sm btn-primary px-3 py-2" onClick={(e) => { this.toggle(); }}>Add Notification</button>
                                            : null
                                        }
                                    </div>
                                    <div className="col-md-0 mt-2 ml-4 font-size-22 pt-2">
                                        <i className="uil uil-sync" onClick={(e) => {
                                            this.setState({
                                                searchName: '',
                                                startDate: null,
                                                endDate: null,
                                                currentPage : 0,
                                                page:1
                                            }, () => {
                                                document.getElementById("startDate").value = "";
                                                document.getElementById("endDate").value = "";
                                                this.getNotificationList();
                                            })

                                        }}></i>
                                    </div>
                                </div>
                            </div>
                            <div className="card-body p-0">
                                <ToolkitProvider
                                    bootstrap4
                                    keyField="id"
                                    data={this.state.notificationList}
                                    columns={notificationColumn}
                                // search
                                // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                                >
                                    {props => (
                                        <React.Fragment>
                                            <BootstrapTable
                                                {...props.baseProps}
                                                bordered={false}
                                                wrapperClasses="table-responsive pl-3 pr-3"
                                                noDataIndication={this.state.loading ? <Loader /> : 'No Data Found'}
                                            />
                                        </React.Fragment>
                                    )}
                                </ToolkitProvider>
                            </div>
                        </div>
                        <div className="row">
                            <div className="text-nowrap mt-4">
                                <ReactPaginate previousLabel={"Previous"}
                                    pageCount={this.state.pageCount}
                                    nextLabel={"Next"}
                                    onPageChange={this.changePage}
                                    forcePage={this.state.currentPage}
                                    containerClassName={"paginationBttns"}
                                    previousLinkClassName={"previousBttn"} nextLinkClassName={"nextBttn"}
                                    activeLinkClassName={"paginationActive"} disabledClassName={"paginationDisabled"}>
                                </ReactPaginate>
                            </div>
                        </div>
                    </div>
                }
                <Modal
                    isOpen={this.state.modal}
                    toggle={this.toggle}
                    className={this.state.className}
                    size='lg'>
                    <div>
                        <ModalHeader toggle={this.toggle}>{this.state.modalType === 'editNotification' ? 'Update Notification' : 'Create Notification'}</ModalHeader>

                        <AvForm onValidSubmit={this.createNotification}>
                            <ModalBody>
                                <Row>
                                    <Col md={12}>
                                        <label>Notification Title</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="title" type="text" required placeholder="Enter Notification Title" autoComplete="false" value={this.state.title} onChange={this.handleChange}
                                            validate={{ required: { value: true } }} />
                                    </Col>
                                    <Col md={12}>
                                        <label>Description</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="description" type="textarea" required placeholder="Enter Description" autoComplete="false" value={this.state.description} onChange={this.handleChange}
                                            validate={{ required: { value: true } }} />
                                    </Col>
                                    <Col md={12}>
                                        <label>Notification Type</label>

                                        <AvRadioGroup value={this.state.notificationType} onChange={this.handleChange} inline name="notificationType" required>
                                            <AvRadio label="Text" value="text" />
                                            <AvRadio label="Image" value="image" />
                                            <AvRadio label="Video" value="video" />
                                        </AvRadioGroup>
                                    </Col>
                                    <Col md={12}>
                                        <Dropzone
                                            accept="video/*,image/*"
                                            onDrop={handleDrop}>
                                            {({ getRootProps, getInputProps }) => (
                                                <div {...getRootProps({ className: "dropzone" })}>
                                                    <input multiple="false" accept="*.jpge,*.png,*.avi," {...getInputProps()} />
                                                    <div className="text-center">
                                                        <h1 class="h1"><i className="uil uil-cloud-upload  pr-2"></i></h1>

                                                        <p> <i className="fa fa-cloud-upload" aria-hidden="true"></i> Drag'n'drop files, or click to select files</p>
                                                        <div>
                                                            <p>
                                                            Notification Image (png ,jpg) <br></br>
                                                            Image size support (380x250px) <br></br>
                                                            Image available only 1 pictures<br></br>
                                                            Video available only 10MB
                                                            </p>
                                                        </div>
                                                    </div>

                                                </div>
                                            )}
                                        </Dropzone>
                                        
                                        <div>
                                            <ul className="list-group mt-3">
                                                {this.state.setFileNames.length > 0 ? this.state.setFileNames.map(file => (
                                                    <li className="list-group-item" key={file.name}>
                                                        {file.type.startsWith("image/")}
                                                        {this.state.ImagePreview == null && file.type.startsWith("image/") == true ? <Loader /> : <img src={this.state.ImagePreview} className="notification-ImagePreviewe" width="200" />}
                                                        <span className="ml-4">{file.name}</span>
                                                    </li>
                                                )) :
                                                    this.state.mediaThumb != null ?
                                                        <li className="list-group-item">
                                                            <img className="rounded" src={baseUrl + this.state.mediaThumb} className="notification-ImagePreviewe" width="200" />
                                                        </li>
                                                        : ''

                                                }
                                            </ul>
                                        </div>
                                    </Col>

                                </Row>

                            </ModalBody>
                            <ModalFooter>
                                <button className="btn btn-outline-primary btn-lg">{this.state.modalType === 'editNotification' ? 'Update' : 'Create'}</button>
                                <button className="btn btn-outline-danger btn-lg" onClick={this.toggle}>Cancel</button>
                            </ModalFooter>
                        </AvForm>
                    </div>
                </Modal>
                <Modal
                    isOpen={this.state.isOpenPlayerModal}
                    toggle={this.playerToggle}
                    className={this.state.className}
                    size='lg'>
                    <div>
                        <ModalHeader toggle={this.playerToggle}>{this.state.selectedMediaRow?.notificationId} - {this.state.selectedMediaRow?.title }</ModalHeader>
                        <div className="p-3">
                             
                        {this.state.selectedMediaRow?.notificationType == "image"? 
                                <img  src={SERVICE_URL + "/notificationMedia/"  + (this.state.selectedMediaRow?.media)} onError={(e)=>{e.target.onerror = null; e.target.src=""+SERVICE_URL + "/notificationMedia/"  +"/notification_image_notfound.png"}} /> : 
                                this.state.selectedMediaRow?.notificationType == "video"?
                                    <ReactPlayer
                                    className='react-player'
                                    url={SERVICE_URL + "/notificationMedia/" + this.state.selectedMediaRow?.media}
                                    width='100%'
                                    height='100%'
                                    controls
                                    playing={true}
                                    /> 
                                :
                                this.state.selectedMediaRow?.notificationType == "text"?<p>{this.state.selectedMediaRow?.description}</p>:
                                <></>
                            }

                       
                        </div>
                       
                    </div>
                </Modal>
               
                
            </React.Fragment>
        )
    }
}
export default Notification;