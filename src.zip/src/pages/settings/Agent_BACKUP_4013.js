import AvField from 'availity-reactstrap-validation/lib/AvField';
import AvForm from 'availity-reactstrap-validation/lib/AvForm';
import AvGroup from 'availity-reactstrap-validation/lib/AvGroup';
import React,{Component} from 'react';
import Loader from '../../components/Loader';
import ReactPaginate from 'react-paginate';
import {Link} from 'react-router-dom';
import Select from 'react-select';
import { Modal, ModalFooter, Col, ModalBody, ModalHeader, Row, Button, Table,CustomInput } from 'reactstrap';
import Label from 'reactstrap/lib/Label';
import { getLoggedInUser } from '../../helpers/authUtils';
import { dateFormat } from '../../helpers/common';
import { serviceGet, servicePost,servicePut } from './../../helpers/api';

import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import moment from 'moment';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import { toast } from 'react-toastify';
class Agent extends Component
{
        constructor(props) {
        super(props);

        this.state = {
            user: getLoggedInUser(),
            modal: false,
            loading: true,
            pageLoading: false,
            agentList: [],
            name:'',
            email: null,
            password: null,
            agentId:null,
            position:'',
            phoneNumber:0,
            countryCode: '',
            inviteBy:'',
            page:1,
            size:10,
            pageCount:1,
            inviters:[],
            positions:['Agent','Trainer'],
            searchName: ''
        };
        this.toggle = this.toggle.bind(this);
        this.getAgentList= this.getAgentList.bind(this);
        this.createAgent= this.createAgent.bind(this);
        this.getInviters= this.getInviters.bind(this);
        this.onChangePosition = this.onChangePosition.bind(this);
        this.onChangeInviter = this.onChangeInviter.bind(this);
        this.changePage = this.changePage.bind(this);
    }
    
    componentDidMount(){     
        this.getAgentList();
    }

    getAgentList = (agentName = null) =>{
        this.setState({
            agentList: [],
            loading: true
        })
        if(agentName == null){agentName =""}
        let url = `api/v1/agent/list?name=${agentName}&page=${this.state.page}&size=${this.state.size}`;
        if(this.state.startDate && this.state.endDate){
          url+= `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
        }else if(this.state.startDate && (!this.state.endDate)){
          url+= `&startDate=${this.state.startDate}`;
        }else if(this.state.endDate && (!this.state.startDate)){
          url+= `&endDate=${this.state.endDate}`;
        }
        serviceGet(url,{
             'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
        .then((res)=>{
              if(res.data){
                this.setState({
                    agentList: res.data.responseObject,
                    pageCount: Math.ceil(res.data.totalElements/10),
                    loading: false
                })
             }
        }).catch((error) => {
            console.log(error);
            this.setState({
                 loading: false
            })
        });
    }

    createAgent = () =>{
<<<<<<< HEAD
        if(this.state.position === null || this.state.position === undefined || this.state.position === ""){
=======
        if( 
        this.state.position === null || this.state.position === undefined || this.state.position === ""){
>>>>>>> dev_deepika
            toast('Please fill all the fields.',{bodyClassName:'error-toast'});
            return;
        }
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        let agent={
          'name': this.state.name,
          'email': this.state.email,
          'password': this.state.password, 
          "phoneNumber": this.state.phoneNumber,
          "countryCode": this.state.countryCode,
          "invitedBy": this.state.inviteBy.value,
          "position": this.state.position
        }
        if(this.state.password === null) {
            delete agent.password;
        }
        if(this.state.agentId){
          servicePut(`api/v1/agent/${this.state.agentId}`,
          JSON.stringify(agent),
          headers,)
          .then((res)=>{
              if(res.data){
                this.getAgentList();
                this.toggle();
                toast('Agent updated successfully',{bodyClassName:'success-toast'});
             }else {
                toast(res.error,{bodyClassName:'error-toast'});
            }
         })
         .catch((err) => {
            console.log(err)
            toast('Some error occurred',{bodyClassName:'error-toast'});
         })
        }else{
        servicePost('api/v1/agent',JSON.stringify(agent),headers)
          .then((res)=>{
              if(res.data){
                this.getAgentList();
                this.toggle();
                toast('Agent created successfully',{bodyClassName:'success-toast'});
             }else {
                toast(res.error,{bodyClassName:'error-toast'});
            }
         })
         .catch((err) => {
            console.log(err)
            toast('Some error occurred',{bodyClassName:'error-toast'});
         })
      }
    }

    toggle = (modal, agent) => {
        if(agent != null) {
            let inviter = {
                'label':agent.invitedBy?.name,
                'value':agent.invitedBy?._id
            }
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                agentId: agent._id,
                name: agent.name,
                phoneNumber: agent.phoneNumber,
                position: agent.position,
                inviteBy: inviter,
                email: agent.email,
                countryCode: agent.countryCode ? agent.countryCode : ''
            }))
        } else {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                agentId:null,
                name: '',
                phoneNumber:null,
                position:'',
                inviteBy:'',
                email: '',
                password: null,
                countryCode: ''
            }))
        }
    };

    getInviters=(inviter)=>{
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        if(inviter.length > 0){
       serviceGet(`api/v1/agent/list?name=${inviter}&page=${1}&size=${10}`,headers)
          .then((res)=>{
              let inviterObj=[];
              for(var i=0;i<res.data.responseObject.length;i++){
                  inviterObj.push({
                      'value':res.data.responseObject[i]._id,
                      'label':res.data.responseObject[i].name
                  });
              }
            //   if(res.data){
                this.setState({
                    inviters: inviterObj
                });
            //  }
         });
      }
    }

    getPositions = () =>{
        serviceGet(`api/v1/agent/position`)
          .then((res)=>{
              if(res.data){
                this.setState({
                    positions: res.data
                })
             }
         });
    }

    onChangePosition = async (selectedValue) => {
        this.setState({
            position: selectedValue.value
        });
    }

    onChangeInviter = async (selectedValue) =>{
        this.setState({
            inviteBy:selectedValue
        });
    }

    handleChange = (event) => {
        if(event.target.name === 'startDate' || event.target.name === 'endDate'){
          let date = new Date(event.target.value);
          this.setState({
            [event.target.name]: date.toISOString()
          });
        }else{
        this.setState({
            [event.target.name]: event.target.value
        });
       }
    }

    searchByName = (name) =>{
        if(!name) {
            this.setState({
                searchName: ''
            }, () => this.getAgentList())
        } else {
            let headers = {
                    'Content-Type': 'application/json',
                    Authorization: 'Bearer ' + this.state.user.token
                };
            if(name.length >= 0) {
                this.setState({
                    agentList: [],
                    searchName: name,
                    loading: true
                })
                serviceGet(`api/v1/agent/list?keyword=${name}&page=${1}&size=${10}`,headers)
                .then((res) => {
                    if(res.data){
                        this.setState({
                            loading: false,
                            agentList: res.data.responseObject,
                            pageCount: res.data.totalElements
                        });
                    }
                }).catch((error) => {
                    console.log(error);
                    this.setState({
                         loading: false
                    })
                });
            }
        }
    }

    changePage = ({selected})=>{
        this.setState({
            page: selected + 1,
            agentList: []
        },()=>{this.getAgentList()});
     }
    
    render() {
        const agentColumn = [
            {
                dataField: '_id',
                text: <CustomInput type="checkbox"/>,
                formatter : (cell,row,index)=>{
                  return (<React.Fragment><CustomInput className="rowCheckbox" type="checkbox" id={row._id}/></React.Fragment>)
                }
            },
            {
                dataField: 'agentId',
                text: 'Agent Id',
                // style: { width: '10%' },
                sort: true,
            },
            {
                dataField: '_id',
                text: 'Image',
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <div>-</div>
                        </React.Fragment>)
                }
            },
            {   
                dataField: 'name',
                text: 'Name',
                sort : true
            },
            {
                dataField: 'createdAt',
                text: 'Register Time/Date',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <div>{moment(cell).format('MM-DD-YYYY')}</div>
                        </React.Fragment>)
                }
            },

            {
                dataField: '_id',
                text: 'Invited By',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            {row.invitedBy? row.invitedBy.name : '-'}
                        </React.Fragment>)
                }
            },
            {
                dataField: 'position',
                text: 'Position',
                sort : true
            },
            {
                dataField: 'earnings',
                text: 'Earnings',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <div className="text-info">{'$ ' + cell}</div>
                        </React.Fragment>)
                }
            },
            {  
               dataField: 'earned',
               text: 'Earned',
               sort : true,
               formatter : (cell, row, rowIndex) => {
                   return (<React.Fragment>
                           <div>{'$ ' + cell}</div>
                       </React.Fragment>)
               }
            },
            {   
                dataField: 'position',
                text: 'Action',
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            
                            <div className="text-success pl-1"><i className="uil uil-edit" onClick={(e) => {this.toggle('editAgent',row);}}></i></div>
                        </React.Fragment>)
                }
            },
        ]
        return (
             <React.Fragment>
                  { this.state.pageLoading ? <Loader/> : 
            <div className="container-fluid">
                <div className="card shadow mt-4">
                    <div className="card-header page-heading pt-4 pb-3">
                        <div className="row">
                            <div className="col-md-12">
                                    <h3 className="text-dark">List of Agents</h3>
                            </div>
                            <div className="col-md-3 pt-3">
                                <div className="text-md-left dataTables_filter search-box-div" id="dataTable_filter">
                                    <i className="uil uil-search search-icon"></i>
<<<<<<< HEAD
                                    <input type="search" id="searchByName" className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search" onChange={(event)=>{this.searchByName(event.target.value)}}/>
=======
                                    <input type="search" id="searchByName" className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search by name" onChange={(event)=>{this.getAgentList(event.target.value)}}/>
>>>>>>> dev_deepika
                                </div>
                            </div>
                            <div className="col-md-3 pt-3">
                                <div className="input-group">
                                   <label className="mt-2 mr-1">Start Date</label>
                                   <input type="date" name="startDate" className="form-control date-box" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={this.handleChange}/>
                                </div>
                            </div>
                            <div className="col-md-3 pt-3">
                                <div className="input-group">
                                   <label className="mt-2 mr-1">End Date</label>
                                   <input type="date" name="endDate" className="form-control date-box" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={this.handleChange}/>
                                </div>
                            </div>
                            <div className="col-md-2 text-md-right pt-3">
                                { this.state.user.roles.indexOf('addAgent') > -1 ?
                                    <button type="button" className="btn btn-sm btn-primary px-3 py-2" onClick={(e) => {this.toggle();}}>Add Agent</button> : null
                                }
                            </div>
                            <div className="col-md-1 mt-2 font-size-20 pt-3">
                                <i className="uil uil-sync" onClick={(e)=>{this.getAgentList()}}></i>
                            </div>
                        </div>
                    </div>
                    <div className="card-body p-0">    
                    <ToolkitProvider
                        bootstrap4
                        keyField="id"
                        data={this.state.agentList}
                        columns={agentColumn}
                        // search
                        // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                        >
                        {props => (
                            <React.Fragment>
                                <BootstrapTable
                                    {...props.baseProps}
                                    bordered={false}
                                    wrapperClasses="table-responsive pl-3 pr-3"
                                    noDataIndication={ this.state.loading ? <Loader/> : 'No Data Found'}
                                />
                            </React.Fragment>
                        )}
                    </ToolkitProvider>   
                    </div>
                </div>
                <div className="row">
                    <div className="text-nowrap mt-4">
                    {/* <div id="dataTable_length" className="dataTables_length" aria-controls="dataTable"><label>Show&nbsp;<select className="form-control form-control-sm custom-select custom-select-sm"><option value="10" selected="">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select>&nbsp;</label></div> */}
                        <ReactPaginate previousLabel={"Previous"} 
                            pageCount={this.state.pageCount}
                            nextLabel={"Next"} 
                            onPageChange={this.changePage} 
                            containerClassName={"paginationBttns"}
                            previousLinkClassName={"previousBttn"} nextLinkClassName={"nextBttn"}
                            activeLinkClassName={"paginationActive"} disabledClassName={"paginationDisabled"}>
                        </ReactPaginate>
                    </div>
                </div>
                <Modal
                    isOpen={this.state.modal}
                    toggle={this.toggle}
                    className={this.state.className}
                    size='lg'>
                        <div><ModalHeader toggle={this.toggle}>{this.state.modalType === 'editAgent'? 'Update Agent Information' : 'Create Agent Information'}</ModalHeader>
                         <AvForm onValidSubmit={this.createAgent}>
                            <ModalBody>
                                <Row>
                                    <Col md={6}>
                                        <label>Agent Name</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="name" type="text" required placeholder="Enter Agent Name" autoComplete="false" value={this.state.name} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6}>
                                        <label>Email</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="email" type="email" required placeholder="Email" autoComplete="false" value={this.state.email} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                        <Col md={6}>
                                    <label>Password</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                       <span className="password-position">
                                          <AvField name="password" type="password" required={this.state.modalType !== 'editAgent'} placeholder="Enter Password" autoComplete="false" value={this.state.password} onChange={this.handleChange}
                                              validate={{
                                                minLength: {value: 4, errorMessage: 'Your password must be between 4 and 8 characters'},
                                                maxLength: {value: 8, errorMessage: 'Your password must be between 4 and 8 characters'},
                                                required: {value: true, errorMessage: 'Please enter password'},
                                              }}
                                               />
                                        </span>
                                        {this.state.modalType === 'editAgent'?<div className="mb-2 text-primary"><i className="uil uil-info-circle info-icon"></i><small>If filled,then existing password will be updated else leave blank</small></div>:''}
                                    </Col>
                                    <Col md={6}>
                                        <AvGroup row>
                                            <Col sm={12}>
                                                <Label for="example" className="text-muted">Position</Label><span className="text-danger pt-2"><sup>*</sup></span>
                                                <Select
                                                   onChange={this.onChangePosition}
                                                    value={[{
                                                         value:this.state.position,
                                                         label:this.state.position
                                                    }]}
                                                   // isMulti={true}
                                                   options={[
                                                     { value: 'Agent', label: 'Agent' },
                                                     { value: 'Trainer', label: 'Trainer' }
                                                   ]}
                                                   className="react-select"
                                                   classNamePrefix="react-select"
                                                   placeholder={'Select a position'}
                                                 />
                                          </Col>
                                         </AvGroup>
                                    </Col>
                                    <Col md={6}>
                                        <label>Phone Number</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="phoneNumber" type="number" required placeholder="Enter Phone Number" autoComplete="false" value={this.state.phoneNumber} onChange={this.handleChange}
                                                                validate={{
                                                                    minLength: {value: 10, errorMessage: 'Please enter valid phone number'},
                                                                    maxLength: {value: 10, errorMessage: 'Please enter valid phone number'},
                                                                    required: {value: true, errorMessage: 'Please enter a phone number'},
                                                                  }}
                                                                />
                                    </Col>
                                    <Col md={6}>
                                        <AvGroup row>
                                            <Col sm={12}>
<<<<<<< HEAD
                                                <Label for="example" className="text-muted">Invite By</Label>
=======
                                                <Label for="example">Invite By</Label><span className="text-danger pt-2"></span>
>>>>>>> dev_deepika
                                                <Select
                                                  onInputChange={(value) => this.getInviters(value)}
                                                  onChange={this.onChangeInviter}
                                                  value={[{'value':this.state.inviteBy?.value,'label':this.state.inviteBy?.label}]}
                                                   // isMulti={true}
                                                   options={this.state.inviters}
                                                   className="react-select"
                                                   classNamePrefix="react-select"
                                                   placeholder={'Search inviter'}
                                                 />
                                          </Col>
                                         </AvGroup>
                                    </Col>
                                    <Col md={6}>
                                        <label>Country Code</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="countryCode" type="number" required placeholder="Enter Country Code" autoComplete="false" value={this.state.countryCode} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                </Row>
                            </ModalBody>
                            <ModalFooter>
                                <button className="btn btn-outline-primary btn-lg">{this.state.modalType === 'editAgent'? 'Update' : 'Create'}</button>
                                <button className="btn btn-outline-danger btn-lg" onClick={this.toggle}>Cancel</button>
                            </ModalFooter>
                          </AvForm> 
                       </div>
                </Modal>
            </div>
            }
            </React.Fragment>
        )
    }
}
export default Agent;