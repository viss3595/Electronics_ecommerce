import React, { Component } from 'react';
import { Row, Col, Card, CardBody, Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import { servicePost } from '../../helpers/api';
import { toast } from 'react-toastify';
import { connect } from 'react-redux';

class Modals extends Component {
    constructor(props) {
        super(props);

        this.state = {
            modal: false,
            type: '',
        };

        this.toggle = this.toggle.bind(this);
        // this.openModalWithSize = this.openModalWithSize.bind(this);
        this.openModalWithClass = this.openModalWithClass.bind(this);
        this.deleteRowTeam = this.deleteRowTeam.bind(this);
        this.deleteTableRow = this.deleteTableRow.bind(this);

        this.headers = {
            'Content-Type': 'application/json',
            Authorization: 'JWT ' + this.props.user.token,
        };
    }

    /**
     * Show/hide the modal
     */
    toggle = () => {
        this.setState((prevState) => ({
            modal: !prevState.modal,
        }));
    };
    /**
     * Opens modal with custom class
     */
    openModalWithClass = (data) => {
        this.setState({
            // className: data.class,
            size: null,
            type: data == 'delete' ? 'delete' : '',
        });
        this.toggle();
    };

    /** DELETE TABLE DATA ROW Team */
    deleteRowTeam = (rowID) => {
        try {
            servicePost('team/deleteTeamByID', { id: rowID }, this.headers)
                .then((res) => {
                    this.props.reload();
                    this.toggle();
                    toast('Deleting Team', { bodyClassName: 'success-toast' });
                })
                .catch((err) => {
                    console.log(err);
                });
        } catch (err) {
            console.log(err);
        }
    };

    /** DELETE TABLE DATA ROW Agent */
    deleteTableRow = (rowID) => {
        try {
            servicePost('agent/deleteAgentByID', { id: rowID }, this.headers)
                .then((res) => {
                    console.log(res.status);
                    this.props.reload();
                    this.toggle();
                    res.status === 0 && res.message === 'SUCCESS'
                        ? toast('Failed to delete, user is an admin', { bodyClassName: 'error-toast' })
                        : toast('Deleting Agent', { bodyClassName: 'success-toast' });
                })
                .catch((err) => {
                    console.log(err);
                });
        } catch (err) {
            console.log(err);
        }
    };

    render() {
        return (
            <Row>
                {this.props.actionType == 'team' && (
                    <React.Fragment>
                        <Col md={4}>
                            <span onClick={() => this.props.rowEdit(this.props.rowID)}>
                                <i class="uil uil-edit"></i>
                            </span>
                        </Col>
                        <Col md={6}>
                            <span style={{ float: 'left' }}>
                                <i onClick={() => this.openModalWithClass('delete')} className="uil uil-trash-alt"></i>
                            </span>
                            <Row>
                                {/* <Col xl={4}>                                     */}
                                {/* <div className="button-list"> */}
                                {/* <Button color="danger" > */}
                                {/* </Button> */}
                                {/* </div> */}
                                {/* </Col>                                */}
                            </Row>
                            <Modal
                                isOpen={this.state.modal}
                                toggle={this.toggle}
                                className={this.state.type == 'delete' ? 'modal-dialog-centered' : ''}
                                // size={this.state.size}
                                backdrop="static">
                                {this.state.type == 'delete' && (
                                    <React.Fragment>
                                        <ModalHeader
                                            cssModule={{ 'modal-title': 'w-100 text-center ' }}
                                            toggle={this.toggle}
                                            style={{ padding: '0.2rem 0.8rem' }}>
                                            <span style={{ fontSize: '28px' }}>Alert </span>
                                        </ModalHeader>
                                        <ModalBody>
                                            <Row>
                                                <Col>
                                                    <p style={{ fontSize: '20px', textAlign: 'center' }}>
                                                        {this.props.countLength != null && (
                                                            <React.Fragment>{this.props.deleteMesg}</React.Fragment>
                                                        )}
                                                        {this.props.countLength == null && (
                                                            <React.Fragment>
                                                                You are sure, you want to delete this team
                                                            </React.Fragment>
                                                        )}
                                                    </p>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col>
                                                    <Button
                                                        color="secondary"
                                                        className="ml-1"
                                                        style={{ float: 'right' }}
                                                        onClick={this.toggle}>
                                                        Cancel
                                                    </Button>
                                                </Col>
                                                <Col>
                                                    <Button
                                                        color="danger"
                                                        style={{ float: 'left' }}
                                                        onClick={this.deleteRowTeam.bind(this, this.props.rowID)}>
                                                        Delete
                                                    </Button>
                                                </Col>
                                            </Row>
                                        </ModalBody>
                                    </React.Fragment>
                                )}
                            </Modal>
                        </Col>
                    </React.Fragment>
                )}
                {this.props.actionType == 'agent' && (
                    <React.Fragment>
                        <Col md={4}>
                            <span onClick={() => this.props.rowEdit({ agentId: this.props.rowID, type: 'editUpdate' })}>
                                <i class="uil uil-edit"></i>
                            </span>
                        </Col>
                        <Col md={6}>
                            <span style={{ float: 'left' }}>
                                <i onClick={() => this.openModalWithClass('delete')} className="uil uil-trash-alt"></i>
                            </span>

                            <Modal
                                isOpen={this.state.modal}
                                toggle={this.toggle}
                                className={this.state.type == 'delete' ? 'modal-dialog-centered' : ''}
                                // size={this.state.size}
                                backdrop="static">
                                {this.state.type == 'delete' && (
                                    <React.Fragment>
                                        <ModalHeader
                                            cssModule={{ 'modal-title': 'w-100 text-center ' }}
                                            toggle={this.toggle}
                                            style={{ padding: '0.2rem 0.8rem' }}>
                                            <span style={{ fontSize: '28px' }}>Alert </span>
                                        </ModalHeader>
                                        <ModalBody>
                                            <Row>
                                                <Col>
                                                    <p style={{ fontSize: '20px', textAlign: 'center' }}>
                                                        Are you sure to delete this agent?
                                                    </p>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col>
                                                    <Button
                                                        color="secondary"
                                                        className="ml-1"
                                                        style={{ float: 'right' }}
                                                        onClick={this.toggle}>
                                                        Cancel
                                                    </Button>
                                                </Col>
                                                <Col>
                                                    <Button
                                                        color="danger"
                                                        style={{ float: 'left' }}
                                                        onClick={this.deleteTableRow.bind(this, this.props.rowID)}>
                                                        Delete
                                                    </Button>
                                                </Col>
                                            </Row>
                                        </ModalBody>
                                    </React.Fragment>
                                )}
                            </Modal>
                        </Col>
                    </React.Fragment>
                )}
            </Row>
        );
    }
}

// export default Modals;

const mapStateToProps = (state) => {
    // const { user, loading, error } = state.Auth;
    return state.Auth;
};
export default connect(mapStateToProps)(Modals);
