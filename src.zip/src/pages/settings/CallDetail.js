import React, { Component } from 'react';
import { Row, Col, Card, CardBody, TabContent, TabPane, Nav, NavItem, NavLink, Input, Button, Badge } from 'reactstrap';
import classnames from 'classnames';
import PageTitle from '../../components/PageTitle';
import BootstrapTable from 'react-bootstrap-table-next';
import ToolkitProvider, { Search, CSVExport } from 'react-bootstrap-table2-toolkit';
import paginationFactory from 'react-bootstrap-table2-paginator';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import filterFactory, { selectFilter,multiSelectFilter, Comparator } from 'react-bootstrap-table2-filter';
import 'react-bootstrap-table2-filter/dist/react-bootstrap-table2-filter.min.css';
import { servicePost } from './../../helpers/api';
import { dateFormat, capitalize } from './../../helpers/common';
import { connect } from 'react-redux';
import Moment from 'react-moment';
import { color } from 'd3';
import Loader from '../../components/Loader';
import UniversalDatePicker from '../miscellaneous/UniversalDatePicker';
import PaginationPage from './../miscellaneous/PaginationPage';
import overlayFactory from 'react-bootstrap-table2-overlay';

const sizePerPageRenderer = ({ options, currSizePerPage, onSizePerPageChange }) => (
    <React.Fragment>
        <label className="d-inline mr-1">Show</label>
        <Input
            type="select"
            name="select"
            id="no-entries"
            className="custom-select custom-select-sm d-inline col-2"
            defaultValue={currSizePerPage}
            onChange={(e) => onSizePerPageChange(e.target.value)}>
            {options.map((option, idx) => {
                return <option key={idx}>{option.text}</option>;
            })}
        </Input>
        <label className="d-inline ml-1">entries</label>
    </React.Fragment>
);
const { SearchBar } = Search;
const TableWithSearch = (props) => {
    const agents = [
        { value: 'Agent 1', label: 'Agent 1' },
        { value: 'Agent 2', label: 'Agent 2' },
        { value: 'Agent 3', label: 'Agent 3' },
    ];
    const callTypes = [
        { value: 'Outgoing', label: 'Outgoing' },
        { value: 'Incoming', label: 'Incoming' },
    ];
    const swearWords = [
        { value: 'Piss off', label: 'Piss off' },
        { value: 'Bastard', label: 'Bastard' },
        { value: 'Hell with you', label: 'Hell with you' },
    ];

    const records = props.records;

    const isCallCompleted = (status) => {
        if (status == 'COMPLETED') {
            return true;
        }
        return false;
    };

    const getFormattedStatus = (status) => {
        if (status === 'COMPLETED') {
            return 'Review';
        } else if (status === 'WAITING') {
            return 'Waiting';
        } else if (status === 'ERROR') {
            return 'Error';
        }
        return 'Processing';
        // let formattedStatus = status.toLowerCase().split("_").join(" ");
        // return formattedStatus
    };

    const columns = [
        // {
        //     dataField: 'index',
        //     text: 'S No.',
        //     sort: true,
        //     style: { width: '7%' }
        // },
        {
            dataField: 'time',
            text: 'Call date/time',
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                    <Moment format="DD MMM YYYY">{row.time}</Moment>
                    <br />
                    <Moment format="hh:mm A">{row.time}</Moment>
                </React.Fragment>
            ),
            sort: false,
            headerFormatter:(column, colIndex)=> {
                return (
                    <div>
                         <div class="text-center">{ column.text }</div>
                         <div class="text-center" style={{'color':'white'}}>()</div>
                    </div>
                );
              },
        },
        {
            dataField: 'caller',
            text: 'Agent',
            sort: true,
            // filter: multiSelectFilter({
            //     options: agents,
            //     placeholder: 'All Agents',  // custom the input placeholder
            //   })
            headerFormatter:(column, colIndex)=> {
                return (
                    <div>
                         <div class="text-center">{ column.text }</div>
                         <div class="text-center" style={{'color':'white'}}>()</div>
                    </div>
                );
              },
        },
        {
            dataField: 'to',
            text: 'To \r\n From',
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                    <div>{`${records[rowIndex].to}`}</div> <div>{records[rowIndex].from}</div>
                </React.Fragment>
            ),
            sort: false,
            headerFormatter:(column, colIndex)=> {
                return (
                    <div>
                         <div class="text-center">{ column.text }</div>
                         <div class="text-center" style={{'color':'white'}}>()</div>
                    </div>
                );
              },
        },
        {
            dataField: 'callType',
            text: 'Type',
            sort: true,
            // filter: selectFilter({
            //     options: callTypes,
            //     placeholder: 'All Call Types',
            // })
            headerFormatter:(column, colIndex)=> {
                return (
                    <React.Fragment>
                         <div class="text-center">{ column.text }</div>
                         <div class="text-center" style={{'color':'white'}}>()</div>
                    </React.Fragment>
                );
              },
        },
        {
            dataField: 'callId',
            text: '',
            headerFormatter: (column, colIndex, components) => (
                <React.Fragment>
                    Moment groups
                    <br />
                    achieved
                </React.Fragment>
            ),
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                    <div style={{ textAlign: 'center' }}>{`${
                        isCallCompleted(records[rowIndex].transcriptionJobStatus)
                            ? `${records[rowIndex].moment.momentGroupsAchieved}/${records[rowIndex].moment.totalMomentGroups}`
                            : '-'
                    }`}</div>
                </React.Fragment>
            ),
            sort: false,
        },
        {
            dataField: 'callId',
            text: '',
            headerFormatter: (column, colIndex, components) => (
                <React.Fragment>
                    Moments
                    <br />
                    achieved
                </React.Fragment>
            ),
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                    <div style={{ textAlign: 'center' }}>{`${
                        isCallCompleted(records[rowIndex].transcriptionJobStatus)
                            ? `${records[rowIndex].moment.momentsAchieved}/${records[rowIndex].moment.totalMoments}`
                            : '-'
                    }`}</div>
                </React.Fragment>
            ),
            sort: false,
        },
        // {
        //     dataField: 'words',
        //     text: 'Keywords',
        //     sort: false,
        //     formatter: (cell, row) =><React.Fragment><Badge color={`soft-secondary`} key="secondary" className="mr-1 badge call-badges font-weight-500 font-size-14">{row.words}</Badge></React.Fragment>,
        //     filter: selectFilter({
        //         options: swearWords,
        //         placeholder: 'All Swear Words',
        //     })
        // },
        {
            dataField: 'transcriptionJobStatus',
            text: 'Action',
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                    {isCallCompleted(records[rowIndex].transcriptionJobStatus) ? (
                        <a target="_blank"
                            style={{ color: 'white' }}
                            href={`/analyse/calls/${records[rowIndex]._id}`}>
                            <button style={{ width: '100%' }} className="btn btn-primary btn-sm">
                                Review
                            </button>
                        </a>
                    ) : (
                        <button style={{ width: '100%' }} className="btn btn-secondary btn-sm">
                            {getFormattedStatus(records[rowIndex].transcriptionJobStatus)}
                        </button>
                    )}
                </React.Fragment>
            ),
            sort: false,
            headerFormatter:(column, colIndex)=> {
                return (
                    <React.Fragment>
                         <div class="text-center">{ column.text }</div>
                         <div class="text-center" style={{'color':'white'}}>()</div>
                    </React.Fragment>
                );
              },
        },
    ];

    const defaultSorted = [
        {
            dataField: 'id',
            order: 'asc',
        },
    ];

    const onTableChangeInternal = props.onTableChange;
    const totalSize = props.totalSize;
    const sizePerPage = props.sizePerPage;
    const isTableLoading = props.isTableLoading;
    return (
        <Card>
            <CardBody className="pt-0 px-0">
                {/* <h4 className="header-title mt-0 mb-1">Team List</h4> */}
                <ToolkitProvider
                    bootstrap4
                    keyField="id"
                    data={records}
                    columns={columns}
                    search
                    exportCSV={{ onlyExportFiltered: true, exportAll: false }}>
                    {(props) => (
                        <React.Fragment>
                            {/* <Row xs={'2 pb-3'}>
                            <Col md={2}>
                               
                            </Col>
                            <Col md={2}>
                                
                            </Col>
                            <Col md={2}>
                               
                            </Col>
                         
                            </Row> */}

                            <BootstrapTable
                                {...props.baseProps}
                                loading={ isTableLoading }
                                bordered={false}
                                defaultSorted={defaultSorted}
                                pagination={paginationFactory({
                                    sizePerPage: sizePerPage,
                                    sizePerPageRenderer: sizePerPageRenderer,
                                    sizePerPageList: [
                                        { text: '5', value: 5 },
                                        { text: '10', value: 10 },
                                        { text: '25', value: 25 },
                                    ],
                                    totalSize: totalSize,
                                })}
                                wrapperClasses="table-responsive"
                                filter={filterFactory()}
                                remote={true}
                                onTableChange={onTableChangeInternal}
                                
                                overlay={ overlayFactory({ spinner: true, styles: { overlay: (base) => ({...base, background: 'rgba(0, 0, 0, 0.4)', zIndex : 99}) } }) }
                            />
                        </React.Fragment>
                    )}
                </ToolkitProvider>
            </CardBody>
        </Card>
    );
};

class CallDetail extends Component {
    constructor(props) {
        super(props);
        this.state = {
            activeTab: '1',
            records: [],
            loading: true,
            sizePerPage: 25,
            page: 1,
            total: 0,
            isTableLoading : false
        };
        this.toggle = this.toggle.bind(this);
    }

    /**
     * Toggle the tab
     */
    toggle = (tab) => {
        if (this.state.activeTab !== tab) {
            this.setState({
                activeTab: tab,
            });
        }
    };
    onTableChange = (type, newState) => {
        this.setState({
            isTableLoading : true
        });
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'JWT ' + this.props.user.token,
        };
        servicePost('api/v1/analyse/get/call/all', { filter: 'TODAY', date: this.getDate(), page : newState.page, pagination : newState.sizePerPage, dateRange : this.props.dateRange  }, headers).then(
            (callRecords) => {
                // CREATE ONE COLUMN FOR SHOW TO/FROM IN ONE COLUMN
                for (var i = 0; i < callRecords.data.length; i++) {
                    callRecords.data[i].toFrom = callRecords.data[i].to + '\\r\\n' + callRecords.data[i].from;
                    callRecords.data[i].date = dateFormat(callRecords.data[i].date, 1);
                }
                this.setState({
                    records: callRecords.data,
                    page : newState.page,
                    sizePerPage : newState.sizePerPage,
                    isTableLoading : false
                });
            }
        )
        .catch((err)=> {
            console.log(err);
        });
    };
    getDate = (days) => {
        let today;
        //FIND DATE FOR LAST N DAYS
        if (days) {
            var date = new Date();
            today = new Date(date.getTime() - days * 24 * 60 * 60 * 1000);
        } else {
            //FIND TODAY DATE
            today = new Date();
        }
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();
        today = yyyy + '-' + mm + '-' + dd;
        return today;
    };

    handleChange = (event) => {
        var value = event.target.value;
        let date;
        if (value == 'TODAY') {
            date = this.getDate();
        } else if (value == 'LAST_7_DAYS') {
            date = this.getDate(7);
        } else if (value == 'LAST_15_DAYS') {
            date = this.getDate(15);
        } else if (value == 'YESTERDAY') {
            date = this.getDate(1);
        } else {
            date = this.getDate(7);
        }
        try {
            let headers = {
                'Content-Type': 'application/json',
                Authorization: 'JWT ' + this.props.user.token,
            };
            servicePost('api/v1/analyse/get/call/all', { filter: value, date: date , dateRange : this.props.dateRange}, headers)
                .then((res) => {
                })
                .catch((err) => {
                    console.log(err);
                });
        } catch (err) {
            console.log(err);
        }
    };

    handleDateChange = () => {
        this.getCalls(true);
    }

    getCalls = async (isLoading = false) => {
        try {
            if(isLoading){
                this.setState({
                    loading: true
                });
            }

            let headers = {
                'Content-Type': 'application/json',
                Authorization: 'JWT ' + this.props.user.token,
            };
            let callRecords = await servicePost(
                'api/v1/analyse/get/call/all',
                { filter: 'TODAY', date: this.getDate(), dateRange : this.props.dateRange },
                headers
            );
            // CREATE ONE COLUMN FOR SHOW TO/FROM IN ONE COLUMN
            for (var i = 0; i < callRecords.data.length; i++) {
                callRecords.data[i].toFrom = callRecords.data[i].to + '\\r\\n' + callRecords.data[i].from;
                callRecords.data[i].date = dateFormat(callRecords.data[i].date, 1);
            }
            this.setState({
                total : callRecords.totalCallCounts,
                records: callRecords.data,
                loading: false
            });
            return '';
        } catch (error) {
            alert('Invalid Request');
        
        }
    }

    async componentDidMount() {
        this.getCalls()
    }

    render() {
        const tabContents = [
            {
                id: '1',
                title: 'Swear Words',
                icon: 'uil-home-alt',
                text:
                    'Home - Food truck quinoa dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.',
            },
            {
                id: '2',
                title: 'Restricted Phrases',
                icon: 'uil-user',
                text:
                    'Profile - Food truck quinoa dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.',
            },
        ];

        if (this.state.loading) {
            return (
                <React.Fragment>
                  
                            <Loader />
                    
                </React.Fragment>
            );
        }

        return (
            <React.Fragment>
                <Row className="page-title">
                    <Col md={12}>
                        
                        <PageTitle
                            breadCrumbItems={[
                                { label: 'Summary', path: '/summary', active: false },
                                { label: 'Analysis', path: '/analyse/calls', active: true },
                            ]}
                            title={'Analysis'}
                        />
                        <span style={{ fontSize : "16px", fontWeight : "bold"}} >(Total of {this.state.total} calls)</span>
                        
                    </Col>
                </Row>
                <Row>
                    {/* tab pills */}
                    <Col lg={12}>
                        <Card>
                            <CardBody>
                            
                                <Row className="pb-3">
                                    <Col md={3}>
                                        {/* <UniversalDatePicker/> */}
                                        {/* <Input type="select" name="selectMulti" id="exampleSelectMulti" onChange={this.handleChange}>
                                    <option value="LAST_7_DAYS">Last 7 days</option>
                                    <option value="TODAY">Today</option>
                                    <option value="YESTERDAY">Yesterday</option>
                                    <option value="LAST_15_DAYS">Last 15 days</option>
                                </Input> */}
                                    </Col>
                                    <Col md={12}>
                                        <TableWithSearch
                                            onTableChange={this.onTableChange}
                                            records={this.state.records}
                                            sizePerPage={this.state.sizePerPage}
                                            totalSize={this.state.total}
                                            isTableLoading={this.state.isTableLoading}
                                        />
                                    </Col>
                                </Row>
                                <Row></Row>
                                {/* <Nav className="nav nav-pills navtab-bg nav-justified">
                                    {tabContents.map((tab, index) => {
                                        return (
                                            <NavItem key={index}>
                                                <NavLink
                                                    href="#"
                                                    className={classnames({ active: this.state.activeTab === tab.id })}
                                                    onClick={() => {
                                                        this.toggle(tab.id);
                                                    }}>
                                                    <i
                                                        className={classnames(
                                                            tab.icon,
                                                            'd-sm-none',
                                                            'd-block',
                                                            'mr-1'
                                                        )}></i>
                                                    <span className="d-none d-sm-block">{tab.title}</span>
                                                </NavLink>
                                            </NavItem>
                                        );
                                    })}
                                </Nav>

                                <TabContent activeTab={this.state.activeTab}>
                                    {tabContents.map((tab, index) => {
                                        return (
                                            <TabPane tabId={tab.id} key={index}>
                                                <TableWithSearch records={this.state.records}/>
                                            </TabPane>
                                        );
                                    })}
                                </TabContent> */}
                            </CardBody>
                        </Card>
                    </Col>
                </Row>
            </React.Fragment>
        );
    }
}
const mapStateToProps = (state) => {
    const { user, loading, error } = state.Auth;
    const { dateRange } =  state.Options;
    return { user, loading, error, dateRange };
};
export default connect(mapStateToProps)(CallDetail);
