import React, {Component, useState  } from 'react';
import { Row, Col, Button,  UncontrolledPopover, PopoverBody } from 'reactstrap';
import { servicePost } from "./../../helpers/api";
// const Action = ({ rowID, rowEdit }) => {
class AgentAction extends Component{
    constructor(props){
        super(props);
        this.superheroElement = React.createRef();

        console.log('action props',this.props);
        
    }
    render(){
        var rowID ='';
        if( this.props.rowID ){
            rowID = this.props.rowID
        }
        return(
            <table class="actionTbl">
                {this.props.type == 'library' && <React.Fragment>
                <tr>
                    <td>
                        <a style={{color: '#4B4B5A'}} href={`/analyse/calls/${this.props.rowID}`} target="_blank"  >                            
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="ml-2" style={{cursor: 'pointer', float: 'right'} }><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                        </a>
                    </td>
                    <td> <span id={this.props.rowIndex}> <i className="uil uil-trash-alt"></i> </span> 
                        <UncontrolledPopover placement='top' id={this.props.rowIndex} target={this.props.rowIndex} trigger='legacy'>
                            <PopoverBody>
                                <Row>
                                    <Col md={12}>                                        
                                        <span style={{ fontWeight: 'bold' }}>
                                            {`${(this.props.deleteMesg )? this.props.deleteMesg : 'Are you sure to delete this agent?' }`}
                                        </span>
                                    </Col>
                                </Row>
                                <Row style={{ float: 'right' }}>
                                    <div>
                                        <Button className='btn btn-info btn-sm'>No</Button>&nbsp;&nbsp;
                                        <Button onClick={()=> this.props.deleteRow(this.props)} className='btn btn-danger btn-sm'>Yes</Button>
                                    </div>
                                </Row>
                            </PopoverBody>
                        </UncontrolledPopover>
                    </td>
                </tr>
                </React.Fragment>}
                {this.props.type != 'library' && <React.Fragment>
                <tr>
                    <td>
                        <span onClick={ () => this.props.rowEdit(this.props.rowID) } >                            
                            <i className="uil uil-edit"></i>
                        </span>
                    </td>
                    <td> <span id={this.props.rowIndex}> <i className="uil uil-trash-alt"></i> </span> 
                        <UncontrolledPopover placement='top' id={this.props.rowIndex} target={this.props.rowIndex} trigger='legacy'>
                            <PopoverBody>
                                <Row>
                                    <Col md={12}>                                        
                                        <span style={{ fontWeight: 'bold' }}>
                                            {`${(this.props.deleteMesg )? this.props.deleteMesg : 'Are you sure to delete this agent?' }`}
                                        </span>
                                    </Col>
                                </Row>
                                <Row style={{ float: 'right' }}>
                                    <div>
                                        <Button className='btn btn-info btn-sm'>No</Button>&nbsp;&nbsp;
                                        <Button onClick={()=> this.props.deleteRow(this.props.rowID)} className='btn btn-danger btn-sm'>Yes</Button>
                                    </div>
                                </Row>
                            </PopoverBody>
                        </UncontrolledPopover>
                    </td>
                </tr>
                </React.Fragment>}
            </table>
        );
    }
}

export default AgentAction;