import AvField from 'availity-reactstrap-validation/lib/AvField';
import AvForm from 'availity-reactstrap-validation/lib/AvForm';
import React,{Component} from 'react';
import Loader from '../../components/Loader';
import ReactPaginate from 'react-paginate';
import { Modal, ModalFooter, Col, ModalBody, ModalHeader, Row, Button, Table,CustomInput } from 'reactstrap';
import { getLoggedInUser } from '../../helpers/authUtils';
import { serviceGet, servicePost,servicePut } from './../../helpers/api';

import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import { toast } from 'react-toastify';
class PaymentStatus extends Component
{
        constructor(props) {
        super(props);

        this.state = {
            user: getLoggedInUser(),
            modal: false,
            loading: true,
            pageLoading: false,
            paymentStatusList: [],
            name:'',
            paymentStatusId:null,
            currentPage: 1,
            size: 3,
            pageCount:1,
            statusName: null,
            description: null,
        };
        this.toggle = this.toggle.bind(this);
        this.getPaymentStatusList= this.getPaymentStatusList.bind(this);
        this.createPaymentStatus= this.createPaymentStatus.bind(this);
        this.changePage = this.changePage.bind(this);
        this.switchPaymentStatus = this.switchPaymentStatus.bind(this);
    }
    
    componentDidMount() {     
        this.getPaymentStatusList();
    }

    getPaymentStatusList = () => {
        this.setState({
            paymentStatusList: [],
            loading: true
        })
        console.log(this.state.searchName);
        let url = `api/v1/payment/search?page=${this.state.currentPage}&size=${this.state.size}`;
        serviceGet(url,{
             'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
        .then((res) => {
              if(res.data) {
                this.setState({
                    paymentStatusList: res.data.responseObject,
                    pageCount: res.data.totalElements < 3 ? 1 : Math.ceil(res.data.totalElements / 3),
                    loading: false
                })
             }
        }).catch((error) => {
            console.log(error);
            this.setState({
                 loading: false
            })
        });
    }

    switchPaymentStatus = (paymentStatus) => {
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };

        this.setState({
            loading: true
        })

        if(paymentStatus._id) {
            servicePut(
                    `api/v1/payment/${paymentStatus._id}/switch?isEnabled=${!paymentStatus.isEnabled}`, '', headers)
            .then((res) => {
                if(res.data) {
                    this.setState({
                        loading: false,
                    }, () => this.getPaymentStatusList());
                    toast('Payment Status updated successfully', {bodyClassName: 'success-toast'});
                } else {
                    toast(res.error, {bodyClassName: 'error-toast'});
                }
            })
            .catch((err) => {
                console.log(err)
                this.setState({
                    loading: false
                })
                toast('Some error occurred', {bodyClassName: 'error-toast'});
            })
        }
    }


    createPaymentStatus = () => {
        if(this.state.statusName === null || this.state.description === null) {
            toast('Please fill all the fields.', {bodyClassName: 'error-toast'});
            return;
        }

        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        let paymentStatus = {
            'statusName': this.state.statusName,
            'description': this.state.description,
        }
        this.setState({
            pageLoading: true
        })

        if(this.state.paymentStatusId) {
            servicePut(
                    `api/v1/payment/${this.state.paymentStatusId}`,
                    JSON.stringify(paymentStatus), headers)
            .then((res) => {
                if(res.data) {
                    this.setState({
                        statusName: null,
                        description: null,
                        pageLoading: false,
                        paymentStatusId: null
                    }, () => this.getPaymentStatusList());
                    toast('Payment Status updated successfully', {bodyClassName: 'success-toast'});
                } else {
                    toast(res.error, {bodyClassName: 'error-toast'});
                }
            })
            .catch((err) => {
                console.log(err)
                this.setState({
                    pageLoading: false
                })
                toast('Some error occurred', {bodyClassName: 'error-toast'});
            })
        } else {
            servicePost('api/v1/payment',JSON.stringify(paymentStatus),headers)
            .then((res) => {
                if(res.data) {
                        this.setState({
                            statusName: null,
                            description: null,
                            pageLoading: false
                        }, () => this.getPaymentStatusList());
                    toast('Payment Status created successfully',{bodyClassName:'success-toast'});
                } else {
                    toast(res.error, {bodyClassName: 'error-toast'});
                }
            })
            .catch((err) => {
                console.log(err)
                this.setState({
                    pageLoading: false
                })
                toast('Some error occurred', {bodyClassName: 'error-toast'});
            })
        }
    }

    toggle = (modal, paymentStatus) => {
        if(paymentStatus != null) {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                paymentStatusId: paymentStatus._id,
                statusName: paymentStatus.statusName,
                description: paymentStatus.description,
            }))
        } else {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                paymentStatusId: null,
                statusName: null,
                description: null,
            }))
        }
    };


    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });
    }

    changePage = ({selected})=>{
        this.setState({
            currentPage: selected + 1,
            paymentStatusList: []
        }, () => { this.getPaymentStatusList() });
     }
    
    render() {
        const paymentStatusColumn = [
            // {
            //     dataField: '_id',
            //     text: <CustomInput type="checkbox"/>,
            //     formatter : (cell,row,index)=>{
            //       return (<React.Fragment><CustomInput className="rowCheckbox" type="checkbox" id={row._id}/></React.Fragment>)
            //     }
            // },
            {
                dataField: 'paymentStatusId',
                text: 'No',
                // sort: true,
            },
            {   
                dataField: 'statusName',
                text: 'Status Name',
                // sort : true
            },
            {   
                dataField: 'description',
                text: 'Description',
                // sort : true
            },
            {   
                dataField: 'isEnabled',
                text: 'Action',
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <Row>
                                <Col md={3} className="p-0 m-0">
                                    <span className="transparent-toggle-button">
                                        <CustomInput 
                                            type="switch"
                                            defaultChecked={cell} 
                                            id={rowIndex}
                                            // name={tab.value}
                                            onChange={e => {this.switchPaymentStatus(row)}}
                                            label=""/>
                                    </span>
                                </Col>
                                <Col md={3} className="p-0 m-0">
                                    <span className="text-success pl-1"><i className="uil uil-edit" onClick={(e) => {this.toggle('editAffiliate',row);}}></i></span>
                                </Col>
                            </Row>
                        </React.Fragment>)
                }
            },
        ]
        return (
             <React.Fragment>{ this.state.pageLoading ? <Loader/> : <>
                <div className="container-fluid">
                    <div className="card mt-4">
                        <div className="card-header page-heading pt-4 pb-3">
                            <AvForm onValidSubmit={this.createPaymentStatus}>
                                <Row>
                                    <Col md={12}>
                                            <h3 className="text-dark">Payment Status</h3>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Status Name</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="statusName" type="text" required placeholder="Enter Status Name" autoComplete="false" value={this.state.statusName} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Description</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="description" type="text" required placeholder="Enter Description" autoComplete="false" value={this.state.description} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={12} className="align-center my-3">
                                        <button className="btn btn-outline-primary btn-lg px-5">{this.state.paymentStatusId != null ? 'UPDATE' : 'ADD'}</button>
                                    </Col>
                                </Row>
                            </AvForm>
                        </div>
                    </div>
                </div>
            <div className="container-fluid">
                <div className="card shadow mt-4">
                    <div className="card-header page-heading pt-4 pb-3">
                        <div className="row">
                            <div className="col-md-12">
                                    <h3 className="text-dark">List of Payment Status</h3>
                            </div>
                        </div>
                    </div>
                    <div className="card-body p-0">    
                    <ToolkitProvider
                        bootstrap4
                        keyField="id"
                        data={this.state.paymentStatusList}
                        columns={paymentStatusColumn}
                        // search
                        // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                        >
                        {props => (
                            <React.Fragment>
                                <BootstrapTable
                                    {...props.baseProps}
                                    bordered={false}
                                    wrapperClasses="table-responsive pl-3 pr-3"
                                    noDataIndication={ this.state.loading ? <Loader/> : 'No Data Found'}
                                />
                            </React.Fragment>
                        )}
                    </ToolkitProvider>   
                    </div>
                </div>
                <div className="row">
                    <div className="text-nowrap mt-4">
                        <ReactPaginate previousLabel={"Previous"} 
                            pageCount={this.state.pageCount}
                            nextLabel={"Next"} 
                            onPageChange={this.changePage} 
                            containerClassName={"paginationBttns"}
                            previousLinkClassName={"previousBttn"} nextLinkClassName={"nextBttn"}
                            activeLinkClassName={"paginationActive"} disabledClassName={"paginationDisabled"}>
                        </ReactPaginate>
                    </div>
                </div>
                {/* <Modal
                    isOpen={this.state.modal}
                    toggle={this.toggle}
                    className={this.state.className}
                    size='lg'>
                        <div><ModalHeader toggle={this.toggle}>Update Affiliate Information</ModalHeader>
                         <AvForm onValidSubmit={this.createPaymentStatus}>
                            <ModalBody>
                                <Row>
                                    <Col md={6} className="mt-3">
                                        <label>Commission Fee (Personnage %)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="statusName" type="text" required placeholder="Enter Commission Fee" autoComplete="false" value={this.state.statusName} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Trainer commission fee (Personnage %)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="description" type="text" required placeholder="Enter Trainer Commission Fee" autoComplete="false" value={this.state.description} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Up line fee (Personage %)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="upLineFee" type="text" required placeholder="Enter UpLine Fee" autoComplete="false" value={this.state.upLineFee} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Expansion level (N-1)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="expansionLevel" type="text" required placeholder="Enter Level" autoComplete="false" value={this.state.expansionLevel} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                </Row>
                            </ModalBody>
                            <ModalFooter>
                                <button className="btn btn-outline-primary btn-lg">Update</button>
                                <button className="btn btn-outline-danger btn-lg" onClick={this.toggle}>Cancel</button>
                            </ModalFooter>
                          </AvForm> 
                       </div>
                </Modal> */}
            </div> </>
            }
            </React.Fragment>
        )
    }
}
export default PaymentStatus;