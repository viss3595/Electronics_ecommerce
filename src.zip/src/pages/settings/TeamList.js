import React, { Component } from 'react';
import { Row, Col, Card, CardBody, Input, UncontrolledDropdown, DropdownMenu, DropdownItem, DropdownToggle, Button,  UncontrolledPopover, PopoverBody, Modal, ModalHeader, ModalBody, ModalFooter,Badge,
    UncontrolledTooltip, } from 'reactstrap';
import BootstrapTable from 'react-bootstrap-table-next';
import ToolkitProvider, { Search, CSVExport } from 'react-bootstrap-table2-toolkit';
import paginationFactory from 'react-bootstrap-table2-paginator';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import { servicePost } from "./../../helpers/api";
import PageTitle from '../../components/PageTitle';
import AddModal from './AddModal';
import { connect } from 'react-redux';
import Loader from '../../components/Loader';
import TableAction from './tableAction';
import AddTeam from '../forms/settings/AddTeam';
import { dateFormat, capitalize } from './../../helpers/common';
import SlidingPanel from 'react-sliding-side-panel';

const sizePerPageRenderer = ({ options, currSizePerPage, onSizePerPageChange }) => (
    <React.Fragment>
        <label className="d-inline mr-1">Show</label>
        <Input type="select" name="select" id="no-entries" className="custom-select custom-select-sm d-inline col-2"
            defaultValue={currSizePerPage}
            onChange={(e) => onSizePerPageChange(e.target.value)}>
            {options.map((option, idx) => {
                return <option key={idx}>{option.text}</option>
            })}
        </Input>
        <label className="d-inline ml-1">entries</label>
    </React.Fragment>
);

const TableWithSearch = (props) => {
    console.log(props
        );
    const { SearchBar } = Search;
    const records = props.records
    
    const columns = [
        // {
        //     dataField: '_id',
        //     text: 'S No.',
        //     sort: true,
        //     formatter: (cell, row, rowIndex) => (
        //         <React.Fragment>
        //             {rowIndex+1}
        //             {/* <div>{`${records[rowIndex].to}`}</div> <div>{records[rowIndex].from}</div> */}
        //         </React.Fragment>
        //     ),
        // },
        {
            dataField: 'teamName',
            text: 'Team Name',
            style: { width: '10%' },
            sort: true,
        },
        {
            dataField: 'teamLead',
            text: 'Team Lead',
            sort: false,
            style: { width: '10%' },
        },
        {
            dataField: 'teamData',
            text: 'Agents in the team',
            sort: true,
            style: { width: '60%' },
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                    {cell != null && <React.Fragment>
                        {cell.map((value, index) => {
                            return (
                                <Badge
                                key={rowIndex}
                                id={`tag-${index}`}
                                color={`soft-secondary`}
                                className="mr-1 mt-1 badge font-weight-500 font-size-14">
                                    {cell[index].name}
                                    <UncontrolledTooltip placement="top" target={`tag-${index}`}>
                                        {cell[index].name}
                                    </UncontrolledTooltip>
                                </Badge>
                            )
                            
                        })
                    }
                    <Badge
                                onClick={(e) => {
                                    props.editDataRow(row._id)
                                }}
                                key={`ele${row._id}`}
                                id={`ele${row._id}`}
                                color={`soft-secondary`}
                                className="mr-1 mt-1 badge font-weight-500 font-size-14">
                                    +
                                    <UncontrolledTooltip placement="top" target={`ele${row._id}`}>
                                        Add Agents
                                    </UncontrolledTooltip>
                    </Badge>
                    {/* <a href="javascript:void()" onClick={this.editDataRow.bind(this)} >Add more agents</a> */}
                </React.Fragment>}
                    
                </React.Fragment>
            ),
        },
        {
            dataField: 'createdAt',
            text: 'Date Created',
            sort: false,
            style: { width: '10%' },
            // headerStyle: { display: 'none' },
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                {   dateFormat(row.createdAt) }
                </React.Fragment>
            ),
        },
        {
            dataField: 'updatedAt',
            text: 'Last Modified',
            sort: false,
            style: { width: '10%' },
            formatter: (cell, row, rowIndex) => (
                <React.Fragment>
                {   dateFormat(row.updatedAt) }
                </React.Fragment>
            ),
        },
        {
            dataField: 'actions',
            text: 'Actions',
            sort: false,
            formatter : (cell,row, rowIndex) => (
                <React.Fragment>
                    <div style={{display : "flex"}}>
                    {cell}
                    {/* <i className="uil uil-eye pl-3" onClick={(e) => props.toggleSlider(records[rowIndex].feedbackData[0]._id)}></i> */}
                    </div>
                    
                </React.Fragment>
            )
        },
    ];
    
    const defaultSorted = [
        {
            dataField: 'updatedAt',
            order: 'desc',
        },
    ];
    

    const isModal = () => {
        props.newdata()
    }

    if(props.isData == false){
        return (
            <Card>
                <CardBody>
                    <Row>
                        <Col md={12} style={{ textAlign: 'center' }}>
                            <div>
                                <AddModal modalView={isModal.bind(this)} btnStyle={'center'} buttonName={'Create a Team'} modalType={ 'team' } modalTitle={'Create a new Team'} isFooter={ 'false' } />
                            </div>
                            
                        </Col>
                    </Row>
                </CardBody>
            </Card>
        )
    }
    if(props.isData){
        return (
            <Card>
                <CardBody>
                    <ToolkitProvider
                        bootstrap4
                        keyField="id"
                        data={records}
                        columns={columns}
                        // search
                        // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                        >
                        {props => (
                            <React.Fragment>
                                <Row>
                                    <Col>
                                        <SearchBar {...props.searchProps} />
                                    </Col>
                                    <Col style={{ float: 'right' }}>
                                        <AddModal modalView={isModal.bind(this)} btnStyle={'right'} buttonName={'Create a Team'} modalType={ 'team' } modalTitle={'Create a new Team'} isFooter={ 'false' } />
                                    </Col>
                                </Row>

                                <BootstrapTable
                                    {...props.baseProps}
                                    bordered={false}
                                    defaultSorted={defaultSorted}
                                    pagination={paginationFactory({ sizePerPage: 10, sizePerPageRenderer: sizePerPageRenderer, sizePerPageList: [{ text: '5', value: 5, }, { text: '10', value: 10 }, { text: '25', value: 25 }] })}
                                    wrapperClasses="table-responsive"
                                />
                            </React.Fragment>
                        )}
                    </ToolkitProvider>
                </CardBody>
            </Card>
        );
    }
};

class Tables extends Component {
    constructor(props) {
        super(props);

        this.state = {
            modal: false,
            records: [],
            loading : true,
            isDataAvailable: false,
            isFeedbackHidden: false,
            formId: null   
        };

        this.editDataRow.bind(this)

        this.toggle = this.toggle.bind(this);
        this.openModalWithSize = this.openModalWithSize.bind(this);
        this.openModalWithClass = this.openModalWithClass.bind(this);
        this.toggleSlider = this.toggleSlider.bind(this);

        this.headers= {
            "Content-Type": 'application/json',
            "Authorization": 'JWT '+this.props.user.token,
        }
    }

    toggleSlider = (formId) => {
        this.setState({
            isFeedbackHidden: !this.state.isFeedbackHidden,
            formId: formId
        });
    };

    reloadData = () =>{
        this.getAllTeam();
    }

    /**
     * Show/hide the modal
     */
    toggle = () => {
        this.setState(prevState => ({
            modal: !prevState.modal,
        }));
    };

    /**
     * Opens large modal
     */
    openModalWithSize = size => {
        this.setState({ size: size, className: null });
        this.toggle();
    };

    /**
     * Opens modal with custom class
     */
    openModalWithClass = className => {
        this.setState({ className: className, size: null });
        this.toggle();
    };

    /**GET TEAM LIST */
    getAllTeam = async () => {
        try{
            servicePost('team/getTeams',{},this.headers)
                .then((res) => {
                    if(res.status == 1){

                        for (let j = 0; j < res.data.length; j++) {
                            const ele = res.data[j];
                            ele.actions = <TableAction
                            rowIndex={'btn-'+j}
                            actionType={'team'}
                            rowID={ele._id}
                            reload={this.reloadData}
                            rowEdit={this.editDataRow.bind(this)}
                            countLength={ele.assignedAgent}
                            deleteMesg={`This team is assigned to ${(ele.assignedAgent !=null )?ele.assignedAgent.length:['']} agents. You would need to assign them a new team from “Manage Agents” section.`}
                            // deleteRow={this.deleteTableRow.bind(this)}
                            />
                            
                        }

                        this.setState({
                            records: res.data,
                            loading: false,
                        })
                        if( res.data.length > 0 ){
                            this.setState({
                                isDataAvailable: true,
                            })
                        }

                        if( res.data.length == 0 ){
                            this.setState({
                                isDataAvailable: false,
                            })
                        }                    }
                })
                .catch((err)=> {
                    console.log(err);
                })
            }catch(err){
                console.log(err);
            }
    }

    componentDidMount = () => {
        this.getAllTeam()
    }

    newView = () =>{
        this.getAllTeam();
    }

    editDataRow= async (rowID)=>{       
        // alert(rowID) 
        try{
            await  servicePost('team/getTeamByID',{ id: rowID },this.headers)
            .then((res) => {
                console.log('edir row===',res.data[0])



                // this.toggle();
                this.setState({
                    teamIDdata: res.data[0],
                    modal: true,
                    modalType: 'agent',
                    modalTitle: 'Edit information of '+res.data[0].teamName,
                    isFooter: false,
                    buttonName: 'Update Team',
                    // modal: !prevState.modal,
                })
            })
            .catch((err)=> {
                console.log(err);
            })
        }catch(err){
            console.log(err);
        }
    }

    

    render () {
        if(this.state.loading){
            return <React.Fragment>
                <Row>
                    <Col md={12} className="page-title mt-2">
                        <Loader/>
                    </Col>
                </Row>
            </React.Fragment>
        }
    return (
        <React.Fragment>
                <Row className="page-title">
                    <Col md={12}>
                        <PageTitle
                            breadCrumbItems={[
                                { label: 'Settings', path: '/setting/teams' },
                                { label: 'Teams', path: '/setting/teams', active: true },
                            ]}
                            title={'Teams Manager'}
                        />
                        <div className="subtitle-heading">Create teams & assign agents from this screen.</div>
                    </Col>
                </Row>
                <Row>
                    <Col className="col-12">
                        <TableWithSearch  toggleSlider={this.toggleSlider} editDataRow={this.editDataRow} isData={this.state.isDataAvailable} records={this.state.records} newdata={ this.newView.bind(this) }/>
                    </Col>
                </Row>
                <Modal
                    isOpen={this.state.modal}
                    toggle={this.toggle}
                    className={this.state.className}
                    size={this.state.size}>
                    <ModalHeader toggle={this.toggle}>{ this.state.modalTitle }</ModalHeader>
                    <ModalBody>
                            <AddTeam  toggle={this.toggle} view={this.reloadData.bind(this)}  data={ this.state.teamIDdata } bName = { this.state.buttonName }/>
                    </ModalBody>                    
                </Modal>
                <SlidingPanel
                    panelClassName="slider-panel"
                    type={'right'}
                    isOpen={this.state.isFeedbackHidden}
                    size={50}>
                    
                </SlidingPanel>
        </React.Fragment>
        );
    }
};

// export default Tables;

const mapStateToProps = (state) => {
    // const { user, loading, error } = state.Auth;
    return state.Auth;
};
export default connect(mapStateToProps)(Tables);