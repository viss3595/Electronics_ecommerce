import AvField from 'availity-reactstrap-validation/lib/AvField';
import AvForm from 'availity-reactstrap-validation/lib/AvForm';
import AvGroup from 'availity-reactstrap-validation/lib/AvGroup';
import React,{Component} from 'react';
import Loader from '../../components/Loader';
import {Link} from 'react-router-dom';
import Select from 'react-select';
import { Modal,ModalFooter,Col,ModalBody,ModalHeader,Row,Button, Table, CustomInput } from 'reactstrap';
import Label from 'reactstrap/lib/Label';
import { getLoggedInUser } from '../../helpers/authUtils';
import { dateFormat } from '../../helpers/common';
import { serviceGet, servicePost,servicePut } from './../../helpers/api';
import ReactPaginate from 'react-paginate';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import moment from 'moment';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import BootstrapTable from 'react-bootstrap-table-next';
import { toast } from 'react-toastify';
const Swal = require('sweetalert2')
const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })
class Customer extends Component
{
        constructor(props) {
        super(props);

        this.state = {
            user: getLoggedInUser(),
            modal: false,
            loading: true,
            pageLoading: false,
            customerList: [],
            name:'',
            customerId:null,
            idCard:'',
            phoneNumber:0,
            seller:'',
            currentPage:0,
            size:10,
            pageCount:1,
            sellers:[],
            searchName: '',
            startDate: null,
            endDate:null,
            pageNo : 1,
            selectCustomers : []
        };
        this.toggle = this.toggle.bind(this);
        this.getCustomerList= this.getCustomerList.bind(this);
        this.createCustomer= this.createCustomer.bind(this);
        this.getSellers= this.getSellers.bind(this);
        this.onChangeSeller = this.onChangeSeller.bind(this);
        this.getExportData = this.getExportData.bind(this);
    }
    
    componentDidMount(){     
        this.getCustomerList();
    }

    getCustomerList = (keyword = null,pageno = null) =>{
        this.setState({
            customerList: [],
            loading: true
        })
        if(pageno == null){
            pageno = this.state.currentPage;
        }
        let url = `api/v1/customer/list?keyword=${this.state.searchName}&page=${this.state.page}&size=${this.state.size}
        &sortBy=${this.state.sortBy}
        &orderBy=${this.state.orderBy}`;
        if(this.state.startDate && this.state.endDate){
          url+= `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
        }else if(this.state.startDate && (!this.state.endDate)){
          url+= `&startDate=${this.state.startDate}`;
        }else if(this.state.endDate && (!this.state.startDate)){
          url+= `&endDate=${this.state.endDate}`;
        }
        serviceGet(url,{
             'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
        .then((res)=>{
              if(res.data){
                this.setState({
                    page : (pageno == null ? 0 : pageno) + 1, 
                    currentPage : pageno == null ? 0 : pageno,
                    customerList: res.data.responseObject,
                    pageCount: res.data.totalElements <10 ? 1 : Math.ceil(res.data.totalElements / 10),
                    loading: false
                })
             }
        }).catch((error) => {
            console.log(error);
            this.setState({
                 loading: false
            })
        });
    }

    createCustomer = () =>{
        if(this.state.seller === null || this.state.seller === undefined || this.state.seller === ""){
            toast('Please add seller.',{bodyClassName:'error-toast'});
            return;
        }
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        let customer={
          'name':this.state.name,
          "phoneNumber": this.state.phoneNumber,
          "seller": this.state.seller.value,
          "idCard": this.state.idCard
        }
        if(this.state.customerId){
          servicePut(`api/v1/customer/${this.state.customerId}`,
          JSON.stringify(customer),
          headers,)
          .then((res)=>{
              if(res.data){
                this.toggle();
                toast('Customer updated successfully',{bodyClassName:'success-toast'});
                this.getCustomerList();
                }
         });
        }else{
        servicePost('api/v1/customer',JSON.stringify(customer),headers)
            .then((res)=>{
                if(res.data){
                    this.toggle();
                    toast('Customer created successfully',{bodyClassName:'success-toast'});
                    this.getCustomerList();
                }
            });
        }
    }

    toggle = (modal, customer) => {
        if(customer != null) {
            let seller = {
                'label':customer.seller?.name,
                'value':customer.seller?._id
            }
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                customerId:customer._id,
                name: customer.name,
                phoneNumber:customer.phoneNumber,
                idCard:customer.idCard,
                seller:seller
            }))
        } else {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                customerId:null,
                name: '',
                phoneNumber:null,
                idCard:null,
                seller:''
            }))
        }
    };

    getSellers=(seller)=>{
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        if(seller.length > 0){
       serviceGet(`api/v1/agent/list?name=${seller}&page=${1}&size=${10}`,headers)
          .then((res)=>{
              let sellerObj=[];
              for(var i=0;i<res.data.responseObject.length;i++){
                  sellerObj.push({
                      'value':res.data.responseObject[i]._id,
                      'label':res.data.responseObject[i].name
                  });
              }
            //   if(res.data){
                this.setState({
                    sellers: sellerObj
                });
            //  }
         });
      }
    }

    onChangeSeller = async (selectedValue) =>{
        this.setState({
            seller:selectedValue
        });
    }

    handleChange = (event) => {
        if(event.target.name === 'startDate' || event.target.name === 'endDate'){
          let date = new Date(event.target.value);
          date.setHours(0,0,0,0);
          this.setState({
            [event.target.name]: date.toISOString()
          },()=>{
            this.setState({page :1},()=>{
                if(this.state.startDate != null && this.state.endDate != null){
                    this.getCustomerList();
                }
            });
          });

        }else{
        this.setState({
            [event.target.name]: event.target.value
        });
       }
    }

    searchByName = (keyword) =>{
        
        if(!keyword) {
            this.setState({
                searchName: ''
            }, () => this.getCustomerList())
        } else {
            let headers = {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.state.user.token
            };
            if(keyword.length >= 1) {
                this.setState({
                    customerList: [],
                    searchName: keyword,
                    loading: true
                })
                let url = `api/v1/customer/list?keyword=${this.state.searchName}&page=${1}&size=${this.state.size}
                &sortBy=${this.state.sortBy}
                &orderBy=${this.state.orderBy}`;
                if(this.state.startDate && this.state.endDate){
                url+= `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
                }else if(this.state.startDate && (!this.state.endDate)){
                url+= `&startDate=${this.state.startDate}`;
                }else if(this.state.endDate && (!this.state.startDate)){
                url+= `&endDate=${this.state.endDate}`;
                }
                //serviceGet(`api/v1/customer/list?keyword=${keyword}&page=${1}&size=${10}`,headers)
                serviceGet(url,headers)
                .then((res)=>{
                    if(res.data) {
                        this.setState({
                            page : 1, 
                            currentPage : 0,
                            loading: false,
                            customerList: res.data.responseObject,
                            pageCount: res.data.totalElements <10 ? 1 : Math.ceil(res.data.totalElements / 10)
                        });
                    }
                }).catch((error) => {
                    console.log(error);
                    this.setState({
                         loading: false
                    })
                });
            }
        }
    }

    changePage = ({selected}) => {
       this.setState({
           page : selected + 1,
           currentPage: selected,
           customerList : []
       },() => {this.getCustomerList()});
    }
    sortList = (sortBy,orderBy)=>{
        this.setState({
            sortBy : sortBy,
            orderBy : orderBy
        },()=>{
            this.getCustomerList();
        });
    }
    getExportData = (cutomerName = null, callback) => {
        this.setState({
            searchName: cutomerName
        })
        if (cutomerName == null) { cutomerName = "" }
        let url = `api/v1/customer/report/export?name=${cutomerName}&page=${this.state.page}&size=${this.state.size}`;
        if (this.state.startDate && this.state.endDate) {
            url += `&startDate=${this.state.startDate}&endDate=${this.state.endDate}`;
        } else if (this.state.startDate && (!this.state.endDate)) {
            url += `&startDate=${this.state.startDate}`;
        } else if (this.state.endDate && (!this.state.startDate)) {
            url += `&endDate=${this.state.endDate}`;
        }
        serviceGet(url, {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
            .then((res) => {
                if (res.data) {
                    console.log("DATA EX", res.data.responseObject);
                    callback(res.data.responseObject)
                    console.log(res.data.responseObject);
                }
            }).catch((error) => {
                console.log(error);
                this.setState({
                    loading: false
                })
            });
    }
    
    deleteSelectedCustomers = ()=>{
        Swal.fire({
            title: 'Are you sure?',
            // text: "You want to delete ",
            icon: 'warning',
            html: 'You want to delete selected customers',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
          }).then((result) => {
            if (result.isConfirmed) {
                
                let headers = {
                    'Content-Type': 'application/json',
                    Authorization: 'Bearer ' + this.state.user.token
                };
                let customersIds = {
                    ids : this.state.selectCustomers
                }
                this.setState({
                    pageLoading: true
                })
                servicePost('api/v1/customer/delete',customersIds,headers)
                .then((res) => {
                    if(res.data) {
                            this.setState({
                                pageLoading: false,
                                selectCustomers : []
                            }, () =>{
                                Toast.fire({
                                    icon: 'success',
                                    title: 'Delete customers successfully'
                                    
                                  });
                                  this.getCustomerList();
                            });
                    } else {
                        this.setState({
                            pageLoading: false
                        })
                    }
                })
                .catch((err) => {
                    console.log(err)
                    this.setState({
                        pageLoading: false
                    })
                    Toast.fire({
                        icon: 'error',
                        title: 'Some error occurred'
                      });
                })
 
            
            }
          })
         
    }
    render() {
        const MyExportCSV = (props) => {
            const handleClick = () => {
                this.getExportData(this.state.searchName, (responseObject) => {
                    props.onExport(responseObject);
                });
            };
            return (
                <div>
                    <button className="btn btn-sm btn-outline-success" onClick={handleClick}>
                        <i className="uil uil-file-download-alt mr-2"></i>
                        Export to CSV
                    </button>
                </div>
            );
        };
        const customerColumns = [
            // {
            //     dataField: '_id',
            //     text: <CustomInput type="checkbox"/>,
            //     formatter : (cell,row,index)=>{
            //       return (<React.Fragment><CustomInput className="rowCheckbox" type="checkbox" id={row._id}/></React.Fragment>)
            //     },
            //     csvExport: false,
            // },
            {
                dataField: 'customerId',
                text: 'Customer Id',
                // style: { width: '10%' },
                sort: true,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                
                dataField: 'name',
                text: 'Name',
                sort : true,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {
                dataField: 'phoneNumber',
                text: 'Number',
                sort : true,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {  
                dataField: 'idCard',
                text: 'ID Card',
                sort : true,
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            { 
                dataField: 'createdAt',
                text: 'Register Time/Date',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <div>{moment(cell).format('MM-DD-YYYY')}</div>
                        </React.Fragment>)
                },
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            {   
                dataField: 'seller.name',
                text: 'Lead of saler',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            {row.seller.name}
                        </React.Fragment>)
                },
                onSort: (field, order) => {
                    this.sortList(field,order);
                }
            },
            { 
                dataField: 'position',
                text: 'Action',
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment> 
                            <div className="text-success pl-4"><i className="uil uil-edit" onClick={(e) => {this.toggle('editCustomer',row);}}></i></div>
                        </React.Fragment>)
                },
                csvExport: false,
            },
        ]
        const selectRow = {
            mode: 'checkbox',
            clickToSelect: true,
            selectionHeaderRenderer: ({ indeterminate, ...rest }) => (
              <CustomInput
                type="checkbox" className="rowCheckbox"
                
                ref={ (input) => {
                  if (input) input.indeterminate = indeterminate;
                } }
                { ...rest }
              />
            ),
            selectionRenderer: ({ mode, ...rest }) => (
              <CustomInput className="rowCheckbox" type={ mode } { ...rest } />
            ),
            selected : this.state.selectCustomers,
            onSelect: (row, isSelect, rowIndex, e) => {
                    var selectedCustomersList = this.state.selectCustomers;
                    if(isSelect){
                        selectedCustomersList.push(row._id);
                        
                    }else{
                        selectedCustomersList = selectedCustomersList.filter(x=> x != row._id);
                    }
                    this.setState({
                        selectCustomers : selectedCustomersList
                    })
              },
              onSelectAll: (isSelect, rows, e) => {
                     var selectedCustomersList = this.state.selectCustomers;
                    if(isSelect){
                        var selectAllperPage = this.state.customerList.map((x)=>{return x._id;});
                        selectedCustomersList = selectedCustomersList.concat(selectAllperPage);
                    }else{
                        var dd = this.state.customerList.map((a)=>{return a._id;});
                        var tt = selectedCustomersList.filter(x=> dd.indexOf(x) < 0 );
                        
                        selectedCustomersList = tt;
                    }
                    this.setState({
                        selectCustomers : selectedCustomersList
                    })
              }
          };
      
        return (
             <React.Fragment>
                 { this.state.pageLoading ? <Loader/> : 
            <div className="container-fluid">
                <div className="card shadow mt-4">
                    <div className="card-header page-heading pt-4 pb-3">
                        <div className="row">
                            <div className="col-md-12">
                                <h3 className="text-dark">List of Customers</h3>
                            </div>
                            <div className="col-md-3 pt-3">
                                <div className="text-md-left dataTables_filter search-box-div" id="dataTable_filter">
                                  <i className="uil uil-search search-icon"></i>
                                  {/* <input type="search" id="searchByName" className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search" onChange={(event)=>{this.searchByName(event.target.value)}}/> */}
                                  <input type="search"  id="searchByName" value={this.state.searchName} className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search" onChange={(event)=>{
                                        this.setState({
                                            searchName : event.target.value
                                        },()=>{
                                            this.searchByName(this.state.searchName)
                                        })
                                    }}/>
                                </div>
                            </div>
                            <div className="col-md-3 pt-3">
                                <div className="input-group">
                                   <label className="mt-2 mr-1">Start Date</label>
                                   <input type="date" id="startDate" name="startDate" className="form-control date-box" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={this.handleChange}/>
                                </div>
                            </div>
                            <div className="col-md-3 pt-3">
                                <div className="input-group">
                                   <label className="mt-2 mr-1">End Date</label>
                                   <input type="date" id="endDate" name="endDate" className="form-control date-box" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" onChange={this.handleChange}/>
                                </div>
                            </div>
                            <div className="col-md-2 text-md-right pt-3">
                            { this.state.user.roles.indexOf('addCustomer') > -1 ?
                                <button type="button" className="btn btn-sm btn-primary px-3 py-2" onClick={(e) => {this.toggle();}}>Add Customer</button> : null
                            }
                            </div>
                            <div className="col-md-1 mt-2 font-size-20 pt-3">
                                <i className="uil uil-sync" onClick={(e)=>{
                                        this.setState({
                                            searchName : '',
                                            startDate : null,
                                            endDate : null,
                                            currentPage : 0,
                                            page:1
                                        },()=>{
                                            document.getElementById("startDate").value = "";
                                            document.getElementById("endDate").value = "";
                                            this.getCustomerList()
                                        })
                                    }}></i>
                            </div>
                        </div>
                    </div>
                    <div className="card-body p-0">       
                        <ToolkitProvider
                                bootstrap4
                                keyField="_id"
                                data={this.state.customerList}
                                columns={customerColumns}
                                exportCSV={{
                                    fileName: 'CustomerList_Report_' + Date.now() + '.csv',
                                }}
                                // search
                                // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                                >
                                {props => (
                                    <React.Fragment>
                                         <div className="grid-action-row border-top p-2 pl-4">
                                        
                                                 
                                                <div class="btn-group">
                                                {
                                                        this.state.selectCustomers != null && this.state.selectCustomers.length > 0 ? 
                                                            <button onClick={(e)=>{this.deleteSelectedCustomers()}} className="btn btn-sm btn-danger mr-2" >
                                                            <i className="uil uil-trash mr-2"></i>
                                                            Delete all selected customers ({this.state.selectCustomers.length})
                                                        </button> : <></>
                                                    }
                                                   
                                                    <MyExportCSV {...props.csvProps} />
                                                </div>
                                            </div>
                                        <BootstrapTable
                                            selectRow={ selectRow }
                                            {...props.baseProps}
                                            bordered={false}
                                            wrapperClasses="table-responsive pl-3 pr-3"
                                            noDataIndication={ this.state.loading ? <Loader/> : 'No Data Found'}
                                        />
                                    </React.Fragment>
                                )}
                            </ToolkitProvider>  
                    </div>
                </div>
                <div className="row">
                    <div className="text-nowrap mt-4">
                        {/* <div id="dataTable_length" className="dataTables_length" aria-controls="dataTable"><label>Show&nbsp;<select className="form-control form-control-sm custom-select custom-select-sm"><option value="10" selected="">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select>&nbsp;</label></div> */}
                        <ReactPaginate previousLabel={"Previous"} 
                            pageCount={this.state.pageCount}
                            nextLabel={"Next"} 
                            onPageChange={this.changePage} 
                            forcePage={this.state.currentPage}
                            containerClassName={"paginationBttns"}
                            previousLinkClassName={"previousBttn"} nextLinkClassName={"nextBttn"}
                            activeLinkClassName={"paginationActive"} disabledClassName={"paginationDisabled"}>
                        </ReactPaginate>
                    </div>
                </div>
                <Modal
                    isOpen={this.state.modal}
                    toggle={this.toggle}
                    className={this.state.className}
                    size='lg'>
                        <div><ModalHeader toggle={this.toggle}>{this.state.modalType === 'editCustomer'? 'Update Customer Information' : 'Create Customer Information'}</ModalHeader>
                         <AvForm onValidSubmit={this.createCustomer}>
                            <ModalBody>
                                <Row>
                                    <Col md={6}>
                                        <AvField name="name" label="Customer Name" type="text" required placeholder="Enter Customer Name" autoComplete="false" value={this.state.name} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6}>
                                        <AvField name="idCard" label="National Id Card" type="text" required placeholder="Enter National Id Card" autoComplete="false" value={this.state.idCard} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6}>
                                        <AvField name="phoneNumber" label="Phone Number" type="text" required placeholder="Enter Phone Number" autoComplete="false" value={this.state.phoneNumber} onChange={this.handleChange}
                                         onKeyPress={function(e){
                                            if (e.target.value.length >= 10 ) {
                                                e.preventDefault();
                                            }
                                         }}
                                         validate = {{
                                            minLength: {value: 8 ,errorMessage: 'Please enter valid phone number'},
                                            maxLength: {value: 10 ,errorMessage: 'Please enter valid phone number'},
                                           required: {value: true ,errorMessage: 'Please enter valid phone number'}
                                           }}/>
                                    </Col>
                                    <Col md={6}>
                                        <AvGroup row>
                                            <Col sm={12}>
                                                <Label for="example">Seller</Label>
                                                <Select
                                                  onInputChange={(value) => this.getSellers(value)}
                                                  onChange={this.onChangeSeller}
                                                  value={[{'value':this.state.seller?.value,'label':this.state.seller?.label}]}
                                                   // isMulti={true}
                                                   options={this.state.sellers}
                                                   className="react-select"
                                                   classNamePrefix="react-select"
                                                   placeholder={'Search seller'}
                                                 />
                                          </Col>
                                         </AvGroup>
                                    </Col>
                                </Row>
                            </ModalBody>
                            <ModalFooter>
                                <button className="btn btn-outline-primary btn-lg">{this.state.modalType === 'editCustomer'? 'Update' : 'Create'}</button>
                                <button className="btn btn-outline-danger btn-lg" onClick={this.toggle}>Cancel</button>
                            </ModalFooter>
                          </AvForm> 
                       </div>
                </Modal>
            </div>}
            </React.Fragment>
        )
    }
}
export default Customer;