import { AvForm, AvGroup, AvField } from 'availity-reactstrap-validation';
import { Table } from 'reactstrap'
import React,{ Component } from 'react';
import ReactPaginate from 'react-paginate';
import Select from 'react-select';
import InputMask from 'react-input-mask';
import { Modal, ModalFooter, Col, ModalBody, ModalHeader,Input, Row, Button, CustomInput } from 'reactstrap';
import { getLoggedInUser } from '../../helpers/authUtils';
import { dateFormat } from '../../helpers/common';
import { serviceGet, servicePost, servicePut, serviceDelete } from './../../helpers/api';
import Loader from '../../components/Loader';
import moment from 'moment';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import { toast } from 'react-toastify';
const Swal = require('sweetalert2')
const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })
class User extends Component
{
        constructor(props) {
        super(props);

        this.state = {
            user: getLoggedInUser(),
            modal: false,
            loading: true,
            pageLoading: false, 
            userList: [],
            firstName: '',
            lastName: '',
            phoneNumber: 0,
            email: '',
            password: null,
            role: null,
            roles: [],
            userId: null,
            size: 'lg',
            modalType: null,
            currentPage: 1,
            size: 10,
            pageCount: 1,
        };
        this.toggle = this.toggle.bind(this);
        this.getUserList= this.getUserList.bind(this);
        this.createAndUpdateUser= this.createAndUpdateUser.bind(this);
        this.getRoles= this.getRoles.bind(this);
        this.onChangeRole = this.onChangeRole.bind(this);
        this.deleteUser = this.deleteUser.bind(this);
        this.changePage = this.changePage.bind(this);
    }
    
    componentDidMount(){     
        this.getUserList();
    }

    getUserList = () =>{
        this.setState({
            userList: [],
            loading: true
        })
        serviceGet(`api/v1/user/search?page=${this.state.currentPage}&size=${this.state.size}`,{
             'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
        .then((res)=>{
              if(res.data){
                this.setState({
                    userList: res.data,
                    pageCount: res.totalElements < 10 ? 1 : Math.ceil(res.data.totalElements / 10),
                    loading: false
                })
             }
        }).catch((error) => {
            console.log(error);
            this.setState({
                 loading: false
            })
        });
    }

    createAndUpdateUser = () =>{
        if(this.state.role === null || this.state.role === undefined || this.state.role === ""){
            toast('Please add role.',{bodyClassName:'error-toast'});
            return;
        }
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        console.log(this.state);
        let user = {
            firstName: this.state.firstName,
            lastName: this.state.lastName,
            phoneNumber: this.state.phoneNumber,
            email: this.state.email,
            password: this.state.password,
            roleId: this.state.role ? this.state.role.value: null 
        }
         if(this.state.password === null) {
            delete user.password;
        }
        if (this.state.userId) {
          let userId = this.state.userId;
          servicePut(`api/v1/user/${userId}`, JSON.stringify(user), headers)
          .then((res)=>{
              if(res.data){
                toast('User updated successfully',{bodyClassName:'success-toast'});
                this.getUserList();
                this.toggle();
             }else {
                toast(res.error,{bodyClassName:'error-toast'});
            }
         })
         .catch((err) => {
            console.log(err)
            toast('Some error occurred',{bodyClassName:'error-toast'});
         })
        } else {
            servicePost('api/v1/user', JSON.stringify(user), headers)
            .then((res)=>{
                if(res.data){
                    toast('User created successfully',{bodyClassName:'success-toast'});
                    this.getUserList();
                    this.toggle();
                } else {
                    toast(res.error,{bodyClassName:'error-toast'});
                }
            })
            .catch((err) => {
                console.log(err)
                toast('Some error occurred',{bodyClassName:'error-toast'});
            })
        }
    }

    toggle = (modal, user) => {
        if(user != null) {
            console.log(user);
             var role={
                'value':user.roleId?._id,
                'label':user.roleId?.roleName
            }
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                userId: user.userId,
                firstName: user.firstName,
                lastName: user.lastName,
                phoneNumber: user.phoneNumber,
                email: user.email,
                password: user.password,
                role: role
            }))
        } else {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                userId: null,
                firstName: '',
                lastName: '',
                phoneNumber: '',
                email: '',
                password: null,
                role: null
            }))
        }
    };

    getRoles = (role) => {
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        if(role.length > 0) {
            serviceGet(`api/v1/roles/search?name=${role}&page=${1}&size=${5}`, headers)
            .then((res) => {
                if (res.totalElements > 0 && res.data) {
                    let rolesObj = [];
                    for(var i = 0; i < res.data.length; i++){
                        rolesObj.push({
                            'value': res.data[i]._id,
                            'label': res.data[i].roleName
                        });
                    }
                    this.setState({
                        roles: rolesObj
                    }, () => {console.log(this.state.roles);});
             }
         });
      }
    }

    onChangeRole = async (selectedValue) => {
        this.setState({
            role: selectedValue
        });
    }

    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });
    }

    searchByName = (name) => {
        if (!name) {
            this.getUserList();
        } else {
            let headers = {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + this.state.user.token
            };
            if (name.length > 2) {
                this.setState({
                    loading: true
                })
                serviceGet(`api/v1/user/search?name=${name}&page=${1}&size=${10}`, headers)
                .then((res) => {
                    if (res.data) {
                        this.setState({
                            loading: false,
                            userList: res.data,
                            pageCount: res.totalElements < 10 ? 1 : Math.ceil(res.data.totalElements / 10),
                        });
                    }
                }).catch((error) => {
                    console.log(error);
                    this.setState({
                         loading: false
                    })
                });
            }
        }
    }

    // deleteUser = (userId) => {
    //     if (userId) {
    //         this.setState({
    //             loading: true
    //         })
    //         let headers = {
    //             'Content-Type': 'application/json',
    //             Authorization: 'Bearer ' + this.state.user.token
    //         };
    //         serviceDelete(`api/v1/user/${userId}/delete`, headers)
    //         .then((res) => {
    //             if (res.data) {
    //                 this.setState({
    //                     loading: false
    //                 })
    //                 this.getUserList();
    //             }
    //         });
    //     }
    // }

    changePage = ({selected}) => {
        this.setState({
            currentPage: selected + 1,
            userList: []
        },() => {this.getUserList()});
     }
     deleteUser = (id,name)=>{

        Swal.fire({
           title: 'Are you sure?',
           // text: "You want to delete ",
           icon: 'warning',
           html: 'You want to delete <b>'+name+'</b> User',
           showCancelButton: true,
           confirmButtonColor: '#3085d6',
           cancelButtonColor: '#d33',
           confirmButtonText: 'Yes, delete it!'
         }).then((result) => {
           if (result.isConfirmed) {
               this.setState({
                   pageLoading: true
               })
               let headers = {
                   'Content-Type': 'application/json',
                   Authorization: 'Bearer ' + this.state.user.token
               };
               serviceDelete('api/v1/user/'+id+'/delete',headers)
               .then((res) => {
                   if(res.data) {
                           this.setState({
                               pageLoading: false
                           }, () =>{
                               Toast.fire({
                                   icon: 'success',
                                   title: 'Delete user successfully'
                                 });
                                 this.getUserList();
                           });
                   } else {
                       this.setState({
                           pageLoading: false
                       })
                   }
               })
               .catch((err) => {
                   console.log(err)
                   this.setState({
                       pageLoading: false
                   })
                   Toast.fire({
                       icon: 'error',
                       title: 'Some error occurred'
                     });
               })

               Toast.fire({
                   icon: 'success',
                   title: 'Delete affiliate successfully'
                 })
           
           }
         })
        
    }
   
     handleKeyPress(e) {
        if(e.key === " "){
            e.preventDefault();
        }        
      }
    
    render() {

        const userColumn = [
            {
                dataField: '_id',
                text: <i className = "uil uil-square"></i>,
                formatter : (cell,row,index)=>{
                  return (<React.Fragment><CustomInput className="rowCheckbox" type="checkbox" id={row.userId}/></React.Fragment>)
                }
            },
            {
                dataField: 'serialUserId',
                text: 'User Id',
                // style: { width: '10%' },
                sort: true,
            },
            {   
                dataField: 'firstName',
                text: 'First Name',
                sort : true
            },
            {   
                dataField: 'lastName',
                text: 'Last Name',
                sort : true
            },
            {   
                dataField: 'phoneNumber',
                text: 'Number',
                sort : true
            },
            {   
                dataField: 'email',
                text: 'Email',
                sort : true
            },
            {   
                dataField: 'roleId.roleName',
                text: 'Role Name',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            {row.roleId.roleName}
                        </React.Fragment>)
                }
            },
            {
                dataField: 'createdAt',
                text: 'Create Time/Date',
                sort : true,
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <div>{moment(cell).format('MM-DD-YYYY')}</div>
                        </React.Fragment>)
                }
            },
            {   
                dataField: 'edit',
                text: 'Action',
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <span className="text-success pl-1"><i className="uil uil-edit" onClick={(e) => {this.toggle('editUser', row);}}></i></span>
                            <span className="text-danger pl-1"><i className="uil uil-glass-tea" onClick={() => this.deleteUser(row.userId,row.firstName)}></i></span>
                        </React.Fragment>)
                }
            }
        ]

        const selectRow = {
            mode: 'checkbox',
            clickToSelect: true
        };


        return (
             <React.Fragment>
                 { this.state.pageLoading ? <Loader/> : 
            <div className="container-fluid">
                <div className="card shadow mt-4">
                    <div className="card-header page-heading pt-4 pb-3">
                        <div className="row">
                            <div className="col-md-3">
                                    <h3 className="text-dark">User Management</h3>
                                </div>
                            <div className="col-md-3 pt-3">
                                <div className="text-md-left dataTables_filter search-box-div" id="dataTable_filter">
                                        <i className="uil uil-search search-icon"></i>
                                        <input type="search" className="form-control form-control-sm search-border" aria-controls="dataTable" placeholder="Search by name" onChange={(event)=>{this.searchByName(event.target.value)}}/>
                                </div>
                            </div>
                            {/* <div className="col-md-1 mt-3 font-size-16">
                                <i className="uil uil-sync" onClick={(e)=>{this.getUserList()}}></i>
                            </div> */}
                            <div className="col-md-6 text-md-right">
                                <button type="button" className="btn btn-sm btn-primary mt-2 float-right" onClick={(e) => {this.toggle();}}>Add User</button>
                            </div>
                        </div>
                    </div>
                    <div className="card-body p-0">     
                        <ToolkitProvider
                            bootstrap4
                            keyField="id"
                            data={this.state.userList}
                            columns={userColumn}
                                // search
                                // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                        >
                            {props => (
                                <React.Fragment>
                                    <BootstrapTable
                                        {...props.baseProps}
                                        bordered={false}
                                        wrapperClasses="table-responsive pl-3 pr-3"
                                        // selectRow={ selectRow }
                                        noDataIndication={ this.state.loading ? <Loader/> : 'No Data Found'}
                                    />
                                </React.Fragment>
                            )}
                        </ToolkitProvider>
                    </div>
                </div>
                <div className="row">
                    <div className="text-nowrap mt-4">
                        {/* <div id="dataTable_length" className="dataTables_length" aria-controls="dataTable"><label>Show&nbsp;<select className="form-control form-control-sm custom-select custom-select-sm"><option value="10" selected="">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select>&nbsp;</label></div> */}
                        <ReactPaginate previousLabel={"Previous"} 
                            pageCount={this.state.pageCount}
                            nextLabel={"Next"} 
                            onPageChange={this.changePage} 
                            containerClassName={"paginationBttns"}
                            previousLinkClassName={"previousBttn"} nextLinkClassName={"nextBttn"}
                            activeLinkClassName={"paginationActive"} disabledClassName={"paginationDisabled"}>
                        </ReactPaginate>
                    </div>
                </div>
                <Modal
                    isOpen={this.state.modal}
                    toggle={this.toggle}
                    className={this.state.className}
                    size="lg">
                        <div><ModalHeader toggle={this.toggle}>{this.state.modalType === 'editUser'? 'Edit User Manager' : 'Add User Manager'}</ModalHeader>
                         <AvForm onValidSubmit={this.createAndUpdateUser}>
                            <ModalBody>
                                <Row>
                                    <Col md={6}>
                                        <label>First Name</label> <span className="text-danger"><sup>*</sup></span>
                                        <AvField name="firstName" type="text" required placeholder="First Name" autoComplete="false" value={this.state.firstName} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6}>
                                    <label>Last Name</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="lastName" type="text" required placeholder="Last Name" autoComplete="false" value={this.state.lastName} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6}>
                                    <label>Phone</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="phoneNumber" type="number" required placeholder="Phone Number" autoComplete="false" value={this.state.phoneNumber} onChange={this.handleChange}
                                             onKeyPress={function(e){
                                                if (e.target.value.length >= 10 ) {
                                                    e.preventDefault();
                                                }
                                             }}
                                           validate = {{
                                                minLength: {value: 8 ,errorMessage: 'Please enter valid phone number'},
                                                maxLength: {value: 10 ,errorMessage: 'Please enter valid phone number'},
                                               required: {value: true ,errorMessage: 'Please enter valid phone number'}
                                               }}/>
                                    </Col>
                                    <Col md={6}>
                                    <label>Email</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="email" type="email" required placeholder="Email" autoComplete="false" value={this.state.email} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6}>
                                    <label>Password</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                    <span className="password-position">
                                        <AvField name="password" type="password" required={this.state.modalType !== 'editUser'} placeholder="Enter Password" autoComplete="new-password" value={this.state.password} onKeyPress={this.handleKeyPress} onChange={this.handleChange}
                                              validate={{
                                                pattern: {value: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/, errorMessage: 'Password must contain a lowercase letter, a uppercase letter, a number, a special character and minimum 8 characters'},
                                                required: {value: true, errorMessage: 'Please enter password'},
                                              }} />
                                    </span>
                                         {this.state.modalType === 'editUser'?<div className="mb-2 text-primary"><i className="uil uil-info-circle info-icon"></i><small>If filled,then existing password will be updated else leave blank</small></div>:''}
                                    </Col>
                                    <Col md={6}>
                                        <AvGroup row>
                                            <Col sm={12}>
                                                <label for="AssignRole" className="text-muted">Assign Role</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                                <Select
                                                    id="AssignRole"
                                                    onInputChange={(value) => this.getRoles(value)}
                                                    onChange={this.onChangeRole}
                                                    value={[{'value': this.state.role?.value,'label': this.state.role?.label}]}
                                                    options={this.state.roles}
                                                    className="react-select"
                                                    classNamePrefix="react-select"
                                                    placeholder={'Select a Role'}
                                                    validate = {{required: {value: true}}}
                                                 />
                                          </Col>
                                         </AvGroup>
                                    </Col>
                                </Row>
                            </ModalBody>
                            <ModalFooter>
                                <button className="btn btn-outline-primary btn-lg">{this.state.modalType === 'editUser'? 'Update' : 'Create'}</button>
                                <button className="btn btn-outline-danger btn-lg" onClick={this.toggle}>Cancel</button>
                            </ModalFooter>
                          </AvForm> 
                       </div>
                </Modal>
            </div>
            }
            </React.Fragment>
        )
    }
}
export default User;