import AvField from 'availity-reactstrap-validation/lib/AvField';
import AvForm from 'availity-reactstrap-validation/lib/AvForm';
import React,{Component} from 'react';
import Loader from '../../components/Loader';
import ReactPaginate from 'react-paginate';
import { Modal, ModalFooter, Col, ModalBody, ModalHeader, Row, Button, Table,CustomInput } from 'reactstrap';
import { getLoggedInUser } from '../../helpers/authUtils';
import { serviceDelete, serviceGet, servicePost,servicePut } from './../../helpers/api';

import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import { toast } from 'react-toastify';
const Swal = require('sweetalert2')
const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })
class Affiliate extends Component
{
        constructor(props) {
        super(props);

        this.state = {
            user: getLoggedInUser(),
            modal: false,
            loading: true,
            pageLoading: false,
            affiliateList: [],
            name:'',
            affiliateId:null,
            currentPage: 1,
            size: 3,
            pageCount:1,
            affiliateName: null,
            commissionFee: null,
            trainerCommissionFee: null,
            upLineFee: null,
            expansionLevel: null
        };
        this.toggle = this.toggle.bind(this);
        this.getAffiliateList= this.getAffiliateList.bind(this);
        this.createAffiliate= this.createAffiliate.bind(this);
        this.changePage = this.changePage.bind(this);
        this.switchAffiliate = this.switchAffiliate.bind(this);
    }
    
    componentDidMount() {     
        this.getAffiliateList();
    }

    getAffiliateList = () => {
        this.setState({
            affiliateList: [],
            loading: true
        })
        console.log(this.state.searchName);
        let url = `api/v1/affiliate?page=${this.state.currentPage}&size=${this.state.size}`;
        serviceGet(url,{
             'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        })
        .then((res) => {
              if(res.data) {
                  
                this.setState({
                    affiliateList: res.data.responseObject,
                    pageCount: Math.ceil(res.data.totalElements / this.state.size),
                    loading: false
                })
             }
        }).catch((error) => {
            console.log(error);
            this.setState({
                 loading: false
            })
        });
    }

    switchAffiliate = (affiliate) => {
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };

        this.setState({
            loading: true
        })

        if(affiliate._id) {
            servicePut(
                    `api/v1/affiliate/${affiliate._id}/switch?isEnabled=${!affiliate.isEnabled}`, '', headers)
            .then((res) => {
                if(res.data) {
                    this.setState({
                        loading: false,
                    }, () => this.getAffiliateList());
                    toast('Affiliate updated successfully', {bodyClassName: 'success-toast'});
                } else {
                    toast(res.error, {bodyClassName: 'error-toast'});
                    this.getAffiliateList();
                }
            })
            .catch((err) => {
                console.log(err)
                this.setState({
                    loading: false
                })
                toast('Some error occurred', {bodyClassName: 'error-toast'});
            })
        }
    }


    createAffiliate = () => {
        if(this.state.affiliateName === null || this.state.upLineFee === undefined ||
             this.state.expansionLevel === "" || this.state.trainerCommissionFee === null
             || this.state.commissionFee === null
             ) {
            toast('Please fill all the fields.', {bodyClassName: 'error-toast'});
            return;
        }

        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.state.user.token
        };
        let affiliate = {
            'affiliateName': this.state.affiliateName,
            'commissionFee': this.state.commissionFee,
            'trainerCommissionFee': this.state.trainerCommissionFee,
            'upLineFee': this.state.upLineFee, 
            "expansionLevel": this.state.expansionLevel,
        }
        this.setState({
            pageLoading: true
        })

        if(this.state.affiliateId) {
            servicePut(
                    `api/v1/affiliate/${this.state.affiliateId}`,
                    JSON.stringify(affiliate), headers)
            .then((res) => {
                if(res.data) {
                    this.setState({
                        affiliateName: null,
                        commissionFee: null,
                        trainerCommissionFee: null,
                        upLineFee: null,
                        expansionLevel: null,
                        pageLoading: false,
                        affiliateId: null
                    }, () => this.getAffiliateList());
                    toast('Affiliate updated successfully', {bodyClassName: 'success-toast'});
                } else {
                    toast(res.error, {bodyClassName: 'error-toast'});
                }
            })
            .catch((err) => {
                console.log(err)
                this.setState({
                    pageLoading: false
                })
                toast('Some error occurred', {bodyClassName: 'error-toast'});
            })
        } else {
            servicePost('api/v1/affiliate',JSON.stringify(affiliate),headers)
            .then((res) => {
                if(res.data) {
                        this.setState({
                            affiliateName: null,
                            commissionFee: null,
                            trainerCommissionFee: null,
                            upLineFee: null,
                            expansionLevel: null,
                            pageLoading: false
                        }, () => this.getAffiliateList());
                    toast('Affiliate created successfully',{bodyClassName:'success-toast'});
                } else {
                    toast(res.error, {bodyClassName: 'error-toast'});
                }
            })
            .catch((err) => {
                console.log(err)
                this.setState({
                    pageLoading: false
                })
                toast('Some error occurred', {bodyClassName: 'error-toast'});
            })
        }
    }

    toggle = (modal, affiliate) => {
        if(affiliate != null) {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                affiliateId: affiliate._id,
                affiliateName: affiliate.affiliateName,
                commissionFee: affiliate.commissionFee,
                trainerCommissionFee: affiliate.trainerCommissionFee,
                upLineFee: affiliate.upLineFee,
                expansionLevel: affiliate.expansionLevel,
            }))
        } else {
            this.setState((prevState) => ({
                modal: !prevState.modal,
                modalType: modal,
                affiliateId: null,
                affiliateName: null,
                commissionFee: null,
                trainerCommissionFee: null,
                upLineFee: null,
                expansionLevel: null,
            }))
        }
    };


    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });
    }

    changePage = ({selected})=>{
        this.setState({
            currentPage: selected + 1,
            affiliateList: []
        }, () => { this.getAffiliateList() });
     }

     deleteAffilate = (id,name)=>{
         //alert(id);
         Swal.fire({
            title: 'Are you sure?',
            // text: "You want to delete ",
            icon: 'warning',
            html: 'You want to delete <b>'+name+'</b> Affiliate',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
          }).then((result) => {
            if (result.isConfirmed) {
                this.setState({
                    pageLoading: true
                })
                let headers = {
                    'Content-Type': 'application/json',
                    Authorization: 'Bearer ' + this.state.user.token
                };
                serviceDelete('api/v1/affiliate/'+id+'/delete',headers)
                .then((res) => {
                    if(res.data) {
                            this.setState({
                                pageLoading: false
                            }, () =>{
                                Toast.fire({
                                    icon: 'success',
                                    title: 'Delete affiliate successfully'
                                  });
                                  this.getAffiliateList();
                            });
                    } else {
                        this.setState({
                            pageLoading: false
                        })
                    }
                })
                .catch((err) => {
                    console.log(err)
                    this.setState({
                        pageLoading: false
                    })
                    Toast.fire({
                        icon: 'error',
                        title: 'Some error occurred'
                      });
                })

                Toast.fire({
                    icon: 'success',
                    title: 'Delete affiliate successfully'
                  })
            
            }
          })
         
     }
    
     
    render() {
        const affiliateColumn = [
            {
                dataField: 'affiliateId',
                text: 'No',
                // sort: true,
            },
            {   
                dataField: 'affiliateName',
                text: 'Name',
                // sort : true
            },
            // {   
            //     dataField: 'commissionFee',
            //     text: 'Persontage',
            //     // sort : true
            //     formatter : (cell, row, rowIndex) => {
            //         return (<React.Fragment>
            //                 <div>{cell + '%'}</div>
            //             </React.Fragment>)
            //     }
            // },
            {   
                dataField: 'trainerCommissionFee',
                text: 'Trainer Fee',
                // sort : true
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <div>{cell + '%'}</div>
                        </React.Fragment>)
                }
            },
            {   
                dataField: 'upLineFee',
                text: 'Up Line Fee',
                // sort : true
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <div>{cell + '%'}</div>
                        </React.Fragment>)
                }
            },
            {   
                dataField: 'expansionLevel',
                text: 'Expansion Level',
                // sort : true
            },
            {   
                dataField: 'isEnabled',
                text: 'Action',
                formatter : (cell, row, rowIndex) => {
                    return (<React.Fragment>
                            <Row>
                                <Col md={3} className="p-0 m-0">
                                    <span className="transparent-toggle-button">
                                        <CustomInput 
                                            type="switch"
                                            defaultChecked={cell} 
                                            id={rowIndex}
                                            // name={tab.value}
                                            onChange={e => {this.switchAffiliate(row)}}
                                            label=""/>
                                    </span>
                                </Col>
                                <Col md={3} className="p-0 m-0">
                                    <span className="text-success pl-1"><i className="uil uil-edit" onClick={(e) => {this.toggle('editAffiliate',row);}}></i></span>
                                    <span className="text-danger pl-1"><i className="uil uil-glass-tea" onClick={() => this.deleteAffilate(row._id,row.affiliateName)}></i></span>
                                </Col>
                            </Row>
                        </React.Fragment>)
                }
            },
        ]
        return (
             <React.Fragment>{ this.state.pageLoading ? <Loader/> : <>
                <div className="container-fluid">
                    <div className="card mt-4">
                        <div className="card-header page-heading pt-4 pb-3">
                            <AvForm onValidSubmit={this.createAffiliate}>
                                <Row>
                                    <Col md={12}>
                                            <h3 className="text-dark">Affiliate</h3>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Affiliate Name</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                       
                                        <AvField name="affiliateName" type="text" required placeholder="Enter Name" autoComplete="false" value={this.state.affiliateName} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Commission Fee (Personnage %)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                       
                                        
                                        <AvField  name="commissionFee" type="number"  required placeholder="Enter Commission Fee" autoComplete="false" value={this.state.commissionFee} onChange={this.handleChange}
                                            
                                            onKeyUp={function(e){
                                                console.log(e);
                                                if (parseInt(e.target.value)  > 100 ) {
                                                    e.target.value = e.target.value.substring(0, e.target.value.length - 1);;
                                                    e.preventDefault();
                                                }
                                             }}
                                            validate = {{required: {value: true}}}/>
                                           
                                        
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Trainer commission fee (Personnage %)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="trainerCommissionFee" type="number" required placeholder="Enter Trainer Commission Fee" autoComplete="false" value={this.state.trainerCommissionFee} onChange={this.handleChange}
                                             onKeyUp={function(e){
                                                console.log(e);
                                                if (parseInt(e.target.value)  > 100 ) {
                                                    e.target.value = e.target.value.substring(0, e.target.value.length - 1);;
                                                    e.preventDefault();
                                                }
                                             }}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Up line fee (Personage %)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="upLineFee" type="number"  required placeholder="Enter UpLine Fee" autoComplete="false" value={this.state.upLineFee} onChange={this.handleChange}
                                            onKeyUp={function(e){
                                                console.log(e);
                                                if (parseInt(e.target.value)  > 100 ) {
                                                    e.target.value = e.target.value.substring(0, e.target.value.length - 1);;
                                                    e.preventDefault();
                                                }
                                             }}
                                           validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Expansion level (N-1)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="expansionLevel" type="number" required placeholder="Enter Level" autoComplete="false" value={this.state.expansionLevel} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={12} className="align-center my-3">
                                        <button className="btn btn-outline-primary btn-lg px-5">{this.state.affiliateId != null ? 'UPDATE' : 'ADD'}</button>
                                        
                                    </Col>
                                </Row>
                            </AvForm>
                        </div>
                    </div>
                </div>
            <div className="container-fluid">
                <div className="card shadow mt-4">
                    <div className="card-header page-heading pt-4 pb-3">
                        <div className="row">
                            <div className="col-md-12">
                                    <h3 className="text-dark">List of Affiliate</h3>
                            </div>
                        </div>
                    </div>
                    <div className="card-body p-0">    
                    <ToolkitProvider
                        bootstrap4
                        keyField="_id"
                        data={this.state.affiliateList}
                        columns={affiliateColumn}
                        // search
                        // exportCSV={{ onlyExportFiltered: true, exportAll: false }}
                        >
                        {props => (
                            <React.Fragment>
                                <BootstrapTable
                                    {...props.baseProps}
                                    bordered={false}
                                    wrapperClasses="table-responsive pl-3 pr-3"
                                    noDataIndication={ this.state.loading ? <Loader/> : 'No Data Found'}
                                />
                            </React.Fragment>
                        )}
                    </ToolkitProvider>   
                    </div>
                </div>
                <div className="row">
                    <div className="text-nowrap mt-4">
                        <ReactPaginate previousLabel={"Previous"} 
                            pageCount={this.state.pageCount}
                            nextLabel={"Next"} 
                            onPageChange={this.changePage} 
                            containerClassName={"paginationBttns"}
                            previousLinkClassName={"previousBttn"} nextLinkClassName={"nextBttn"}
                            activeLinkClassName={"paginationActive"} disabledClassName={"paginationDisabled"}>
                        </ReactPaginate>
                    </div>
                </div>
                {/* <Modal
                    isOpen={this.state.modal}
                    toggle={this.toggle}
                    className={this.state.className}
                    size='lg'>
                        <div><ModalHeader toggle={this.toggle}>Update Affiliate Information</ModalHeader>
                         <AvForm onValidSubmit={this.createAffiliate}>
                            <ModalBody>
                                <Row>
                                    <Col md={6} className="mt-3">
                                        <label>Commission Fee (Personnage %)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="commissionFee" type="text" required placeholder="Enter Commission Fee" autoComplete="false" value={this.state.commissionFee} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Trainer commission fee (Personnage %)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="trainerCommissionFee" type="text" required placeholder="Enter Trainer Commission Fee" autoComplete="false" value={this.state.trainerCommissionFee} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Up line fee (Personage %)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="upLineFee" type="text" required placeholder="Enter UpLine Fee" autoComplete="false" value={this.state.upLineFee} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                    <Col md={6} className="mt-3">
                                        <label>Expansion level (N-1)</label> <span className="text-danger pt-2"><sup>*</sup></span>
                                        <AvField name="expansionLevel" type="text" required placeholder="Enter Level" autoComplete="false" value={this.state.expansionLevel} onChange={this.handleChange}
                                            validate = {{required: {value: true}}}/>
                                    </Col>
                                </Row>
                            </ModalBody>
                            <ModalFooter>
                                <button className="btn btn-outline-primary btn-lg">Update</button>
                                <button className="btn btn-outline-danger btn-lg" onClick={this.toggle}>Cancel</button>
                            </ModalFooter>
                          </AvForm> 
                       </div>
                </Modal> */}
            </div> </>
            }
            </React.Fragment>
        )
    }
}
export default Affiliate;