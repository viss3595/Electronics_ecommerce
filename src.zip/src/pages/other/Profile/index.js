import React, { Component } from 'react';
import { Row, Col, Card, CardBody, Nav, NavItem, NavLink, TabContent, TabPane } from 'reactstrap';
import classNames from 'classnames';
import PageTitle from '../../../components/PageTitle';

import UserBox from './UserBox';



class Profile extends Component {
    constructor(props) {
        super(props);

        this.toggleTab = this.toggleTab.bind(this);
        this.state = {
            activeTab: '1'
        };
    }

    /**
     * Toggles tab
     * @param {*} tab 
     */
    toggleTab(tab) {
        if (this.state.activeTab !== tab) {
            this.setState({
                activeTab: tab
            });
        }
    }

    render() {
        return (
            <React.Fragment>
                <Row className="page-title">
                    <Col md={12}>
                        <PageTitle
                            breadCrumbItems={[
                                { label: 'Pages', path: '/pages/profile' },
                                { label: 'Profile', path: '/pages/profile', active: true },
                            ]}
                            title={'Profile'}
                        />
                    </Col>
                </Row>

                <Row>
                    <Col lg={6}>
                        {/* User information */}
                        <UserBox />
                    </Col>

                    <Col lg={9}>
                        
                    </Col>
                </Row>
            </React.Fragment>
        );
    }
}

export default Profile;
