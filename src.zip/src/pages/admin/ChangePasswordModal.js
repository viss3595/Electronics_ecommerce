import React, { useState, useEffect, Component } from 'react';
import { Redirect, Link } from 'react-router-dom';

import { connect } from 'react-redux';
import { AvForm, AvGroup, AvInput, AvFeedback } from 'availity-reactstrap-validation';

import { Row, Col, Label, Card, CardBody, Container, Button, Modal, ModalHeader, ModalBody, Alert } from 'reactstrap';
import { servicePost } from '../../helpers/api';

class ChangePasswordModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            alert: false,
            alertMessage: '',
        };
    }

    // console.log(tokenVerified);

    handleChange = (e) => {
        this.setState({ [e.target.id]: e.target.value });
    };

    handleSubmit = async (e) => {
        e.preventDefault();

        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'JWT ' + this.props.user.token,
        };
        let res = await servicePost(
            'change-password',
            { currentPassword: this.state.currentPassword, newPassword: this.state.newPassword },
            headers
        );
        console.log(res);
        if (res.data !== null) {
            this.setState({
                alert: true,
                alertColor: 'success',
                alertMessage: 'Password Changed Successfully',
            });
        } else if (res.statusCode === 200) {
            this.setState({
                alert: true,
                alertColor: 'danger',
                alertMessage: "Current password didn't match",
            });
        } else {
            this.setState({
                alert: true,
                alertColor: 'danger',
                alertMessage: 'Error changing password',
            });
        }

        setTimeout(() => {
            this.setState({
                alert: false,
            });
        }, 3000);
    };

    render() {
        return (
            <React.Fragment>
                <Modal isOpen={this.props.Modal} toggle={this.props.Toggle}>
                    <ModalHeader toggle={this.toggle}>Change Password</ModalHeader>

                    <ModalBody>
                        <AvForm onSubmit={this.handleSubmit}>
                            <AvGroup>
                                <Label for="examplePassword2">Current password</Label>
                                <AvInput
                                    required
                                    type="password"
                                    name="currentPassword"
                                    id="currentPassword"
                                    onChange={this.handleChange}
                                    placeholder="Enter old password"
                                    autoComplete="false"
                                    style={{ backgroundColor: '#f3f4f7' }}
                                />
                            </AvGroup>
                            <AvGroup>
                                <Label for="examplePassword2">New password</Label>
                                <AvInput
                                    required
                                    type="password"
                                    name="newPassword"
                                    id="newPassword"
                                    onChange={this.handleChange}
                                    placeholder="Enter new password"
                                    autoComplete="false"
                                    style={{ backgroundColor: '#f3f4f7' }}
                                />
                            </AvGroup>
                            <Alert color={this.state.alertColor} isOpen={this.state.alert ? true : false}>
                                <div
                                    dangerouslySetInnerHTML={{
                                        __html: this.state.alertMessage,
                                    }}></div>
                            </Alert>
                            <AvGroup row>
                                <Col sm={6}>
                                    <Button
                                        onClick={this.props.Toggle}
                                        style={{ float: 'right' }}
                                        className="btn btn-primary cancel-btn"
                                        type="button">
                                        Cancel
                                    </Button>
                                </Col>
                                <Col sm={6}>
                                    <Button color="primary" type="submit">
                                        Change
                                    </Button>
                                </Col>
                            </AvGroup>
                        </AvForm>
                    </ModalBody>
                </Modal>
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    return state.Auth;
};

export default connect(mapStateToProps)(ChangePasswordModal);
