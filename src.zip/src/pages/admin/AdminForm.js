import React, { Component } from 'react';

import { Row, Col, Label, Card, CardBody, Container, Button, Modal, ModalHeader, ModalBody, Alert } from 'reactstrap';
import { AvForm, AvGroup, AvInput } from 'availity-reactstrap-validation';
import PageTitle from '../../components/PageTitle';
import { connect } from 'react-redux';
import { servicePost } from './../../helpers/api';
import Axios from 'axios';
import CardTitle from 'reactstrap/lib/CardTitle';
import { dateFormat } from './../../helpers/common';
import { toast } from 'react-toastify';
import Loader from '../../components/Loader';
import ChangePasswordModal from './ChangePasswordModal';

class AdminForm extends Component {
    constructor(props) {
        super(props);

        this.state = {
            adminData: '',
            planData: '',
            ExpiresOn: [],
            val: '',
            callDuration: '',
            loader: true,
            modal: false,
            buttonName: this.props.buttonName,
            modalType: this.props.modalType,
            modalTitle: 'title',
        };
        this.updateDetails = this.updateDetails.bind(this);
        this.handleChange = this.handleChange.bind(this);

        this.handleShow = this.handleShow.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.toggle = this.toggle.bind(this);
        this.openModalWithSize = this.openModalWithSize.bind(this);
        this.openModalWithClass = this.openModalWithClass.bind(this);
    }
    handleShow() {
        // console.log(this.state)
        this.setState({ modal: true });
    }
    handleClose() {
        this.setState({ modal: false });
    }

    /**
     * Show/hide the modal
     */
    toggle = () => {
        this.setState((prevState) => ({
            modal: !prevState.modal,
        }));
    };

    /**
     * Opens large modal
     */
    openModalWithSize = (size) => {
        this.setState({ size: size, className: null });
        this.toggle();
    };

    /**
     * Opens modal with custom class
     */
    openModalWithClass = (className) => {
        this.setState({ className: className, size: null });
        this.toggle();
    };

    componentDidMount() {
        this._isMounted = true;
        // GET ADMIN DATA USING API
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'JWT ' + this.props.user.token,
        };
        servicePost('adminSetting', {}, headers)
            .then((res) => {
                if (res.data) {
                    this.setState({
                        adminData: res.data,
                        callDuration: res.data.minimumCallDuration,
                    });

                    headers = {
                        'Content-Type': 'application/json',
                        Authorization: 'JWT ' + this.props.user.token,
                    };

                    servicePost('plan/getPlanDetails', { planId: this.state.adminData.planId }, headers).then((res) => {
                        if (res) {
                            this.setState({
                                planData: res.data,
                                loader: false,
                            });
                            /*let expireOn = dateFormat(this.state.planData.createdAt)
                        this.setState({
                            ExpiresOn : expireOn.split(" ")
                        })
                        let now = new Date().getDate();
                        let month = new Date().getMonth()+1;
                        if(now==Number(this.state.ExpiresOn[0])){
                            this.setState({
                                val:"Today"
                            })
                        }
                        else{
                            if(month==2)
                            {
                                this.setState({
                                    val:"29" + "/" + (new Date().getMonth()+1) + "/" + new Date().getFullYear()
                                })
                            }
                            else if(month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12)
                            {
                                this.setState({
                                    val:"31" + "/" + (new Date().getMonth()+1) + "/" + new Date().getFullYear()
                                })
                            }
                            else{
                                this.setState({
                                    val:"30" + "/" + (new Date().getMonth()+1) + "/" + new Date().getFullYear()
                                })
                            }
                        }*/
                        }
                    });
                }
            })
            .catch((err) => {
                console.log(err);
            });
    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    handleChange(e) {
        this.setState({
            callDuration: e.target.value,
        });
    }

    updateDetails() {
        let headers = {
            'Content-Type': 'application/json',
            Authorization: 'JWT ' + this.props.user.token,
        };

        servicePost('user/updateUser', { minCallDuration: this.state.callDuration }, headers)
            .then((res) => {
                if (res === 'Updated') {
                    toast('Successfully Updated', { bodyClassName: 'success-toast' });
                } else {
                    toast('Updation Failed', { bodyClassName: 'error-toast' });
                }
            })
            .catch((err) => {
                console.log(err);
            });
    }
    copyToClipboard = (e) => {
        navigator.clipboard.writeText(this.refs.myInput.value);
        this.setState({ copied: true });
        setTimeout(() => {
            this.setState({ copied: false });
        }, 2000);
    };
    render() {
        if (this.state.loader) {
            return (
                <Row className="page-title mt-4">
                    <Col xl={12} md={12}>
                        <Loader />
                    </Col>
                </Row>
            );
        }
        return (
            <React.Fragment>
                <Row className="page-title">
                    <Col md={12}>
                        <PageTitle
                            breadCrumbItems={[{ label: 'Admin Settings', path: '/admin_settings', active: true }]}
                            title={'Admin Setting'}
                        />
                    </Col>
                </Row>

                <ChangePasswordModal Modal={this.state.modal} Value={this.state.adminData.email} Toggle={this.toggle} />

                <Container>
                    <Row>
                        <Col className="col-md-8">
                            <Card>
                                <CardBody>
                                    <CardTitle tag="h5">
                                        {' '}
                                        <span className="uil-suitcase"></span> Your Plan
                                    </CardTitle>
                                    <div>
                                        You are on the plan:{' '}
                                        <span style={{ fontWeight: '900' }}>{this.state.planData.planName}</span>
                                    </div>
                                    {/* <div><span style={{fontWeight:"900"}}>Your billing rate:</span> ${(1/((this.state.planData.minutes*60)/this.state.planData.planPrice))} per second of audio transcribed</div> */}
                                    {/* <div>Expires on: {this.state.val}</div> */}
                                    <div>
                                        Max number of agents:{' '}
                                        <span style={{ fontWeight: '900' }}>{this.state.adminData.countAgents}</span>
                                    </div>
                                    <div>
                                        Pricing per agent:{' '}
                                        <span style={{ fontWeight: '900' }}>${this.state.planData.planPrice}</span>
                                    </div>
                                </CardBody>
                            </Card>
                            <Card>
                                <CardBody>
                                    <h4 className="header-title mt-0">Profile</h4>
                                    <AvForm onSubmit={this.updateDetails}>
                                        <AvGroup>
                                            <Label for="examplePassword2">Admin email</Label>
                                            <AvInput
                                                disabled
                                                type="email"
                                                name="email"
                                                id=""
                                                placeholder="Enter Email"
                                                autoComplete="false"
                                                style={{ backgroundColor: '#f3f4f7' }}
                                                value={this.state.adminData.email}
                                            />
                                        </AvGroup>

                                        <AvGroup>
                                            <Label for="examplePassword2">Account name</Label>
                                            <AvInput
                                                disabled
                                                type="text"
                                                name="name"
                                                id=""
                                                placeholder="Enter Name"
                                                autoComplete="false"
                                                style={{ backgroundColor: '#f3f4f7' }}
                                                value={this.state.adminData.name}
                                            />
                                        </AvGroup>

                                        
                                        <AvGroup>
                                            <Label for="examplePassword2">No. of agents in plan</Label>
                                            <AvInput
                                                disabled
                                                type="text"
                                                name="countAgents"
                                                id="countAgents"
                                                placeholder="No. of Agents"
                                                style={{ backgroundColor: '#f3f4f7' }}
                                                value={this.state.adminData.countAgents}
                                                autoComplete="false"
                                            />
                                        </AvGroup>
                                        <AvGroup>
                                            <Label for="examplePassword2">
                                                Analysis minutes per agents (per month)
                                            </Label>
                                            <AvInput
                                                disabled
                                                type="text"
                                                name="totalMinutes"
                                                id="totalMinutes"
                                                placeholder="Total Minutes"
                                                style={{ backgroundColor: '#f3f4f7' }}
                                                value={this.state.adminData.totalSeconds / 60}
                                                autoComplete="false"
                                            />
                                        </AvGroup>
                                        <AvGroup>
                                            <Label for="examplePassword2">
                                                Analyze calls above this duration (in seconds)
                                            </Label>
                                            <AvInput
                                                type="text"
                                                name="minimumCallDuration"
                                                id="minimumCallDuration"
                                                placeholder="Total Seconds"
                                                value={this.state.callDuration}
                                                onChange={this.handleChange}
                                                autoComplete="false"
                                            />
                                        </AvGroup>
                                        <Button type="submit" outline color="primary">
                                            Save
                                        </Button>
                                    </AvForm>
                                </CardBody>
                            </Card>
                        </Col>
                        <Col className="col-md-4">
                            <Card>
                                <CardBody>
                                    <CardTitle tag="h5">
                                        {' '}
                                        <span className="uil-user"></span> Account Details
                                    </CardTitle>
                                    <AvForm onSubmit={this.updateDetails}>
                                        <AvGroup>
                                            <Label for="examplePassword2">Email</Label>
                                            <AvInput
                                                disabled
                                                type="email"
                                                name="email"
                                                id=""
                                                placeholder="Enter Email"
                                                autoComplete="false"
                                                style={{ backgroundColor: '#f3f4f7' }}
                                                value={this.state.adminData.email}
                                            />
                                        </AvGroup>
                                        <AvGroup>
                                            <Label for="examplePassword2">Password</Label>
                                            <AvInput
                                                disabled
                                                type="password"
                                                name="password"
                                                id=""
                                                placeholder="Enter Email"
                                                autoComplete="false"
                                                style={{ backgroundColor: '#f3f4f7' }}
                                                value={'sdfkasdflj'}
                                            />
                                        </AvGroup>

                                        <a
                                            onClick={() => this.openModalWithClass('modal-dialog-scrollable')}
                                            style={{ color: '#5268f7' }}
                                            type="submit"
                                            outline
                                            color="primary">
                                            change password
                                        </a>
                                    </AvForm>
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>
                </Container>
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    // const { user, loading, error } = state.Auth;
    return state.Auth;
};
export default connect(mapStateToProps)(AdminForm);
