// @flow
import React, { Component } from 'react';
import Chart from 'react-apexcharts';
import {  Col, Row } from 'reactstrap';
import * as d3 from 'd3';



// simple donut chart
class TimeSeriesChart extends Component {
    constructor(props) {
        super(props);
        this.state = {
            width: this.props.width,
        };
    }

    componentDidMount(){
        this.drawChart(this.props, this.state.width);
    }

    responsivefy(svg) {
        
        // get container + svg aspect ratio
        var container = d3.select(svg.node().parentNode),
            width = parseInt(svg.style("width")),
            height = parseInt(svg.style("height")),
            aspect = width / height;
    
            alert(`${width} ${height} ${aspect}`)

        // add viewBox and preserveAspectRatio properties,
        // and call resize so that svg resizes on inital page load
        svg
        // .attr("viewBox", "0 0 " + width + " " + height)
            .attr("perserveAspectRatio", "xMinYMid")
            .call(resize);
    
        // to register multiple listeners for same event type, 
        // you need to add namespace, i.e., 'click.foo'
        // necessary if you call invoke this function for multiple svgs
        // api docs: https://github.com/mbostock/d3/wiki/Selections#on
        d3.select(window).on("resize." + container.attr("id"), resize);
    
        // get width of container and resize svg to fit it
        function resize() {
            var targetWidth = parseInt(container.style("width"));
            svg.attr("width", targetWidth);
            svg.attr("height", Math.round(targetWidth / aspect));
        }
    }

     componentDidUpdate(){
        
        
     }

    drawChart(props, width) {
        
        let height = props.height;
        let curveWidth = props.curveWidth;
        let colorIndex = props.colorIndex;
        let barHeight = props.barHeight;
        let aspect = width / height;
        
        d3.selectAll(`#${props.id} svg`).remove();
        var svg = d3.select(`#${props.id}`).append('svg')
        .attr('width', width)
        .attr('height', barHeight)
        // .call(this.responsivefy);
        

        // .attr("preserveAspectRatio", "xMinYMin")
        // .attr('viewBox', `0 0 ${width} ${height}`);

        var states = [0, 1, 2],
            segmentWidth = 100,
            currentState = colorIndex;

        var colorScale = d3.scaleOrdinal().domain(states).range(['yellow', 'orange', 'green']);

        svg.append('rect')
            .attr('class', 'bg-rect')
            .attr('rx', curveWidth)
            .attr('ry', curveWidth)
            .attr('fill', '#F3F4F7')
            .attr('height', barHeight)
            .attr('width', width)
            .attr('x', 0);

        // svg.append('rect')
        // .attr('class', 'bg-rect')
        // .attr('rx', 10)
        // .attr('ry', 10)
        // .attr('fill', 'gray')
        // .attr('height', 15)
        // .attr('width', function(){
        // 	return segmentWidth * states.length;
        // })
        // .attr('x', 0);

        try {
            props.records.forEach((record) => {
                let progress = svg
                    .append('rect')
                    .attr('class', 'progress-rect')
                    .attr('fill', function () {
                        return colorScale(currentState);
                    })
                    .attr('height', barHeight)
                    .attr('width', ((width/props.totalTime )* record.end_time)  -((width/props.totalTime )* record.start_time)  )
                    .attr('rx', curveWidth)
                    .attr('ry', curveWidth)
                    .attr('x', ((width/props.totalTime )* record.start_time));
                // progress
                //     .transition()
                //     .duration(1000)
                //     .attr('width', function () {
                //         var index = states.indexOf(currentState);
                //         return (index + 1) * segmentWidth;
                //     });
            });    
        } catch (error) {
            console.log("Empty", error);
        }
        

        // function moveProgressBar(state){
        // 	progress.transition()
        // 		.duration(1000)
        // 		.attr('fill', function(){
        // 			return colorScale(state);
        // 		})
        // 		.attr('width', function(){
        // 			var index = states.indexOf(state);
        // 			return (index + 1) * segmentWidth;
        // 		});
        // }
    }

    render() {
        return (
                    <React.Fragment>
                        <Row className="my-1">
                            <Col md={1} xl={1} xs={12} style={{ textAlign : "center"}}>
                                <span className="text-muted text-uppercase font-size-12 font-weight-bold">{this.props.title}</span>
                            </Col>
                            <Col md={1} xl={10} xs={12} style={{ textAlign : "center"}}>
                            <div  style={{ marginLeft: "70px" }} className={`mt-${this.props.margin} mb-${this.props.margin}`} id={this.props.id}></div>
                            </Col>
                        </Row>
                        
                        
                    </React.Fragment>
                    
                
        );
    }
}

export default TimeSeriesChart;
