 export const SERVICE_URL = 'http://localhost:3001';
//export const SERVICE_URL = "http://13.212.90.48/api/";

export const DEFAULT_SERVICE_VERSION = "v1";
