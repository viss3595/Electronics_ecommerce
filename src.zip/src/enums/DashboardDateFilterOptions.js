export const dashbordFilterOption={
    Last7Days : { label  :'Last 7 Days',value : '7Days'},
    LastMonth : {lable:'Last month',value:'LastMonth'},
    ThisYear : {label:'This year',value:'ThisYear'},
    LastYear : {label:'Last year',value:'LastYear'}
}