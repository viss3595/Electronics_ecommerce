import React, { Component } from 'react';
import { Row, Col, Spinner } from 'reactstrap';
import loader from './../assets/images/loader-block.svg';

/**
 * Renders the preloader
 */
class PreLoaderWidget extends Component {
    constructor(props){
        super(props);

    }
    render() {
        if(this.props.spinner){
            return ( <div className="preloader">
            <div className="status">
                <div className="spinner-border avatar-sm text-primary m-2" role="status"></div>
            </div>
        </div>)
        }
        return (
            <Row className="page-title mt-4">
                <Col md={12} xs={12}  style={{ textAlign : "center"}}>
                    <div
                    style={{  marginTop : "15%", marginBottom : "15%"}}
                    >
                            <Spinner  className="m-2" type="grow" color={'primary'} />
                <Spinner  className="m-2" type="grow" color={'primary'} />
                <Spinner  className="m-2" type="grow" color={'primary'} />
                <Spinner  className="m-2" type="grow" color={'primary'} />
                <Spinner  className="m-2" type="grow" color={'primary'} />

                    </div>
                
                {/* <img style={{ width : "6rem", marginTop : "15%"}} src={loader}></img> */}
                    {/* <div className="preloader">
                        <div className="status">
                            <div className="spinner-border avatar-sm text-primary m-2" role="status"></div>
                        </div>
                    </div> */}
                </Col>
            </Row>
        );
    }
}

export default PreLoaderWidget;
