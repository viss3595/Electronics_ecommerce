import React, { Component } from "react";
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { Container } from 'reactstrap';
import { Menu, X, Search, Settings, User, HelpCircle, Lock, LogOut } from 'react-feather';

import { showRightSidebar } from '../redux/actions';
import NotificationDropdown from './NotificationDropdown';
import ProfileDropdown from './ProfileDropdown';
import LanguageDropdown from './LanguageDropdown';

import logo from '../assets/images/icons/icon_building.png';
import profilePic from '../assets/images/users/avatar-7.jpg';
import {UncontrolledDropdown, DropdownToggle, DropdownMenu} from "reactstrap";
import { getLoggedInUser } from "../helpers/authUtils";


const Notifications = [{
  id: 1,
  text: 'New user registered',
  subText: '1 min ago',
  icon: 'uil uil-user-plus',
  bgColor: 'primary'
},
{
  id: 2,
  text: 'Karen Robinson',
  subText: 'Wow ! this admin looks good and awesome design',
  icon: 'uil uil-comment-message',
  bgColor: 'success'
},
{
  id: 3,
  text: 'Cristina Pride',
  subText: 'Hi, How are you? What about our next meeting',
  icon: 'uil uil-comment-message',
  bgColor: 'danger'
}, {
  id: 4,
  text: 'New user registered',
  subText: '1 day ago',
  icon: 'uil uil-user-plus',
  bgColor: 'info'
},];

const ProfileMenus = [{
  label: 'My Account',
  icon: User,
  redirectTo: "/",
},
{
  label: 'Settings',
  icon: Settings,
  redirectTo: "/"
},
{
  label: 'Support',
  icon: HelpCircle,
  redirectTo: "/"
},
{
  label: 'Lock Screen',
  icon: Lock,
  redirectTo: "/"
},
{
  label: 'Logout',
  icon: LogOut,
  redirectTo: "/logout",
  hasDivider: true
}];
const COLORS_ARRAY = ['#2EA1F8', '#FF9600', '#2BB415', '#B698EE', '#76E0B7', '#B8E986', '#F5EA5E', '#9D5617', '#F8BC1C', '#D0021B', '#6EB9E2', '#9D57DB', '#C955E1', '#069E7C', '#D92777', '#F3586B'];
const size_class = 'circle-';


class Topbar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: getLoggedInUser()
    }
    this.handleRightSideBar = this.handleRightSideBar.bind(this);
  }

  componentDidMount(){
    this.generateProfilePic();
  }
  /**
   * Toggles the right sidebar
   */
  handleRightSideBar = () => {
    this.props.showRightSidebar();
  }

  backgroundColor(name) {
    let selected_index = name.length % COLORS_ARRAY.length;
    return COLORS_ARRAY[selected_index];
  };

  generateProfilePic = (name) => {
    if(this.state.user.imageUrl) {
      document.getElementById('profile_pic').style['background-image'] = 'url(' + this.imageUrl + ')';
      document.getElementById('profile_pic').innerText = '';
    } else {
     document.getElementById('profile_pic').style['background-image'] = '';
     document.getElementById('profile_pic').innerText = this.getLetters(this.state.user.name);
     document.getElementById('profile_pic').style['background-color'] = this.backgroundColor(this.state.user.name);
    }
  }

  getLetters = (name) => {
    let name_array = name.toLowerCase().split(' ');
    let first_letter = name_array[0].charAt(0);
    return (name_array.length - 1 === 0 ? first_letter : first_letter + name_array[name_array.length - 1].charAt(0));
  };

  render() {
    return (
      <React.Fragment>
        <div className="navbar navbar-expand flex-column flex-md-row navbar-custom">
          <Container fluid>
            { /* logo */}
            <Link to="/" className="navbar-brand mr-0 mr-md-2 logo">
              <span className="logo-lg">
                <img src={logo} alt="" height="70" />
              </span>
              <span className="logo-sm">
                <img src={logo} alt="" height="24" />
              </span>
            </Link>

            { /* menu*/}
            <ul className="navbar-nav bd-navbar-nav flex-row list-unstyled menu-left mb-0">
              <li className="">
                <button className="button-menu-mobile open-left disable-btn" onClick={this.props.openLeftMenuCallBack}>
                  <Menu className="menu-icon" />
                  <X className="close-icon" />
                </button>
              </li>
            </ul>


            <ul className="navbar-nav flex-row ml-auto d-flex list-unstyled topnav-menu float-right mb-0">
              {/* <li className="d-none d-sm-block">
                <div className="app-search">
                  <form>
                    <div className="input-group">
                      <input type="text" className="form-control" placeholder="Search..." />
                      <Search />
                    </div>
                  </form>
                </div>
              </li>

              <LanguageDropdown tag="li" />
              <NotificationDropdown notifications={Notifications} /> */}

              {/* <li className="notification-list">
                <button className="btn btn-link nav-link right-bar-toggle" onClick={this.handleRightSideBar}>
                  <Settings />
                </button>
              </li> */}

              {/* <ProfileDropdown profilePic={profilePic} menuItems={ProfileMenus} username={'Shreyu N'} description="Administrator" /> */}
            </ul>
            <UncontrolledDropdown className="align-self-center profile-dropdown-menu">
                    <DropdownToggle
                        data-toggle="dropdown"
                        tag="button"
                        className="btn p-0 dropdown-toggle mr-0">
                        {/* <img src={profilePic} className="avatar-sm rounded-circle mr-2" alt="user" /> */}
                        <span className="avatar-sm rounded-circle mr-2 profile-pic" id="profile_pic"></span>
                      
                        {/*<FeatherIcon.ChevronDown />*/}
                    </DropdownToggle>
                    <DropdownMenu right className="topbar-dropdown-menu profile-dropdown-items">
                        {/* <Link to="/" className="dropdown-item notify-item">
                        <FeatherIcon.User className="icon-dual icon-xs mr-2" />
                        <span>My Account</span>
                    </Link> */}
                        {/*<Link to="/admin_settings" className="dropdown-item notify-item">
                            <FeatherIcon.Settings className="icon-dual icon-xs mr-2" />
                            <span>Admin Settings</span>
                        </Link>
                    */}

                        {/* <Link to="/" className="dropdown-item notify-item">
                        <FeatherIcon.HelpCircle className="icon-dual icon-xs mr-2" />
                        <span>Support</span>
                    </Link> */}
                        {/* <Link to="/" className="dropdown-item notify-item">
                        <FeatherIcon.Lock className="icon-dual icon-xs mr-2" />
                        <span>Lock Screen</span>
                    </Link> */}
                        {/*<DropdownItem divider />*/}
                        <Link to="/logout" className="dropdown-item notify-item">
                            <LogOut className="icon-dual icon-xs mr-2" />
                            <span>Logout</span>
                        </Link>
                    </DropdownMenu>
                </UncontrolledDropdown>

          </Container>
        </div>
      </React.Fragment >
    );
  }
}

export default connect(
  null,
  { showRightSidebar }
)(Topbar);
