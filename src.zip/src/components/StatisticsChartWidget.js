import React from 'react';
import { Card, CardBody, CardText, Col, Media, Row, Progress } from 'reactstrap';
import Chart from 'react-apexcharts';
import classNames from 'classnames';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import ViewSummary from '../pages/settings/ViewSummary';
import { servicePost } from './../helpers/api';
import 'react-tippy/dist/tippy.css';
import { Tooltip } from 'react-tippy';

let ms = require('ms');
const StatisticsChartWidget = (props) => {
    const options = {
        chart: {
            parentHeightOffset: 0,
            toolbar: {
                show: false,
            },
            sparkline: {
                enabled: true,
            },
        },
        fill: {
            type: 'gradient',
            gradient: {
                type: 'vertical',
                shadeIntensity: 1,
                inverseColors: false,
                opacityFrom: 0.45,
                opacityTo: 0.05,
                stops: [45, 100],
            },
        },
        xaxis: {
            crosshairs: {
                width: 1,
            },
        },
        stroke: {
            width: 2,
            curve: 'smooth',
        },
        tooltip: {
            theme: 'dark',
            fixed: {
                enabled: false,
            },
            x: {
                show: false,
            },
            y: {
                title: {
                    formatter: function () {
                        return '';
                    },
                },
            },
            marker: {
                show: false,
            },
        },
        colors: props.colors || ['#727cf5'],
    };
    const type = props.type || 'area';
    const series = [{ name: props.name || 'Data', data: props.data || [] }];
    const isModal = () => {
        //alert('====im good====');
        props.newdata();
    };

    const getRocTextHtml = (rateOfChange) => {
        if (rateOfChange == 0) {
            return (
                <span style={{ color: 'darkgray' }} class="font-weight-bold dashboard-summary-flash-card-text">
                    {' '}
                    <span className="font-size-14 font-weight-bold">{rateOfChange}%</span>
                </span>
            );
        } else if (rateOfChange > 0) {
            return (
                <span class="text-success font-weight-bold dashboard-summary-flash-card-text">
                    <i class="uil uil-arrow-up"></i>
                    <span className="font-size-14 font-weight-bold" style={{ color: 'darkgray' }}>
                        {Math.abs(rateOfChange)}%
                    </span>
                </span>
            );
        } else {
            return (
                <span class="text-danger font-weight-bold dashboard-summary-flash-card-text">
                    <i class="uil uil-arrow-down"></i>
                    <span className="font-size-14 font-weight-bold" style={{ color: 'darkgray' }}>
                        {Math.abs(rateOfChange)}%
                    </span>
                </span>
            );
        }
    };

    const getRateOfChange = (previousValue, newValue) => {
        // alert(previousValue, newValue);
        try {
            let p = Number(newValue) / Number(previousValue);
            if (Number(previousValue) == 0) {
                throw 'Divide by Zero';
            }
            let rateOfChange = Number((p - 1) * 100).toFixed(0);
            if (isNaN(rateOfChange) || rateOfChange === Infinity) {
                throw rateOfChange;
            }
            return {
                rateOfChange: rateOfChange,
            };
        } catch (error) {
            return {
                rateOfChange: 0.0,
            };
        }
    };
    let achievdCallRoc = getRateOfChange(props.prevDateDate.achievedCall, props.achievedCall);
    let MissedCallRoc = getRateOfChange(props.prevDateDate.missedCall, props.missedCall);

    return (
        <Card className={classNames(props.bgClass)}>
            <CardBody className="p-3">
                <CardText>
                    <Row>
                        <Col className="text-muted  font-size-14 font-weight-bold" md={9}>
                            {props.description}
                        </Col>
                        <Col md={3}>
                            <div className="dashboard-since-timestamp">
                                vs. previous{' '}
                                {ms(new Date(props.dateRange.to).getTime() - new Date(props.dateRange.from).getTime(), {
                                    long: true,
                                })}{' '}
                                period
                            </div>
                        </Col>
                    </Row>
                    <div className="pt-3">
                        {/* <span
                            style={{ color: '#000', backgroundColor: '#d8f7ce' }}
                            className="mr-1 badge-pill font-weight-500 font-size-14 badge badge-success">
                            Achieved in
                        </span> */}

                        <Row>
                            <Col md={9} className="right-border">
                                {/* Both Missed & Achieved Calls Data Here */}
                                <div>
                                    <div style={{ display: 'flex', alignSelf: 'center' }}>
                                        <div className="font-size-24 font-weight-bold">{props.achievedCall}</div>
                                        <div
                                            style={{ fontWeight: '500 !important', alignSelf: 'center' }}
                                            className="pl-2 mt-1 text-muted  font-size-14 font-weight-bold">
                                            {props.achievedCall > 1 ? 'calls' : 'call'} (Moment achieved)
                                        </div>
                                        <div
                                            style={{ flexGrow: '1', alignSelf: 'center' }}
                                            className="pl-1 font-size-14 font-weight-bold">
                                            <span style={{ float: 'right' }}>{props.title}</span>
                                        </div>
                                    </div>
                                    <Progress color="info" value={props.title.split('%')[0].trim()} className="mb-2" />
                                </div>
                            </Col>
                            <Col md={3}>
                                <div className="dashboard-summary-flash-card-text pt-3">
                                    {' '}
                                    {
                                        <Tooltip
                                            // options
                                            title={`Moment achieved in ${props.prevDateDate.achievedCall} ${
                                                props.prevDateDate.achievedCall > 1 ? 'Calls' : 'Call'
                                            } in the previous period`}
                                            position="top-end"
                                            arrow={true}
                                            trigger="mouseenter">
                                            {getRocTextHtml(achievdCallRoc.rateOfChange)}
                                        </Tooltip>
                                    }
                                </div>
                            </Col>
                            <Col md={9} className="right-border">
                                <div>
                                    <div style={{ display: 'flex', alignSelf: 'center' }}>
                                        <div className="font-size-24 font-weight-bold">{props.missedCall}</div>
                                        <div
                                            style={{ fontWeight: '500 !important', alignSelf: 'center' }}
                                            className="pl-2 mt-1 text-muted  font-size-14 font-weight-bold">
                                            {props.missedCall > 1 ? 'calls' : 'call'} (Moment missed)
                                        </div>
                                        <div
                                            style={{ flexGrow: '1', alignSelf: 'center' }}
                                            className="pl-1 font-size-14 font-weight-bold">
                                            <span style={{ float: 'right' }}>{props.missedPercentage}</span>
                                        </div>
                                    </div>
                                    <Progress
                                        color="warning"
                                        value={props.missedPercentage.split('%')[0].trim()}
                                        className="mb-2"
                                    />
                                </div>
                            </Col>
                            <Col md={3} className="top-border pb-2">
                                <div className="dashboard-summary-flash-card-text pt-3">
                                    {' '}
                                    {
                                        <Tooltip
                                            // options
                                            title={`Moment missed in ${props.prevDateDate.missedCall}  ${
                                                props.prevDateDate.missedCall > 1 ? 'Calls' : 'Call'
                                            } in the previous period`}
                                            position="top-end"
                                            arrow={true}
                                            trigger="mouseenter">
                                            {getRocTextHtml(MissedCallRoc.rateOfChange)}
                                        </Tooltip>
                                    }
                                </div>
                            </Col>
                            <Col md={12} className="text-muted  font-size-14 font-weight-bold top-border pt-2">
                                <i className="uil uil-book-reader pr-1"></i>
                                <Tooltip
                                    // options
                                    title={`Shows agent wise splits for this call moment`}
                                    position="top-end"
                                    arrow={true}
                                    trigger="mouseenter">
                                    <ViewSummary
                                        teamId={props.teamId}
                                        modalView={isModal.bind(this)}
                                        buttonName={'View splits'}
                                        modalType={'moment'}
                                        modalTitle={'Summary'}
                                        groupID={props.groupId}
                                        momentId={props.momentId}
                                        groupName={props.groupName}
                                        momentName={props.momentName}
                                        achievedCalls={props.achievedCall}
                                        totalCalls={props.totalCalls}
                                        avgAchievedCalls={props.title}
                                        isFooter={'false'}
                                        getDataReq={'true'}
                                        groupColor={props.groupColor}
                                    />
                                </Tooltip>
                            </Col>
                        </Row>

                        {/* {props.achievedCall > 1 && (
                            <React.Fragment>
                                <div className="mb-0">
                                    <span className="font-size-18 font-weight-bold">
                                        {props.achievedCall} calls &nbsp;
                                    </span>
                                    <span className="font-size-14 font-weight-bold">({props.title})</span>
                                </div>
                            </React.Fragment>
                        )} */}
                        {/* {props.achievedCall <= 1 && (
                            <React.Fragment>
                                <div className="mb-0">
                                    <span className="font-size-18 font-weight-bold">{props.achievedCall} call</span>
                                </div>
                            </React.Fragment>
                        )} */}
                        {/* PREVIOUS DATE ACHIEVED CALLS DATA */}
                        {/* {props.prevDateDate.achievedCall <= 1 && (
                            <React.Fragment>
                                <span
                                    style={{ color: '#000', backgroundColor: '#D3D3D3' }}
                                    className="mr-1 badge-pill font-weight-500 font-size-10 badge badge-danger">
                                    Previous period {props.prevDateDate.achievedCall} call{' '}
                                </span>
                            </React.Fragment>
                        )}
                        {props.prevDateDate.achievedCall > 1 && (
                            <React.Fragment>
                                <span
                                    style={{ color: '#000', backgroundColor: '#D3D3D3' }}
                                    className="mr-1 badge-pill font-weight-500 font-size-10 badge badge-danger">
                                    Previous period {props.prevDateDate.achievedCall} calls (
                                    {props.prevDateDate.achievedCallPercentage})
                                </span>
                            </React.Fragment>
                        )} */}
                    </div>

                    <div className="align-self-center d-none">
                        <Chart
                            className="apex-charts"
                            options={options}
                            series={series}
                            type={type}
                            height={45}
                            width={90}
                        />
                        <span className={classNames(props.trend.textClass, 'font-weight-bold', 'font-size-13')}>
                            <i className={`${props.trend.icon}`}></i> {props.trend.value}
                        </span>
                    </div>
                </CardText>
            </CardBody>
        </Card>
    );
};

const mapStateToProps = (state) => {
    const { user, loading, error } = state.Auth;
    const { dateRange, pastDateRange } = state.Options;
    return { user, loading, error, dateRange, pastDateRange };
};
export default connect(mapStateToProps)(StatisticsChartWidget);
