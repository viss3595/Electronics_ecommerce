# Authenticity-Console

This is a console application (Frontend) of Authenticity where user can upload calls and do analysis

### Installation

Console requires [Node.js](https://nodejs.org/) to run.

Install the dependencies and devDependencies and start the server.

```sh
$ npm install --verbose
```

For production environments...

```sh
$ npm install
$ npm run build
```

* NOTE : Update the Service URL (NodeJS) Service Url in `src/constants/utility.js`. Default is `http://localhost:3001`
 
### Deployment
- Install pm2 with command `npm install -g pm2`
- Run the application in daemon mode using pm2 `pm2 start app.js --name=authenticity-console`
- Server is accessible on `http://localhost:3000` now !